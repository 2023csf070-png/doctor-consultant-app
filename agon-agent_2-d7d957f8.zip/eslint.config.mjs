import tsParser from "@typescript-eslint/parser";
export default [
  {
    ignores: [
      "dist/**",
      "node_modules/**",
      ".expo/**",
      ".clinic*/**",
      "test-artifacts/**",
      ".agon-env/**",
    ],
  },
  {
    files: ["**/*.{ts,tsx}"],
    languageOptions: {
      parser: tsParser,
      parserOptions: { ecmaFeatures: { jsx: true }, sourceType: "module" },
    },
    rules: {
      "no-unreachable": "error",
      "no-eval": "error",
      "no-debugger": "error",
      "no-duplicate-case": "error",
      "no-dupe-keys": "error",
    },
  },
  {
    files: [
      "server/**/*.mjs",
      "api/**/*.mjs",
      "scripts/**/*.mjs",
      "tests/**/*.mjs",
    ],
    languageOptions: { ecmaVersion: "latest", sourceType: "module" },
    rules: {
      "no-unreachable": "error",
      "no-eval": "error",
      "no-debugger": "error",
      "no-dupe-keys": "error",
      "no-constant-binary-expression": "error",
    },
  },
];
