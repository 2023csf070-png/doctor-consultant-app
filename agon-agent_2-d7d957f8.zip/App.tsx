import React from "react";
import { useFonts } from "expo-font";
import Ionicons from "@expo/vector-icons/Ionicons";
import { SafeAreaProvider } from "react-native-safe-area-context";
import ClinicApp from "./screens/ClinicApp";

export default function App() {
  const [ready, fontError] = useFonts({ ...Ionicons.font });
  if (!ready && !fontError) return null;
  return (
    <SafeAreaProvider>
      <ClinicApp />
    </SafeAreaProvider>
  );
}
