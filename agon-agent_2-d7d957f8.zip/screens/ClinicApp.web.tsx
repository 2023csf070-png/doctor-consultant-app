import React, { useEffect, useState } from "react";
import { api, setSession, Service, User } from "../lib/api";
import catalog from "../lib/catalog.json";
import { Clinic, Button, Empty, Icon, Loading } from "../components/UI.web";
import {
  Header,
  Footer,
  Home,
  About,
  Services,
  Contact,
  Legal,
  Online,
} from "./Public.web";
import { Auth } from "./Auth.web";
import { Booking } from "./Booking.web";
import { Dashboard } from "./Dashboard.web";
import "./clinic.css";
const getPath = () => window.location.pathname + window.location.search;
const titles: Record<string, string> = {
  "/": "Bashir Alam Clinic Multan | Medical Clinic & Online Consultation",
  "/about": "About the Clinic",
  "/services": "Medical Services",
  "/contact": "Contact & Directions",
  "/book": "Book an Appointment in Multan",
  "/online-consultation": "Online Doctor Consultation",
  "/privacy": "Privacy Policy",
  "/terms": "Terms & Conditions",
  "/patient/signup": "Patient Registration",
  "/doctor/login": "Doctor Portal",
  "/patient/login": "Patient Portal",
  "/forgot-password": "Account Recovery",
  "/reset-password": "Reset Password",
};
export default function ClinicApp() {
  const [path, setPath] = useState(getPath),
    [user, setUser] = useState<User | null>(null),
    [ready, setReady] = useState(false),
    [preview, setPreview] = useState(false),
    [services, setServices] = useState<Service[]>(catalog),
    [message, setMessage] = useState(""),
    [booking, setBooking] = useState<any>(null),
    [bootError, setBootError] = useState("");
  const go = (to: string) => {
    if (!to.startsWith("/") || to.startsWith("//")) return;
    window.history.pushState({}, "", to);
    setPath(getPath());
    window.scrollTo({ top: 0, behavior: "instant" });
  };
  const onAuth = (u: User | null, c = "") => {
    setUser(u);
    setSession(c);
    if (!u) setBooking(null);
  };
  const refreshServices = async () => {
    const r = await api("services");
    setServices(r.services);
  };
  const init = () => {
    setBootError("");
    api("session")
      .then((r) => {
        onAuth(r.user, r.csrf);
        setPreview(r.preview);
      })
      .catch((e) => setBootError(e.message))
      .finally(() => setReady(true));
  };
  useEffect(() => {
    init();
    refreshServices().catch(() => {});
    const pop = () => {
      setPath(getPath());
      window.scrollTo(0, 0);
    };
    const expire = () => {
      onAuth(null);
      setMessage("Your session expired. Please sign in again.");
    };
    window.addEventListener("popstate", pop);
    window.addEventListener("clinic-session-expired", expire);
    return () => {
      window.removeEventListener("popstate", pop);
      window.removeEventListener("clinic-session-expired", expire);
    };
  }, []);
  useEffect(() => {
    if (message) {
      const t = setTimeout(() => setMessage(""), 5500);
      return () => clearTimeout(t);
    }
  }, [message]);
  const route = path.split("?")[0].replace(/\/$/, "") || "/",
    dash = route === "/patient/dashboard" || route === "/doctor/dashboard";
  useEffect(() => {
    document.title =
      route === "/"
        ? titles["/"]
        : (titles[route] || (dash ? "Private Workspace" : "Clinic")) +
          " | Bashir Alam Clinic";
  }, [route]);
  useEffect(() => {
    if (dash && ready && !bootError) {
      const role = route.startsWith("/doctor") ? "doctor" : "patient";
      if (!user || user.role !== role)
        go("/" + role + "/login?next=" + encodeURIComponent(path));
    }
    if (ready && user && route === "/" + user.role + "/login") {
      const q = new URLSearchParams(path.split("?")[1]);
      go(q.get("next") || "/" + user.role + "/dashboard");
    }
  }, [route, ready, user?.id]);
  let page;
  if (dash)
    page = !ready ? (
      <Loading />
    ) : bootError ? (
      <Empty
        title="Workspace unavailable"
        action={<Button onClick={init}>Reconnect</Button>}
      >
        {bootError}
      </Empty>
    ) : user && route.startsWith("/" + user.role) ? (
      <Dashboard />
    ) : (
      <Loading label="Opening secure sign in…" />
    );
  else if (route === "/") page = <Home />;
  else if (route === "/about") page = <About />;
  else if (route === "/services") page = <Services />;
  else if (route === "/contact") page = <Contact />;
  else if (route === "/book") page = <Booking />;
  else if (route === "/online-consultation") page = <Online />;
  else if (route === "/privacy" || route === "/terms")
    page = <Legal isPrivacy={route === "/privacy"} />;
  else if (
    [
      "/patient/login",
      "/doctor/login",
      "/patient/signup",
      "/forgot-password",
      "/reset-password",
    ].includes(route)
  )
    page = (
      <Auth
        key={path}
        kind={
          route.includes("signup")
            ? "signup"
            : route.includes("forgot")
              ? "forgot"
              : route.includes("reset")
                ? "reset"
                : "login"
        }
        doctor={route.startsWith("/doctor")}
      />
    );
  else
    page = (
      <Empty
        title="Page not found"
        action={<Button to="/">Back to home</Button>}
      >
        This page is not part of the clinic website.
      </Empty>
    );
  return (
    <Clinic.Provider
      value={{
        go,
        path,
        user,
        ready,
        preview,
        services,
        refreshServices,
        onAuth,
        toast: setMessage,
        booking,
        setBooking,
      }}
    >
      <a className="skip-link" href="#main-content">
        Skip to content
      </a>
      <Header />
      <div id="main-content" tabIndex={-1}>
        {page}
      </div>
      {!dash && <Footer />}
      {message && (
        <div className="toast" role="status">
          <Icon name="success" size={18} />
          {message}
          <button aria-label="Dismiss message" onClick={() => setMessage("")}>
            <Icon name="x" size={14} />
          </button>
        </div>
      )}
    </Clinic.Provider>
  );
}
