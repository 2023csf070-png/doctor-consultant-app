import React, { createContext, useContext, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Linking,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  useColorScheme,
  View,
  Switch,
} from "react-native";
import {
  NavigationContainer,
  DefaultTheme,
  DarkTheme,
  useNavigation,
} from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { SafeAreaView } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { Image } from "expo-image";
import Animated, { FadeIn, ReduceMotion } from "react-native-reanimated";
import Ionicons from "@expo/vector-icons/Ionicons";
import * as Store from "expo-secure-store";
import {
  api,
  apiBase,
  dateLabel,
  FOOTER_DISCLAIMER,
  MAP,
  PHONE,
  pkToday,
  setSession,
  timeLabel,
  TYPES,
  User,
} from "../lib/api";
import catalog from "../lib/catalog.json";
const Tabs = createBottomTabNavigator(),
  Stack = createNativeStackNavigator();
const Native = createContext<any>(null);
const useApp = () => useContext(Native);
const nav = () => useNavigation<any>();
const symbols: Record<string, any> = {
  stethoscope: "medkit-outline",
  heart: "pulse-outline",
  video: "videocam-outline",
  followup: "calendar-outline",
  calendar: "calendar-number-outline",
  folder: "folder-open-outline",
  prescription: "document-text-outline",
  education: "book-outline",
};
function Label({
  children,
  title = false,
  muted = false,
  style,
}: {
  children: React.ReactNode;
  title?: boolean;
  muted?: boolean;
  style?: any;
}) {
  const { theme: t } = useApp();
  return (
    <Text
      style={[
        {
          color: muted ? t.muted : t.text,
          fontSize: title ? 23 : 14,
          fontWeight: title ? "700" : "400",
          lineHeight: title ? 30 : 21,
        },
        style,
      ]}
    >
      {children}
    </Text>
  );
}
function Action({
  children,
  onPress,
  icon,
  secondary = false,
  disabled = false,
}: {
  children: string;
  onPress: () => void;
  icon?: any;
  secondary?: boolean;
  disabled?: boolean;
}) {
  const { theme: t } = useApp();
  return (
    <Pressable
      accessibilityRole="button"
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        s.action,
        {
          backgroundColor: secondary ? t.surface : "#087f70",
          borderColor: secondary ? t.line : "#087f70",
          opacity: disabled ? 0.45 : pressed ? 0.8 : 1,
        },
      ]}
    >
      {icon && (
        <Ionicons name={icon} size={18} color={secondary ? t.text : "#fff"} />
      )}
      <Text
        style={{
          fontWeight: "600",
          color: secondary ? t.text : "#fff",
          fontSize: 13,
        }}
      >
        {children}
      </Text>
    </Pressable>
  );
}
function Box({ children }: { children: React.ReactNode }) {
  const { theme: t } = useApp();
  return (
    <Animated.View
      entering={FadeIn.duration(160).reduceMotion(ReduceMotion.System)}
      style={[s.box, { backgroundColor: t.surface, borderColor: t.line }]}
    >
      {children}
    </Animated.View>
  );
}
function Err({ message }: { message: string }) {
  return message ? (
    <Text accessibilityRole="alert" style={s.err}>
      {message}
    </Text>
  ) : null;
}
function Header({
  tag,
  title,
  body,
}: {
  tag: string;
  title: string;
  body?: string;
}) {
  return (
    <View style={{ gap: 7, marginBottom: 16 }}>
      <Text style={s.overline}>{tag}</Text>
      <Label title>{title}</Label>
      {body && <Label muted>{body}</Label>}
    </View>
  );
}
function external(path: string) {
  const origin = apiBase();
  if (!origin)
    return Alert.alert(
      "Clinic connection",
      "Set EXPO_PUBLIC_API_ORIGIN to the deployed HTTPS clinic in the app build configuration.",
    );
  Linking.openURL(origin + path).catch(() =>
    Alert.alert("Unable to open the clinic portal."),
  );
}
function Home() {
  const n = nav(),
    { theme: t } = useApp(),
    [items, setItems] = useState(catalog),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const load = async () => {
    setBusy(true);
    setError("");
    try {
      const r = await api("services");
      setItems(r.services);
    } catch {
      setError("Live service updates are unavailable. Pull down to reconnect.");
    } finally {
      setBusy(false);
    }
  };
  useEffect(() => {
    if (apiBase()) load();
  }, []);
  return (
    <SafeAreaView
      edges={["left", "right"]}
      style={{ flex: 1, backgroundColor: t.bg }}
    >
      <FlatList
        data={items}
        keyExtractor={(i) => i.id}
        refreshing={busy}
        onRefresh={load}
        contentContainerStyle={s.page}
        ListHeaderComponent={
          <>
            <View style={[s.hero, { backgroundColor: t.soft }]}>
              <Text style={s.overline}>IN-CLINIC & ONLINE CARE</Text>
              <Label
                style={{
                  fontSize: 43,
                  lineHeight: 46,
                  fontWeight: "800",
                  letterSpacing: -2.3,
                  marginVertical: 10,
                }}
              >
                Your Health,{"\n"}
                <Text style={{ color: "#087f70" }}>Our Priority.</Text>
              </Label>
              <Label muted>
                Book your appointment online and consult with your doctor
                conveniently from anywhere through secure online consultation.
              </Label>
              <Image
                source={require("../assets/images/consultation.webp")}
                style={s.photo}
                contentFit="cover"
                accessibilityLabel="A doctor consulting with a patient"
              />
              <Action
                icon="calendar-outline"
                onPress={() => n.navigate("Book")}
              >
                Book Appointment
              </Action>
              <Action
                secondary
                icon="videocam-outline"
                onPress={() => n.navigate("Book", { type: TYPES[2] })}
              >
                Online Consultation
              </Action>
            </View>
            <View style={{ marginVertical: 20 }}>
              <Header
                tag="OUR SERVICES"
                title="Care for every step"
                body="In-person and online care with Dr. Faisal Jhandir."
              />
            </View>
            <Err message={error} />
          </>
        }
        renderItem={({ item }) => (
          <Pressable
            accessibilityRole="button"
            onPress={() => n.navigate("Service", { service: item })}
          >
            <Box>
              <View style={s.row}>
                <View style={[s.sym, { backgroundColor: t.soft }]}>
                  <Ionicons
                    name={symbols[item.icon]}
                    size={24}
                    color="#388b74"
                  />
                </View>
                <View style={{ flex: 1 }}>
                  <Label style={{ fontWeight: "650" }}>{item.name}</Label>
                  <Label muted style={{ fontSize: 12, lineHeight: 18 }}>
                    {item.description}
                  </Label>
                </View>
                <Ionicons name="chevron-forward" size={15} color={t.muted} />
              </View>
            </Box>
          </Pressable>
        )}
        ListFooterComponent={
          <Label muted style={{ fontSize: 11, marginVertical: 14 }}>
            For a medical emergency, seek immediate local emergency care.
          </Label>
        }
      />
    </SafeAreaView>
  );
}
function Service({ route }: any) {
  const x = route.params.service,
    n = nav(),
    { theme: t } = useApp();
  return (
    <SafeAreaView style={[s.page, { flex: 1, backgroundColor: t.bg }]}>
      <Header tag="CLINIC SERVICE" title={x.name} body={x.detail} />
      <Action
        onPress={() =>
          n.navigate("ClinicTabs", {
            screen: ["records", "prescription", "guidance"].includes(x.id)
              ? "My care"
              : "Book",
            params: {
              type:
                x.id === "online"
                  ? TYPES[2]
                  : x.id === "followup"
                    ? TYPES[3]
                    : x.id === "disease"
                      ? TYPES[1]
                      : TYPES[0],
            },
          })
        }
      >
        {["records", "prescription", "guidance"].includes(x.id)
          ? "Open patient care"
          : "Book a consultation"}
      </Action>
    </SafeAreaView>
  );
}
function NativeAuth({ route }: any) {
  const n = nav(),
    { setUser, theme: t } = useApp(),
    [kind, setKind] = useState("login"),
    [b, setB] = useState<Record<string, string>>({}),
    [consent, setConsent] = useState(false),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const doctor = route.params?.doctor === true;
  const inputs =
    kind === "signup"
      ? [
          ["name", "Full name"],
          ["father_name", "Father / husband name"],
          ["cnic", "CNIC (13 digits)"],
          ["dob", "Date of birth (YYYY-MM-DD)"],
          ["gender", "Gender (Male, Female, Other, or Prefer not to say)"],
          ["phone", "Mobile number"],
          ["email", "Email address"],
          ["address", "Address"],
          ["city", "City"],
          ["password", "Password (12+ characters)"],
          ["confirmation", "Confirm password"],
        ]
      : kind === "forgot"
        ? [["email", "Registered email"]]
        : [
            ["identifier", doctor ? "Email or username" : "Email or phone"],
            ["password", "Password"],
            ...(doctor ? [["otp", "Authenticator code (if enabled)"]] : []),
          ];
  async function submit() {
    setBusy(true);
    setError("");
    try {
      if (!apiBase())
        throw Error(
          "The clinic API address must be configured for this native build.",
        );
      if (kind === "signup") {
        await api("signup", { ...b, consent });
        setB({ identifier: b.email });
        setKind("login");
        Alert.alert("Account created", "Sign in with your email and password.");
      } else if (kind === "forgot") {
        const r = await api("forgot", {
          email: b.email,
          role: doctor ? "doctor" : "patient",
        });
        Alert.alert("Account recovery", r.message);
      } else {
        const r = await api("login", {
          ...b,
          role: doctor ? "doctor" : "patient",
        });
        await Store.setItemAsync("clinic-native-session", r.sessionToken);
        setSession(r.csrf, r.sessionToken);
        setUser(r.user);
        n.goBack();
      }
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: t.bg }}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <FlatList
        data={inputs}
        keyExtractor={(i) => i[0]}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={s.page}
        ListHeaderComponent={
          <Header
            tag={doctor ? "AUTHORISED DOCTOR" : "PATIENT PORTAL"}
            title={
              kind === "signup"
                ? "Create your account"
                : kind === "forgot"
                  ? "Recover your account"
                  : "Welcome back"
            }
            body="Private access to your clinic workspace."
          />
        }
        renderItem={({ item: [k, l] }) => (
          <View style={{ marginBottom: 13 }}>
            <Label style={s.fieldLabel}>{l}</Label>
            <TextInput
              accessibilityLabel={l}
              style={[
                s.input,
                {
                  color: t.text,
                  backgroundColor: t.surface,
                  borderColor: t.line,
                },
              ]}
              value={b[k] || ""}
              onChangeText={(v) => setB({ ...b, [k]: v })}
              secureTextEntry={k === "password" || k === "confirmation"}
              keyboardType={
                k === "email"
                  ? "email-address"
                  : k === "phone"
                    ? "phone-pad"
                    : k === "cnic"
                      ? "number-pad"
                      : "default"
              }
              autoCapitalize="none"
              returnKeyType="done"
              maxLength={k === "address" ? 450 : 180}
            />
          </View>
        )}
        ListFooterComponent={
          <>
            {kind === "signup" && (
              <View style={s.row}>
                <Switch value={consent} onValueChange={setConsent} />
                <Label style={{ flex: 1, fontSize: 12 }}>
                  I consent to storing these details for my care and agree to
                  the clinic privacy policy.
                </Label>
              </View>
            )}
            <Err message={error} />
            <Action disabled={busy} onPress={submit}>
              {busy
                ? "Please wait…"
                : kind === "login"
                  ? "Sign in securely"
                  : kind === "forgot"
                    ? "Request reset link"
                    : "Create patient account"}
            </Action>
            {!doctor && (
              <Action
                secondary
                onPress={() => {
                  setError("");
                  setKind(kind === "signup" ? "login" : "signup");
                }}
              >
                {kind === "signup"
                  ? "Already registered? Sign in"
                  : "Create patient account"}
              </Action>
            )}
            <Action
              secondary
              onPress={() => {
                setError("");
                setKind(kind === "forgot" ? "login" : "forgot");
              }}
            >
              {kind === "forgot" ? "Back to sign in" : "Forgot password?"}
            </Action>
          </>
        }
      />
    </KeyboardAvoidingView>
  );
}
function Booking({ route }: any) {
  const n = nav(),
    { user, theme: t } = useApp(),
    [type, setType] = useState(TYPES[0]),
    [day, setDay] = useState(pkToday()),
    [slots, setSlots] = useState<number[]>([]),
    [time, setTime] = useState<number | null>(null),
    [reason, setReason] = useState(""),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [success, setSuccess] = useState<any>(null);
  const load = async () => {
    setError("");
    setBusy(true);
    setTime(null);
    try {
      if (!apiBase())
        throw Error(
          "Connect this native build to the clinic API to see live availability.",
        );
      const r = await api("slots", undefined, { day });
      setSlots(r.slots);
    } catch (e: any) {
      setSlots([]);
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };
  useEffect(() => {
    load();
  }, [day]);
  useEffect(() => {
    if (route.params?.type) setType(route.params.type);
  }, [route.params?.type]);
  async function submit() {
    if (!user) {
      n.navigate("Secure access");
      return;
    }
    if (user.role === "doctor") {
      external("/book");
      return;
    }
    if (time === null || !reason.trim()) {
      setError("Select a time and enter the reason for your visit.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      const r = await api("book", { type, day, start_min: time, reason });
      setSuccess(r);
      setReason("");
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }
  if (success)
    return (
      <SafeAreaView style={[s.page, { flex: 1, backgroundColor: t.bg }]}>
        <Header
          tag="REQUEST RECEIVED"
          title="Appointment requested"
          body={
            "Reference " +
            success.reference +
            " · Awaiting doctor confirmation."
          }
        />
        <Box>
          <Label>
            {dateLabel(success.day)} · {timeLabel(success.start_min)} PKT
          </Label>
        </Box>
        <Action
          onPress={() => {
            setSuccess(null);
            n.navigate("My care");
            load();
          }}
        >
          View my appointments
        </Action>
      </SafeAreaView>
    );
  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: t.bg }}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <FlatList
        data={slots}
        numColumns={3}
        keyExtractor={(m) => String(m)}
        refreshing={busy}
        onRefresh={load}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={s.page}
        ListHeaderComponent={
          <>
            <Header
              tag="YOUR NEXT VISIT"
              title="Book an appointment"
              body="Choose your visit, date, and available time."
            />
            <Label style={s.fieldLabel}>Consultation type</Label>
            <View style={s.chips}>
              {TYPES.map((x) => (
                <Pressable
                  key={x}
                  style={[
                    s.chip,
                    {
                      backgroundColor: type === x ? "#daeee3" : t.surface,
                      borderColor: t.line,
                    },
                  ]}
                  onPress={() => setType(x)}
                >
                  <Text
                    style={{
                      fontSize: 12,
                      color: type === x ? "#227a5a" : t.text,
                    }}
                  >
                    {x}
                  </Text>
                </Pressable>
              ))}
            </View>
            <Label style={s.fieldLabel}>Appointment date · PKT</Label>
            <FlatList
              horizontal
              showsHorizontalScrollIndicator={false}
              data={Array.from({ length: 90 }, (_, i) =>
                new Date(
                  new Date(pkToday() + "T12:00:00Z").getTime() + 86400000 * i,
                )
                  .toISOString()
                  .slice(0, 10),
              )}
              keyExtractor={(x) => x}
              renderItem={({ item }) => (
                <Pressable
                  style={[
                    s.chip,
                    {
                      marginRight: 6,
                      backgroundColor: day === item ? "#daeee3" : t.surface,
                      borderColor: t.line,
                    },
                  ]}
                  onPress={() => setDay(item)}
                >
                  <Text
                    style={{
                      color: day === item ? "#227a5a" : t.text,
                      fontSize: 12,
                    }}
                  >
                    {dateLabel(item, true).slice(0, -5)}
                  </Text>
                </Pressable>
              )}
            />
            <Label style={[s.fieldLabel, { marginTop: 15 }]}>
              Available times
            </Label>
            <Err message={error} />
          </>
        }
        renderItem={({ item }) => (
          <Pressable
            onPress={() => setTime(item)}
            style={[
              s.chip,
              {
                margin: 3,
                flex: 1,
                backgroundColor: time === item ? "#daeee3" : t.surface,
                borderColor: t.line,
              },
            ]}
          >
            <Text
              style={{
                color: time === item ? "#227a5a" : t.text,
                fontSize: 12,
                textAlign: "center",
              }}
            >
              {timeLabel(item)}
            </Text>
          </Pressable>
        )}
        ListEmptyComponent={
          busy ? (
            <ActivityIndicator color="#087f70" />
          ) : (
            <Label muted>No slots available for this date.</Label>
          )
        }
        ListFooterComponent={
          <View style={{ marginTop: 15 }}>
            <Label style={s.fieldLabel}>Reason for your visit</Label>
            <TextInput
              accessibilityLabel="Reason for visit"
              value={reason}
              onChangeText={setReason}
              multiline
              maxLength={2000}
              style={[
                s.input,
                {
                  minHeight: 80,
                  color: t.text,
                  backgroundColor: t.surface,
                  borderColor: t.line,
                  textAlignVertical: "top",
                },
              ]}
            />
            <Action
              disabled={busy || time === null}
              icon="calendar-outline"
              onPress={submit}
            >
              {user ? "Request appointment" : "Sign in to request visit"}
            </Action>
          </View>
        }
      />
    </KeyboardAvoidingView>
  );
}
function Care() {
  const { user, setUser, theme: t } = useApp(),
    n = nav(),
    [data, setData] = useState<any>(null),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [tab, setTab] = useState("Appointments");
  async function load() {
    if (!user) return;
    setBusy(true);
    setError("");
    try {
      setData(await api("dashboard"));
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }
  useEffect(() => {
    load();
    return n.addListener("focus", load);
  }, [user?.id]);
  if (!user)
    return (
      <SafeAreaView style={[s.page, { flex: 1, backgroundColor: t.bg }]}>
        <Header
          tag="PATIENT PORTAL"
          title="Your private care space"
          body="Sign in to manage appointments, access clinical records, and read your clinic updates."
        />
        <Action
          icon="lock-closed-outline"
          onPress={() => n.navigate("Secure access")}
        >
          Patient sign in
        </Action>
      </SafeAreaView>
    );
  const list =
    tab === "Notifications"
      ? data?.notifications || []
      : data?.appointments || [];
  return (
    <FlatList
      style={{ backgroundColor: t.bg }}
      contentContainerStyle={s.page}
      data={list}
      keyExtractor={(r: any) => r.id}
      refreshing={busy}
      onRefresh={load}
      ListHeaderComponent={
        <>
          <Header
            tag={
              user.role === "doctor" ? "DOCTOR WORKSPACE" : "PATIENT WORKSPACE"
            }
            title={"Hello, " + user.name.split(" ")[0]}
            body="Your visits and the latest clinic updates."
          />
          <View style={s.row}>
            {["Appointments", "Notifications"].map((x) => (
              <Pressable
                key={x}
                onPress={() => setTab(x)}
                style={[
                  s.chip,
                  {
                    borderColor: t.line,
                    backgroundColor: tab === x ? "#daeee3" : t.surface,
                  },
                ]}
              >
                <Text style={{ color: tab === x ? "#227a5a" : t.text }}>
                  {x}
                </Text>
              </Pressable>
            ))}
          </View>
          <Err message={error} />
        </>
      }
      renderItem={({ item: a }: any) => (
        <Box>
          {tab === "Notifications" ? (
            <>
              <Text style={s.overline}>{a.category}</Text>
              <Label>{a.message}</Label>
              {!a.read_at && (
                <Action
                  secondary
                  onPress={async () => {
                    try {
                      await api("notification.read", { id: a.id });
                      load();
                    } catch (e: any) {
                      setError(e.message);
                    }
                  }}
                >
                  Mark read
                </Action>
              )}
            </>
          ) : (
            <>
              <Label style={{ fontWeight: "700" }}>{a.type}</Label>
              <Label muted>
                {dateLabel(a.day, true)} · {timeLabel(a.start_min)} PKT
              </Label>
              <Label>
                {a.reference} · {a.status}
              </Label>
              <Label muted>{a.reason}</Label>
              {a.has_zoom === 1 && a.status === "Confirmed" && (
                <Action
                  icon="videocam-outline"
                  onPress={async () => {
                    try {
                      const z = await api("zoom.join", undefined, { id: a.id });
                      Linking.openURL(z.url);
                    } catch (e: any) {
                      setError(e.message);
                    }
                  }}
                >
                  Join Online Consultation
                </Action>
              )}
              {["Pending", "Confirmed"].includes(a.status) && (
                <Action
                  secondary
                  onPress={() =>
                    Alert.alert(
                      "Cancel appointment?",
                      a.reference + " will be cancelled.",
                      [
                        { text: "Keep visit", style: "cancel" },
                        {
                          text: "Cancel visit",
                          style: "destructive",
                          onPress: async () => {
                            try {
                              await api("appointment.change", {
                                id: a.id,
                                status: "Cancelled",
                              });
                              load();
                            } catch (e: any) {
                              setError(e.message);
                            }
                          },
                        },
                      ],
                    )
                  }
                >
                  Cancel appointment
                </Action>
              )}
            </>
          )}
        </Box>
      )}
      ListEmptyComponent={
        <Box>
          <Label muted>
            {busy ? "Loading…" : "No " + tab.toLowerCase() + " to show."}
          </Label>
        </Box>
      }
      ListFooterComponent={
        <>
          {user.role === "patient" && (
            <Action
              icon="folder-outline"
              onPress={() => n.navigate("Private records")}
            >
              Medical records & prescriptions
            </Action>
          )}
          <Action
            secondary
            icon="open-outline"
            onPress={() => external("/" + user.role + "/dashboard")}
          >
            Open full secure workspace
          </Action>
          <Action
            secondary
            onPress={async () => {
              try {
                await api("logout", {});
                await Store.deleteItemAsync("clinic-native-session");
                setSession("", "");
                setUser(null);
                setData(null);
              } catch (e: any) {
                setError(e.message);
              }
            }}
          >
            Sign out
          </Action>
        </>
      }
    />
  );
}
function NativeRecords() {
  const { user, theme: t } = useApp(),
    [d, setD] = useState<any>(null),
    [e, setE] = useState(""),
    [busy, setBusy] = useState(true);
  const load = async () => {
    setBusy(true);
    setE("");
    try {
      setD(await api("patient.record", undefined, { id: user.id }));
    } catch (x: any) {
      setE(x.message);
    } finally {
      setBusy(false);
    }
  };
  useEffect(() => {
    load();
  }, []);
  const list = [
    ...(d?.records || []).map((r: any) => ({
      id: r.id,
      title: r.category,
      body: r.content,
    })),
    ...(d?.notes || []).map((r: any) => ({
      id: r.id,
      title: "Doctor’s note",
      body: r.body,
    })),
    ...(d?.prescriptions || []).map((r: any) => ({
      id: r.id,
      title: "Prescription · " + dateLabel(r.created_at, true),
      body:
        r.diagnosis +
        "\n" +
        r.items
          .map(
            (m: any) =>
              m.medicine +
              " · " +
              m.dosage +
              " · " +
              m.frequency +
              " · " +
              m.duration +
              "\n" +
              m.instructions,
          )
          .join("\n") +
        "\n" +
        r.notes,
    })),
  ];
  return (
    <FlatList
      style={{ backgroundColor: t.bg }}
      contentContainerStyle={s.page}
      data={list}
      refreshing={busy}
      onRefresh={load}
      keyExtractor={(x) => x.id}
      ListHeaderComponent={
        <>
          <Header
            tag="PRIVATE RECORD"
            title="Clinical timeline"
            body="Records and prescriptions shared by your doctor."
          />
          <Err message={e} />
        </>
      }
      renderItem={({ item }) => (
        <Box>
          <Label style={{ fontWeight: "700" }}>{item.title}</Label>
          <Label muted>{item.body}</Label>
        </Box>
      )}
      ListEmptyComponent={
        <Box>
          <Label muted>
            {busy ? "Loading record…" : "No clinical entries yet."}
          </Label>
        </Box>
      }
    />
  );
}
function Contact() {
  const n = nav(),
    { theme: t } = useApp();
  return (
    <FlatList
      style={{ backgroundColor: t.bg }}
      contentContainerStyle={s.page}
      data={[
        [
          "Clinic hours",
          "9:00 AM – 2:00 PM and 5:00 PM – 10:00 PM · Pakistan time",
        ],
        [
          "Visit the clinic",
          "Near MDA Officers Cooperative Housing Society, Multan, Punjab, Pakistan.\n6GC7+3XQ, Multan, 60000.",
        ],
        [
          "Emergency guidance",
          "Seek immediate local emergency medical care. Do not wait for an online consultation.",
        ],
      ]}
      keyExtractor={(x) => x[0]}
      ListHeaderComponent={
        <Header
          tag="MULTAN, PAKISTAN"
          title="Bashir Alam Clinic"
          body="Care with Dr. Faisal Jhandir."
        />
      }
      renderItem={({ item }) => (
        <Box>
          <Label style={{ fontWeight: "700" }}>{item[0]}</Label>
          <Label muted>{item[1]}</Label>
        </Box>
      )}
      ListFooterComponent={
        <>
          <Action
            icon="call-outline"
            onPress={() => Linking.openURL("tel:+923020460461")}
          >
            Call Now · 0302 0460461
          </Action>
          <Action
            secondary
            icon="navigate-outline"
            onPress={() => Linking.openURL(MAP)}
          >
            Get Directions
          </Action>
          <View style={s.row}>
            <Pressable onPress={() => external("/privacy")}>
              <Label style={s.smallLink}>Privacy policy</Label>
            </Pressable>
            <Pressable onPress={() => external("/terms")}>
              <Label style={s.smallLink}>Terms & conditions</Label>
            </Pressable>
          </View>
          <Label
            muted
            style={{ fontSize: 11, lineHeight: 17, marginVertical: 15 }}
          >
            {FOOTER_DISCLAIMER}
          </Label>
          <Pressable
            onPress={() => n.navigate("Secure access", { doctor: true })}
          >
            <Label style={s.smallLink}>Doctor portal</Label>
          </Pressable>
        </>
      }
    />
  );
}
function TabScreens() {
  const { theme: t } = useApp();
  return (
    <Tabs.Navigator
      screenOptions={({ route }) => ({
        headerStyle: { backgroundColor: "#112f40" },
        headerTintColor: "#fff",
        headerTitle: "Bashir Alam Clinic",
        headerTitleStyle: { fontSize: 18, fontWeight: "700" },
        tabBarStyle: { backgroundColor: t.surface, borderTopColor: t.line },
        tabBarActiveTintColor: "#198b75",
        tabBarInactiveTintColor: t.muted,
        tabBarIcon: ({ color, size }) => (
          <Ionicons
            size={size}
            color={color}
            name={
              (
                {
                  Clinic: "home-outline",
                  Book: "calendar-outline",
                  "My care": "folder-open-outline",
                  Contact: "location-outline",
                } as any
              )[route.name]
            }
          />
        ),
      })}
    >
      <Tabs.Screen name="Clinic" component={Home} />
      <Tabs.Screen name="Book" component={Booking} />
      <Tabs.Screen name="My care" component={Care} />
      <Tabs.Screen name="Contact" component={Contact} />
    </Tabs.Navigator>
  );
}
export default function ClinicApp() {
  const dark = useColorScheme() === "dark",
    [user, setUser] = useState<User | null>(null);
  const theme = dark
    ? {
        bg: "#13262e",
        surface: "#1e343c",
        text: "#e7f1ed",
        muted: "#b3c6bd",
        line: "#38504a",
        soft: "#23423b",
      }
    : {
        bg: "#f7faf8",
        surface: "#fff",
        text: "#112f40",
        muted: "#62796b",
        line: "#d7e3db",
        soft: "#e4f2eb",
      };
  useEffect(() => {
    (async () => {
      try {
        const token = await Store.getItemAsync("clinic-native-session");
        if (token && apiBase()) {
          setSession("", token);
          const r = await api("session");
          setSession(r.csrf, r.user ? token : "");
          setUser(r.user);
          if (!r.user) await Store.deleteItemAsync("clinic-native-session");
        }
      } catch {
        setUser(null);
      }
    })();
  }, []);
  return (
    <Native.Provider value={{ user, setUser, theme }}>
      <StatusBar style="light" />
      <NavigationContainer theme={dark ? DarkTheme : DefaultTheme}>
        <Stack.Navigator
          screenOptions={{
            headerStyle: { backgroundColor: theme.surface },
            headerTintColor: theme.text,
            contentStyle: { backgroundColor: theme.bg },
          }}
        >
          <Stack.Screen
            name="ClinicTabs"
            component={TabScreens}
            options={{ headerShown: false }}
          />
          <Stack.Screen name="Service" component={Service} />
          <Stack.Screen
            name="Secure access"
            component={NativeAuth}
            options={{ presentation: "modal" }}
          />
          <Stack.Screen name="Private records" component={NativeRecords} />
        </Stack.Navigator>
      </NavigationContainer>
    </Native.Provider>
  );
}
const s = StyleSheet.create({
  page: { padding: 20, paddingBottom: 32 },
  box: {
    borderWidth: 1,
    borderRadius: 13,
    padding: 16,
    marginBottom: 10,
    gap: 5,
  },
  row: { flexDirection: "row", alignItems: "center", gap: 12 },
  sym: {
    width: 43,
    height: 43,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  hero: { padding: 18, borderRadius: 18, gap: 4 },
  photo: { width: "100%", height: 180, borderRadius: 13, marginVertical: 12 },
  action: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 9,
    borderWidth: 1,
    marginTop: 9,
  },
  overline: {
    fontSize: 10,
    fontWeight: "700",
    color: "#38876b",
    letterSpacing: 1.7,
  },
  input: { padding: 12, borderWidth: 1, borderRadius: 8, fontSize: 15 },
  fieldLabel: { fontSize: 12, fontWeight: "600", marginBottom: 5 },
  err: {
    backgroundColor: "#feeee6",
    color: "#994c3a",
    padding: 12,
    borderRadius: 8,
    fontSize: 12,
    marginVertical: 9,
  },
  chips: { flexDirection: "row", flexWrap: "wrap", gap: 6, marginBottom: 15 },
  chip: {
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
  },
  smallLink: {
    color: "#338367",
    fontSize: 12,
    fontWeight: "600",
    marginTop: 12,
  },
});
