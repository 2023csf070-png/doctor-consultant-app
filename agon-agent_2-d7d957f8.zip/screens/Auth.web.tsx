import React, { useState } from "react";
import { api } from "../lib/api";
import {
  Button,
  ErrorBox,
  Eyebrow,
  Field,
  Icon,
  Link,
  Notice,
  useClinic,
} from "../components/UI.web";
function Password({
  name = "password",
  fresh = false,
}: {
  name?: string;
  fresh?: boolean;
}) {
  const [show, setShow] = useState(false);
  return (
    <div className="password-input">
      <input
        name={name}
        type={show ? "text" : "password"}
        autoComplete={fresh ? "new-password" : "current-password"}
        required
        minLength={fresh ? 12 : 1}
        maxLength={128}
        placeholder={fresh ? "At least 12 characters" : "Enter your password"}
      />
      <button
        type="button"
        aria-label={show ? "Hide password" : "Show password"}
        onClick={() => setShow(!show)}
      >
        <Icon name={show ? "hidden" : "eye"} size={17} />
      </button>
    </div>
  );
}
export function Auth({
  kind,
  doctor = false,
}: {
  kind: "login" | "signup" | "forgot" | "reset";
  doctor?: boolean;
}) {
  const { path, go, onAuth, preview, toast } = useClinic();
  const query = new URLSearchParams(path.split("?")[1]),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [message, setMessage] = useState("");
  const role = doctor || query.get("role") === "doctor" ? "doctor" : "patient";
  const returnTo = query.get("next") || "";
  const next =
    returnTo.startsWith("/") && !returnTo.startsWith("//")
      ? returnTo
      : "/" + role + "/dashboard";
  const suffix = "?next=" + encodeURIComponent(next);
  const title =
    kind === "signup"
      ? "Create your patient account"
      : kind === "forgot"
        ? "Recover your account"
        : kind === "reset"
          ? "Choose a new password"
          : role === "doctor"
            ? "Doctor sign in"
            : "Welcome back";
  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError("");
    setBusy(true);
    const form = Object.fromEntries(new FormData(e.currentTarget)) as any;
    try {
      if (kind === "login") {
        const result = await api("login", { ...form, role });
        onAuth(result.user, result.csrf);
        go(next);
      } else if (kind === "signup") {
        await api("signup", { ...form, consent: form.consent === "on" });
        toast("Account created. Sign in to your patient portal.");
        go("/patient/login" + suffix);
      } else if (kind === "forgot") {
        const r = await api("forgot", { ...form, role });
        setMessage(r.message);
      } else {
        const r = await api("reset", {
          ...form,
          token: window.location.hash.slice(1),
        });
        window.history.replaceState({}, "", window.location.pathname);
        setMessage(r.message);
      }
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <main className={"auth-page " + (kind === "signup" ? "signup-page" : "")}>
      <div className="auth-wrap">
        <Link to="/" className="back-link">
          <Icon name="back" size={15} />
          Back to clinic
        </Link>
        <div className="auth-card">
          <div className="auth-symbol">
            <Icon
              name={
                role === "doctor"
                  ? "stethoscope"
                  : kind === "forgot" || kind === "reset"
                    ? "key"
                    : "shield"
              }
              size={29}
            />
          </div>
          <Eyebrow>
            {role === "doctor"
              ? "AUTHORISED CLINIC ACCESS"
              : "PRIVATE PATIENT PORTAL"}
          </Eyebrow>
          <h1>{title}</h1>
          <p className="auth-subtitle">
            {kind === "signup"
              ? "A private account for your appointments, reports, and ongoing care."
              : kind === "login"
                ? role === "doctor"
                  ? "Sign in to the clinical workspace for Dr. Faisal Jhandir."
                  : "Sign in to manage your appointments and medical records."
                : kind === "forgot"
                  ? "Enter the email address registered with your clinic account."
                  : "Use the private recovery link sent to your email."}
          </p>
          {preview && (
            <div className="preview-note">
              <Icon name="info" size={15} />
              Preview workspace. Use sample details only; storage is temporary.
            </div>
          )}
          {message ? (
            <>
              <Notice icon="success">{message}</Notice>
              <Button to={"/" + role + "/login" + suffix} end="arrow">
                Return to sign in
              </Button>
            </>
          ) : (
            <form
              onSubmit={submit}
              className={kind === "signup" ? "form-grid" : "form-stack"}
            >
              {kind === "signup" && (
                <>
                  <div className="form-divider field-wide">
                    <span>01</span>Personal details
                  </div>
                  <Field label="Full name">
                    <input
                      name="name"
                      autoComplete="name"
                      required
                      maxLength={100}
                      placeholder="As shown on your CNIC"
                    />
                  </Field>
                  <Field label="Father / husband name">
                    <input
                      name="father_name"
                      required
                      maxLength={100}
                      placeholder="Full name"
                    />
                  </Field>
                  <Field label="CNIC" hint="13 digits, with or without dashes">
                    <input
                      name="cnic"
                      inputMode="numeric"
                      required
                      pattern="[0-9\- ]{13,17}"
                      maxLength={17}
                      placeholder="XXXXX-XXXXXXX-X"
                    />
                  </Field>
                  <Field label="Date of birth">
                    <input
                      name="dob"
                      type="date"
                      autoComplete="bday"
                      min="1900-01-01"
                      max={new Date().toISOString().slice(0, 10)}
                      required
                    />
                  </Field>
                  <Field label="Gender">
                    <select name="gender" required defaultValue="">
                      <option value="" disabled>
                        Select gender
                      </option>
                      {["Male", "Female", "Other", "Prefer not to say"].map(
                        (x) => (
                          <option key={x}>{x}</option>
                        ),
                      )}
                    </select>
                  </Field>
                  <Field label="Mobile number">
                    <input
                      name="phone"
                      type="tel"
                      autoComplete="tel"
                      required
                      maxLength={18}
                      placeholder="03XX XXXXXXX"
                    />
                  </Field>
                  <Field label="Address">
                    <input
                      name="address"
                      autoComplete="street-address"
                      required
                      maxLength={450}
                      placeholder="House, street, and area"
                    />
                  </Field>
                  <Field label="City">
                    <input
                      name="city"
                      autoComplete="address-level2"
                      required
                      maxLength={80}
                      placeholder="City"
                    />
                  </Field>
                  <div className="form-divider field-wide">
                    <span>02</span>Account security
                  </div>
                </>
              )}
              {(kind === "signup" || kind === "forgot") && (
                <Field label="Email address" wide>
                  <input
                    type="email"
                    name="email"
                    autoComplete="email"
                    required
                    maxLength={180}
                    placeholder="you@example.com"
                  />
                </Field>
              )}
              {kind === "login" && (
                <Field
                  label={
                    role === "doctor"
                      ? "Email or username"
                      : "Email or mobile number"
                  }
                >
                  <input
                    name="identifier"
                    required
                    autoComplete="username"
                    maxLength={180}
                    placeholder={
                      role === "doctor"
                        ? "Enter your email or username"
                        : "Enter email or mobile number"
                    }
                  />
                </Field>
              )}
              {kind !== "forgot" && (
                <Field label={kind === "reset" ? "New password" : "Password"}>
                  <Password fresh={kind !== "login"} />
                </Field>
              )}
              {(kind === "signup" || kind === "reset") && (
                <Field label="Confirm password">
                  <Password name="confirmation" fresh />
                </Field>
              )}
              {kind === "login" && role === "doctor" && (
                <Field label="Authenticator code (if enabled)">
                  <input
                    name="otp"
                    inputMode="numeric"
                    pattern="[0-9]{6}"
                    maxLength={6}
                    autoComplete="one-time-code"
                    placeholder="Six-digit code"
                  />
                </Field>
              )}
              {kind === "login" && (
                <div className="forgot-row">
                  <Link to={"/forgot-password?role=" + role}>
                    Forgot password?
                  </Link>
                </div>
              )}
              {kind === "signup" && (
                <label className="consent field-wide">
                  <input name="consent" type="checkbox" required />
                  <span>
                    I consent to the clinic storing my details for care and have
                    read the <Link to="/privacy">Privacy Policy</Link> and{" "}
                    <Link to="/terms">Terms & Conditions</Link>.
                  </span>
                </label>
              )}
              <div className="field-wide">
                <ErrorBox message={error} />
                <Button type="submit" busy={busy} end="arrow" className="full">
                  {kind === "signup"
                    ? "Create patient account"
                    : kind === "forgot"
                      ? "Request reset link"
                      : kind === "reset"
                        ? "Update password"
                        : "Sign in securely"}
                </Button>
              </div>
            </form>
          )}
          {role === "patient" && (kind === "login" || kind === "signup") && (
            <p className="auth-switch">
              {kind === "signup" ? "Already registered?" : "New to the clinic?"}{" "}
              <Link
                to={
                  (kind === "signup" ? "/patient/login" : "/patient/signup") +
                  suffix
                }
              >
                {kind === "signup" ? "Sign in" : "Create an account"}
              </Link>
            </p>
          )}
          {kind === "forgot" && (
            <p className="auth-switch">
              <Link to={"/" + role + "/login"}>Back to sign in</Link>
            </p>
          )}
          <div className="secure-caption">
            <Icon name="lock" size={13} />
            Private, role-protected access
          </div>
        </div>
      </div>
    </main>
  );
}
