import React, { useState } from "react";
import { api, dateLabel, pkToday } from "../lib/api";
import {
  Badge,
  Button,
  Empty,
  ErrorBox,
  Field,
  Icon,
  Loading,
  LoadError,
  Modal,
  Notice,
  useClinic,
  useLoad,
} from "../components/UI.web";
import { ReportUpload } from "../components/Upload.web";
const blankMed = () => ({
  medicine: "",
  dosage: "",
  frequency: "",
  duration: "",
  instructions: "",
});
function PrescriptionForm({
  pid,
  onDone,
  visit,
}: {
  pid: string;
  onDone: () => void;
  visit?: string;
}) {
  const [items, setItems] = useState([blankMed()]),
    [err, setErr] = useState(""),
    [busy, setBusy] = useState(false);
  return (
    <form
      className="form-stack"
      onSubmit={async (e) => {
        e.preventDefault();
        setBusy(true);
        setErr("");
        const b = Object.fromEntries(new FormData(e.currentTarget));
        try {
          await api("prescription.save", {
            ...b,
            patient_id: pid,
            appointment_id: visit || null,
            items,
          });
          onDone();
        } catch (e: any) {
          setErr(e.message);
        } finally {
          setBusy(false);
        }
      }}
    >
      <Notice icon="stethoscope">
        Clinical authoring is restricted to the authorised doctor. No medicines
        are suggested or prescribed by AI.
      </Notice>
      <Field label="Diagnosis / clinical impression">
        <textarea name="diagnosis" rows={2} maxLength={2000} required />
      </Field>
      {items.map((m, i) => (
        <div className="medicine-box" key={i}>
          <div className="form-section-title">
            <h3>Medicine {i + 1}</h3>
            {items.length > 1 && (
              <button
                className="icon-btn"
                type="button"
                aria-label={"Remove medicine " + (i + 1)}
                onClick={() => setItems(items.filter((_, n) => n !== i))}
              >
                <Icon name="trash" size={16} />
              </button>
            )}
          </div>
          <div className="form-grid">
            {Object.keys(m).map((k) => (
              <Field
                label={
                  k === "medicine"
                    ? "Medicine name"
                    : k[0].toUpperCase() + k.slice(1)
                }
                key={k}
                wide={k === "medicine"}
              >
                <input
                  value={m[k as keyof typeof m]}
                  maxLength={k === "instructions" ? 500 : 120}
                  required={k !== "instructions"}
                  onChange={(e) =>
                    setItems(
                      items.map((a, n) =>
                        n === i ? { ...a, [k]: e.target.value } : a,
                      ),
                    )
                  }
                />
              </Field>
            ))}
          </div>
        </div>
      ))}
      <Button
        kind="quiet"
        icon="plus"
        onClick={() => setItems([...items, blankMed()])}
        disabled={items.length >= 30}
      >
        Add medicine
      </Button>
      <Field label="Follow-up date (optional)">
        <input type="date" name="followup" min={pkToday()} />
      </Field>
      <Field label="Additional notes (optional)">
        <textarea name="notes" rows={2} maxLength={3000} />
      </Field>
      <ErrorBox message={err} />
      <Button type="submit" busy={busy} icon="prescription">
        Save prescription
      </Button>
    </form>
  );
}
function Prescription({ rx, patient }: { rx: any; patient: any }) {
  return (
    <>
      <article className="print-prescription">
        <div className="rx-brand">
          <span className="service-icon mint">
            <Icon name="stethoscope" size={29} />
          </span>
          <div>
            <h2>Bashir Alam Clinic</h2>
            <p>Dr. Faisal Jhandir · Multan, Pakistan</p>
          </div>
        </div>
        <div className="rx-meta">
          <div>
            <small>PATIENT</small>
            <strong>{patient.name}</strong>
            <span>
              P-{patient.id.slice(0, 8).toUpperCase()} · {patient.gender}
            </span>
          </div>
          <div>
            <small>PRESCRIPTION DATE</small>
            <strong>{dateLabel(rx.created_at, true)}</strong>
          </div>
        </div>
        <div className="rx-section">
          <small>CLINICAL IMPRESSION</small>
          <p>{rx.diagnosis}</p>
        </div>
        <h3 className="rx-symbol">
          ℞ <span>Prescribed medicines</span>
        </h3>
        {rx.items.map((m: any, i: number) => (
          <div className="rx-med" key={i}>
            <strong>
              {i + 1}. {m.medicine}
            </strong>
            <p>
              {m.dosage} · {m.frequency} · {m.duration}
            </p>
            {m.instructions && <p>{m.instructions}</p>}
          </div>
        ))}
        {rx.notes && (
          <div className="rx-section">
            <small>DOCTOR’S NOTES</small>
            <p>{rx.notes}</p>
          </div>
        )}
        {rx.followup && (
          <div className="rx-section">
            <small>FOLLOW-UP</small>
            <p>{dateLabel(rx.followup)}</p>
          </div>
        )}
        <div className="rx-foot">
          Issued by Dr. Faisal Jhandir · 0302 0460461
          <br />
          Near MDA Officers Cooperative Housing Society, Multan
        </div>
      </article>
      <Button icon="print" onClick={() => window.print()}>
        Print / save PDF
      </Button>
    </>
  );
}
export function RecordView({
  pid,
  tab,
  visit,
  onProfileSave,
}: {
  pid: string;
  tab: string;
  visit?: string;
  onProfileSave?: () => void;
}) {
  const { user, toast } = useClinic(),
    {
      data: d,
      error,
      loading,
      refresh,
    } = useLoad("patient.record", { id: pid }, true, tab);
  const [modal, setModal] = useState(""),
    [selected, setSelected] = useState<any>(null),
    [err, setErr] = useState(""),
    [busy, setBusy] = useState(false);
  const doctor = user?.role === "doctor";
  const done = (s: string) => {
    setModal("");
    setSelected(null);
    toast(s);
    refresh();
    onProfileSave?.();
  };
  if (loading) return <Loading label="Opening private patient record…" />;
  if (error) return <LoadError error={error} retry={refresh} />;
  if (!d) return null;
  const p = d.profile;
  const open = (m: string, s: any = null) => {
    setErr("");
    setModal(m);
    setSelected(s);
  };
  const save = async (e: React.FormEvent<HTMLFormElement>, op: string) => {
    e.preventDefault();
    setErr("");
    setBusy(true);
    const b = Object.fromEntries(new FormData(e.currentTarget));
    try {
      await api(op, {
        ...b,
        patient_id: pid,
        appointment_id: visit || null,
        report_id: modal === "report-note" ? selected?.id : null,
        ...(op === "payment.request"
          ? { amount_minor: Math.round(Number(b.amount) * 100) }
          : {}),
      });
      done("Saved to the patient record.");
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
      <div className="record-content">
        {(tab === "My profile" || tab === "Profile") && (
          <>
            <div className="profile-banner">
              <span className="avatar big">
                {p.name
                  .split(" ")
                  .slice(0, 2)
                  .map((s: string) => s[0])
                  .join("")}
              </span>
              <div>
                <h2>{p.name}</h2>
                <p>Patient ID · P-{p.id.slice(0, 8).toUpperCase()}</p>
              </div>
              {!doctor && (
                <Button kind="secondary" onClick={() => open("profile")}>
                  Edit profile
                </Button>
              )}
            </div>
            <div className="panel">
              <h3>Personal details</h3>
              <div className="detail-grid">
                {[
                  ["Full name", p.name],
                  ["Father / husband name", p.father_name],
                  ["CNIC", p.cnic],
                  ["Date of birth", dateLabel(p.dob)],
                  ["Gender", p.gender],
                  ["Phone number", p.phone],
                  ["Email address", p.email],
                  ["City", p.city],
                  ["Address", p.address],
                ].map(([k, v]) => (
                  <div key={k}>
                    <small>{k}</small>
                    <strong>{v}</strong>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
        {tab === "Medical records" && (
          <>
            <div className="content-head">
              <div>
                <h2>Clinical timeline</h2>
                <p>
                  History, allergies, medicines, and notes recorded by your
                  doctor.
                </p>
              </div>
              {doctor && (
                <Button icon="plus" onClick={() => open("record")}>
                  Add record
                </Button>
              )}
            </div>
            {doctor && (
              <div className="mini-toolbar">
                <Button
                  kind="secondary"
                  icon="file"
                  onClick={() => open("note")}
                >
                  Add doctor note
                </Button>
                {visit && (
                  <Button kind="secondary" onClick={() => open("consultation")}>
                    Consultation summary
                  </Button>
                )}
              </div>
            )}
            {!d.records.length && !d.notes.length && !d.consultations.length ? (
              <Empty title="No clinical entries yet" icon="records">
                Your doctor’s clinical entries and consultation summaries will
                appear here.
              </Empty>
            ) : (
              <div className="timeline">
                {[
                  ...d.records.map((r: any) => ({
                    ...r,
                    title: r.category,
                    body: r.content,
                  })),
                  ...d.notes.map((r: any) => ({
                    ...r,
                    title: r.report_id ? "Report response" : "Doctor’s note",
                  })),
                  ...d.consultations.map((r: any) => ({
                    ...r,
                    title: "Consultation summary",
                    body: r.impression,
                  })),
                ]
                  .sort((a, b) => b.created_at.localeCompare(a.created_at))
                  .map((r) => (
                    <article className="timeline-entry" key={r.id}>
                      <span className="timeline-dot" />
                      <small>
                        {dateLabel(r.created_at, true)} · Dr. Faisal Jhandir
                      </small>
                      <h3>{r.title}</h3>
                      <p>{r.body}</p>
                      {r.followup && <p>Follow-up: {dateLabel(r.followup)}</p>}
                    </article>
                  ))}
              </div>
            )}
          </>
        )}
        {tab === "Prescriptions" && (
          <>
            <div className="content-head">
              <div>
                <h2>Prescriptions</h2>
                <p>Doctor-issued prescriptions and follow-up instructions.</p>
              </div>
              {doctor && (
                <Button icon="plus" onClick={() => open("rx")}>
                  New prescription
                </Button>
              )}
            </div>
            {d.prescriptions.length ? (
              d.prescriptions.map((r: any) => (
                <div className="record-row" key={r.id}>
                  <span className="service-icon mint">
                    <Icon name="prescription" />
                  </span>
                  <div>
                    <strong>
                      Prescription · {dateLabel(r.created_at, true)}
                    </strong>
                    <p>
                      Dr. Faisal Jhandir · {r.items.length} medicine item
                      {r.items.length !== 1 ? "s" : ""}
                    </p>
                  </div>
                  <Button kind="secondary" onClick={() => open("view-rx", r)}>
                    View prescription
                  </Button>
                </div>
              ))
            ) : (
              <Empty title="No prescriptions yet" icon="prescription">
                Prescriptions issued by Dr. Faisal Jhandir will be available
                here to view and print.
              </Empty>
            )}
          </>
        )}
        {tab === "Reports" && (
          <>
            <div className="content-head">
              <div>
                <h2>Medical reports</h2>
                <p>Private uploads and your doctor’s responses.</p>
              </div>
              <Button icon="upload" onClick={() => open("upload")}>
                Upload report
              </Button>
            </div>
            {d.reports.length ? (
              d.reports.map((r: any) => (
                <div className="report-card" key={r.id}>
                  <div className="record-row">
                    <span className="service-icon blue">
                      <Icon name="file" />
                    </span>
                    <div>
                      <strong>{r.filename}</strong>
                      <p>
                        {Math.ceil(r.size / 1024)} KB ·{" "}
                        {dateLabel(r.created_at, true)}
                      </p>
                    </div>
                    <a
                      className="icon-btn"
                      href={
                        "/api/clinic.v1?op=report.download&id=" +
                        encodeURIComponent(r.id)
                      }
                      aria-label={"Download " + r.filename}
                    >
                      <Icon name="download" />
                    </a>
                    {doctor && (
                      <button
                        className="text-link"
                        onClick={() => open("report-note", r)}
                      >
                        Add note
                      </button>
                    )}
                  </div>
                  {d.notes
                    .filter((n: any) => n.report_id === r.id)
                    .map((n: any) => (
                      <div className="report-reply" key={n.id}>
                        <strong>Dr. Faisal Jhandir</strong>
                        <p>{n.body}</p>
                      </div>
                    ))}
                </div>
              ))
            ) : (
              <Empty title="No reports uploaded" icon="upload">
                Upload a medical report to share it privately with your doctor.
              </Empty>
            )}
          </>
        )}
        {tab === "Payments" && (
          <>
            <div className="content-head">
              <div>
                <h2>Payments</h2>
                <p>Clinic payment requests and verified transaction status.</p>
              </div>
              {doctor && (
                <Button icon="plus" onClick={() => open("payment")}>
                  Payment request
                </Button>
              )}
            </div>
            {d.payments.length ? (
              d.payments.map((r: any) => (
                <div className="record-row" key={r.id}>
                  <span className="service-icon peach">
                    <Icon name="payment" />
                  </span>
                  <div>
                    <strong>
                      PKR {(r.amount_minor / 100).toLocaleString()}
                    </strong>
                    <p>
                      {r.provider} · {dateLabel(r.created_at, true)}
                    </p>
                  </div>
                  <Badge>{r.status}</Badge>
                  {r.status === "Pending" &&
                    r.provider === "Card" &&
                    d.cardEnabled &&
                    !doctor && (
                      <Button
                        busy={busy}
                        onClick={async () => {
                          setBusy(true);
                          try {
                            const result = await api("payment.checkout", {
                              id: r.id,
                            });
                            window.location.assign(result.url);
                          } catch (e: any) {
                            setErr(e.message);
                          } finally {
                            setBusy(false);
                          }
                        }}
                      >
                        Pay securely
                      </Button>
                    )}
                </div>
              ))
            ) : (
              <Empty icon="payment" title="No payment requests">
                Any payment requests from the clinic will appear here.
              </Empty>
            )}
            <Notice>
              JazzCash, Easypaisa, and bank transfer integrations are not
              connected.{" "}
              {d.cardEnabled
                ? "Card checkout is available for eligible requests."
                : "Card checkout is also inactive."}{" "}
              No payment is marked paid without verified provider confirmation.
            </Notice>
            <ErrorBox message={err} />
          </>
        )}
      </div>
      {modal && (
        <Modal
          title={
            (
              {
                profile: "Edit personal details",
                record: "Add clinical record",
                note: "Add doctor note",
                "report-note": "Respond to medical report",
                rx: "Create prescription",
                "view-rx": "Prescription details",
                upload: "Upload a private report",
                payment: "Create payment request",
                consultation: "Consultation summary",
              } as any
            )[modal]
          }
          onClose={() => !busy && setModal("")}
          wide={["rx", "view-rx"].includes(modal)}
        >
          {modal === "rx" ? (
            <PrescriptionForm
              pid={pid}
              visit={visit}
              onDone={() => done("Prescription saved and patient notified.")}
            />
          ) : modal === "view-rx" ? (
            <Prescription rx={selected} patient={p} />
          ) : modal === "upload" ? (
            <>
              <p className="modal-description">
                This report is accessible only to the patient and the authorised
                clinic doctor.
              </p>
              <ReportUpload
                patientId={pid}
                onDone={() => done("Report uploaded to the private record.")}
              />
            </>
          ) : (
            <form
              className="form-stack"
              onSubmit={(e) =>
                save(
                  e,
                  modal === "profile"
                    ? "profile.save"
                    : modal === "record"
                      ? "record.add"
                      : modal === "payment"
                        ? "payment.request"
                        : modal === "consultation"
                          ? "consultation.save"
                          : "note.add",
                )
              }
            >
              {modal === "profile" ? (
                <>
                  {[
                    ["Full name", "name"],
                    ["Phone number", "phone"],
                    ["City", "city"],
                    ["Address", "address"],
                  ].map(([l, k]) => (
                    <Field label={l} key={k}>
                      <input
                        name={k}
                        defaultValue={p[k]}
                        required
                        maxLength={k === "address" ? 450 : 100}
                      />
                    </Field>
                  ))}
                  <Notice>
                    Identity and clinical details are not editable here. Contact
                    the clinic for corrections.
                  </Notice>
                </>
              ) : modal === "payment" ? (
                <>
                  <Field label="Amount (PKR)">
                    <input
                      name="amount"
                      type="number"
                      min="1"
                      max="1000000"
                      step="0.01"
                      required
                    />
                  </Field>
                  <Field label="Payment method">
                    <select name="provider">
                      {["Card", "JazzCash", "Easypaisa", "Bank transfer"].map(
                        (x) => (
                          <option key={x}>{x}</option>
                        ),
                      )}
                    </select>
                  </Field>
                  <Notice>
                    This creates a pending request only. It does not collect a
                    payment.
                  </Notice>
                </>
              ) : (
                <>
                  {modal === "record" && (
                    <Field label="Record category">
                      <select name="category">
                        {[
                          "Medical history",
                          "Allergies",
                          "Current medicines",
                          "Conditions",
                          "Clinical impression",
                        ].map((x) => (
                          <option key={x}>{x}</option>
                        ))}
                      </select>
                    </Field>
                  )}
                  {modal === "report-note" && (
                    <Notice>Report: {selected.filename}</Notice>
                  )}
                  <Field
                    label={
                      modal === "consultation"
                        ? "Clinical impression"
                        : "Clinical note"
                    }
                  >
                    <textarea
                      name="content"
                      rows={5}
                      maxLength={6000}
                      required
                    />
                  </Field>
                  {modal === "consultation" && (
                    <Field label="Follow-up date (optional)">
                      <input type="date" name="followup" min={pkToday()} />
                    </Field>
                  )}
                </>
              )}
              <ErrorBox message={err} />
              <Button type="submit" busy={busy} icon="check">
                Save {modal === "profile" ? "changes" : "to record"}
              </Button>
            </form>
          )}
        </Modal>
      )}
    </>
  );
}
export function Education({ aiEnabled = false }: { aiEnabled?: boolean }) {
  const [useAI, setUseAI] = useState(false);
  const [question, setQuestion] = useState(""),
    [items, setItems] = useState<any[]>([]),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  async function ask(q: string) {
    if (!q.trim() || busy) return;
    setBusy(true);
    setError("");
    try {
      const r = await api("education", { question: q, ai_consent: useAI });
      setItems((a) => [...a, { q, ...r }]);
      setQuestion("");
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="education-panel">
      <span className="service-icon purple">
        <Icon name="education" size={28} />
      </span>
      <h2>AI Health Assistant</h2>
      <p className="prose">
        Explore health terms and prepare for your care. This workspace uses
        curated educational answers, not a diagnostic model.
      </p>
      {aiEnabled && (
        <label className="consent">
          <input
            type="checkbox"
            checked={useAI}
            onChange={(e) => setUseAI(e.target.checked)}
          />
          <span>
            Allow the connected AI provider to match my question to an
            educational topic. Only this question is sent, never my records or
            profile. Do not include identifying details.
          </span>
        </label>
      )}
      <div className="education-hints">
        {[
          "How do I read a lab report?",
          "How should I prepare for a visit?",
          "What does a prescription label mean?",
        ].map((s) => (
          <button onClick={() => ask(s)} disabled={busy} key={s}>
            {s}
            <Icon name="arrow" size={14} />
          </button>
        ))}
      </div>
      <div aria-live="polite">
        {items.map((a, i) => (
          <div className="chat-pair" key={i}>
            <div className="question">{a.q}</div>
            <div className="answer">
              <small>
                <Icon name="education" size={14} />
                {a.mode}
              </small>
              <p>{a.answer}</p>
              <aside>{a.disclaimer}</aside>
            </div>
          </div>
        ))}
      </div>
      <form
        className="ask-form"
        onSubmit={(e) => {
          e.preventDefault();
          ask(question);
        }}
      >
        <input
          required
          value={question}
          maxLength={800}
          onChange={(e) => setQuestion(e.target.value)}
          aria-label="General health education question"
          placeholder="Ask a general health question…"
        />
        <Button type="submit" busy={busy} icon="send">
          Ask
        </Button>
      </form>
      <ErrorBox message={error} />
      <p className="small-muted">
        For emergencies, seek immediate local emergency medical care. Do not
        include personal identifiers in your question.
      </p>
    </div>
  );
}
