import React, { useEffect, useState } from "react";
import { api, dateLabel, pkToday, timeLabel } from "../lib/api";
import {
  Badge,
  Button,
  Empty,
  ErrorBox,
  Eyebrow,
  Field,
  Icon,
  Link,
  Loading,
  LoadError,
  Modal,
  Notice,
  useClinic,
  useLoad,
} from "../components/UI.web";
import { SlotPicker } from "./Booking.web";
import { Education, RecordView } from "./Records.web";
import { Availability, ServiceEditor } from "./DoctorSettings.web";
const patientNav = [
  ["Overview", "dashboard"],
  ["Appointments", "calendar"],
  ["Online visits", "video"],
  ["My profile", "user"],
  ["Medical records", "records"],
  ["Prescriptions", "prescription"],
  ["Reports", "file"],
  ["Payments", "payment"],
  ["Health assistant", "education"],
  ["Notifications", "bell"],
];
const doctorNav = [
  ["Overview", "dashboard"],
  ["Appointments", "calendar"],
  ["Online visits", "video"],
  ["Patients", "patients"],
  ["Availability", "schedule"],
  ["Service content", "layers"],
  ["Notifications", "bell"],
];
function VisitDetail({
  a,
  onClose,
  refresh,
  zoomEnabled,
}: {
  a: any;
  onClose: () => void;
  refresh: () => void;
  zoomEnabled: boolean;
}) {
  const { user, toast, go } = useClinic(),
    doc = user?.role === "doctor";
  const [mode, setMode] = useState("view"),
    [day, setDay] = useState(a.day < pkToday() ? pkToday() : a.day),
    [time, setTime] = useState<number | null>(null),
    [busy, setBusy] = useState(false),
    [err, setErr] = useState("");
  const update = async (b: any, op = "appointment.change") => {
    setErr("");
    setBusy(true);
    try {
      await api(op, { ...b, id: a.id });
      toast(
        op === "zoom.create"
          ? "Online meeting prepared."
          : "Appointment updated.",
      );
      onClose();
      refresh();
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };
  const active = ["Pending", "Confirmed"].includes(a.status);
  return (
    <Modal
      title={
        mode === "cancel"
          ? "Cancel this appointment?"
          : mode === "schedule"
            ? "Reschedule appointment"
            : a.type
      }
      onClose={() => !busy && onClose()}
    >
      {mode === "view" ? (
        <>
          <div className="appointment-ref">
            <span>{a.reference}</span>
            <Badge>{a.status}</Badge>
          </div>
          <div className="detail-grid">
            <div>
              <small>Patient</small>
              <strong>{a.patient_name}</strong>
            </div>
            <div>
              <small>Doctor</small>
              <strong>Dr. Faisal Jhandir</strong>
            </div>
            <div>
              <small>Date</small>
              <strong>{dateLabel(a.day, true)}</strong>
            </div>
            <div>
              <small>Time · PKT</small>
              <strong>
                {timeLabel(a.start_min)} · {a.duration} min
              </strong>
            </div>
          </div>
          <div className="note-box">
            <small>REASON FOR VISIT</small>
            <p>{a.reason}</p>
          </div>
          {a.type === "Online Video Consultation" &&
            a.status === "Confirmed" && (
              <div className="online-status">
                {a.has_zoom ? (
                  <Button
                    icon="video"
                    busy={busy}
                    onClick={async () => {
                      setBusy(true);
                      try {
                        const r = await api("zoom.join", undefined, {
                          id: a.id,
                        });
                        window.location.assign(r.url);
                      } catch (e: any) {
                        setErr(e.message);
                      } finally {
                        setBusy(false);
                      }
                    }}
                  >
                    Join Online Consultation
                  </Button>
                ) : doc && zoomEnabled ? (
                  <Button
                    icon="video"
                    busy={busy}
                    onClick={() => update({}, "zoom.create")}
                  >
                    Prepare Zoom meeting
                  </Button>
                ) : (
                  <Notice icon="video">
                    {doc
                      ? "Zoom is not connected. Configure the provider before preparing a meeting."
                      : "Your meeting details will appear after the clinic prepares your video visit."}
                  </Notice>
                )}
              </div>
            )}
          <div className="action-wrap">
            {doc && a.status === "Pending" && (
              <Button
                busy={busy}
                icon="check"
                onClick={() => update({ status: "Confirmed" })}
              >
                Confirm visit
              </Button>
            )}
            {doc && a.status === "Confirmed" && (
              <Button
                busy={busy}
                icon="check"
                onClick={() => update({ status: "Completed" })}
              >
                Complete visit
              </Button>
            )}
            {doc && (
              <Button
                kind="secondary"
                icon="records"
                onClick={() =>
                  go(
                    "/doctor/dashboard?tab=Patient%20record&id=" +
                      a.patient_id +
                      "&visit=" +
                      a.id,
                  )
                }
              >
                Patient record
              </Button>
            )}
            {active && (
              <Button
                kind="secondary"
                icon="calendar"
                onClick={() => {
                  setErr("");
                  setMode("schedule");
                }}
              >
                Reschedule
              </Button>
            )}
            {active && (
              <button
                className="danger-link"
                onClick={() => {
                  setErr("");
                  setMode("cancel");
                }}
              >
                {doc && a.status === "Pending"
                  ? "Decline request"
                  : "Cancel appointment"}
              </button>
            )}
          </div>
        </>
      ) : mode === "cancel" ? (
        <>
          <p className="modal-description">
            This will cancel {a.reference} on {dateLabel(a.day, true)} at{" "}
            {timeLabel(a.start_min)} and release the time slot.
          </p>
          <div className="button-row">
            <Button
              kind="danger"
              busy={busy}
              onClick={() => update({ status: "Cancelled" })}
            >
              Yes, cancel visit
            </Button>
            <Button kind="secondary" onClick={() => setMode("view")}>
              Keep appointment
            </Button>
          </div>
        </>
      ) : (
        <>
          <SlotPicker day={day} setDay={setDay} time={time} setTime={setTime} />
          <Button
            busy={busy}
            disabled={time === null}
            onClick={() =>
              update({ action: "reschedule", day, start_min: time })
            }
          >
            Save new time
          </Button>
        </>
      )}
      <ErrorBox message={err} />
    </Modal>
  );
}
function CalendarView({
  visits,
  onVisit,
  month,
  setMonth,
}: {
  visits: any[];
  onVisit: (a: any) => void;
  month: string;
  setMonth: (s: string) => void;
}) {
  const [sel, setSel] = useState(
    month === pkToday().slice(0, 7) ? pkToday() : month + "-01",
  );
  const first = new Date(month + "-01T12:00:00Z"),
    offset = first.getUTCDay(),
    len = new Date(
      Date.UTC(first.getUTCFullYear(), first.getUTCMonth() + 1, 0),
    ).getUTCDate();
  const shift = (n: number) => {
    const d = new Date(first);
    d.setUTCMonth(d.getUTCMonth() + n);
    setMonth(d.toISOString().slice(0, 7));
  };
  return (
    <div className="panel calendar-panel">
      <div className="form-section-title">
        <h3>
          {first.toLocaleDateString("en-GB", {
            month: "long",
            year: "numeric",
          })}
        </h3>
        <div className="button-row">
          <button
            aria-label="Previous month"
            className="icon-btn"
            onClick={() => shift(-1)}
          >
            <Icon name="left" size={17} />
          </button>
          <button
            aria-label="Next month"
            className="icon-btn"
            onClick={() => shift(1)}
          >
            <Icon name="right" size={17} />
          </button>
        </div>
      </div>
      <div className="calendar-grid">
        {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((x) => (
          <small key={x}>{x}</small>
        ))}
        {Array.from({ length: offset }, (_, i) => (
          <span key={"blank" + i} />
        ))}
        {Array.from({ length: len }, (_, i) => {
          const d = month + "-" + String(i + 1).padStart(2, "0");
          return (
            <button
              key={d}
              className={sel === d ? "chosen" : ""}
              onClick={() => setSel(d)}
            >
              {i + 1}
              {visits.some((x) => x.day === d) && <i />}
            </button>
          );
        })}
      </div>
      <h3>{dateLabel(sel, true)}</h3>
      {visits
        .filter((a) => a.day === sel)
        .map((a) => (
          <button
            className="calendar-visit"
            onClick={() => onVisit(a)}
            key={a.id}
          >
            {timeLabel(a.start_min)} · {a.patient_name}
            <Badge>{a.status}</Badge>
          </button>
        ))}
      {!visits.some((a) => a.day === sel) && (
        <p className="muted">No visits on this date.</p>
      )}
    </div>
  );
}
function VisitList({
  visits,
  onVisit,
  compact = false,
}: {
  visits: any[];
  onVisit: (a: any) => void;
  compact?: boolean;
}) {
  const { user } = useClinic();
  return visits.length ? (
    <div className="visit-list">
      {visits.map((a) => (
        <button className="visit-row" key={a.id} onClick={() => onVisit(a)}>
          <div className="date-tile">
            <small>
              {new Date(a.day + "T12:00:00Z").toLocaleDateString("en-GB", {
                month: "short",
              })}
            </small>
            <b>{a.day.slice(8)}</b>
          </div>
          <div className="visit-title">
            <strong>{user?.role === "doctor" ? a.patient_name : a.type}</strong>
            <span>
              {user?.role === "doctor" ? a.type : "Dr. Faisal Jhandir"}
            </span>
          </div>
          <div className="visit-time">
            <Icon name="clock" size={14} />
            {timeLabel(a.start_min)}
            <small>PKT</small>
          </div>
          <Badge>{a.status}</Badge>
          <Icon name="right" size={16} />
        </button>
      ))}
    </div>
  ) : (
    <Empty
      icon="calendar"
      title={compact ? "No upcoming appointments" : "No appointments found"}
    >
      {compact
        ? "Choose an available time for your next clinic or online visit."
        : "Appointments matching this view will appear here."}
    </Empty>
  );
}
function PatientDirectory() {
  const { go } = useClinic(),
    [term, setTerm] = useState(""),
    [search, setSearch] = useState("");
  useEffect(() => {
    const t = setTimeout(() => setSearch(term), 220);
    return () => clearTimeout(t);
  }, [term]);
  const { data, loading, error, refresh } = useLoad("patients", { search });
  return (
    <>
      <div className="content-head">
        <div>
          <h2>Patient directory</h2>
          <p>Search the patients assigned to your clinic.</p>
        </div>
      </div>
      <label className="search wide-search">
        <Icon name="search" size={17} />
        <input
          value={term}
          onChange={(e) => setTerm(e.target.value)}
          placeholder="Search by name, phone, CNIC, or patient ID"
          aria-label="Search patients"
        />
      </label>
      {loading ? (
        <Loading />
      ) : error ? (
        <LoadError error={error} retry={refresh} />
      ) : data?.patients.length ? (
        data.patients.map((p: any) => (
          <button
            key={p.id}
            className="patient-row"
            onClick={() =>
              go("/doctor/dashboard?tab=Patient%20record&id=" + p.id)
            }
          >
            <span className="avatar">{p.name.slice(0, 1)}</span>
            <div>
              <strong>{p.name}</strong>
              <small>
                P-{p.id.slice(0, 8).toUpperCase()} · {p.phone}
              </small>
            </div>
            <span>{p.city}</span>
            <Icon name="right" size={17} />
          </button>
        ))
      ) : (
        <Empty title="No matching patients" icon="patients">
          Registered patients appear here. Try a different search.
        </Empty>
      )}
    </>
  );
}
export function Dashboard() {
  const { user, path, go, onAuth, toast, preview } = useClinic();
  const doc = user!.role === "doctor",
    params = new URLSearchParams(path.split("?")[1]),
    tab = params.get("tab") || "Overview",
    pid = params.get("id") || "",
    visit = params.get("visit") || undefined;
  const nav = doc ? doctorNav : patientNav;
  const [page, setPage] = useState(0),
    [month, setMonth] = useState(pkToday().slice(0, 7));
  const [selected, setSelected] = useState<any>(null),
    [filter, setFilter] = useState("All statuses"),
    [view, setView] = useState("list"),
    [sub, setSub] = useState("Profile"),
    [busy, setBusy] = useState(false),
    [actError, setActError] = useState("");
  const listTab = tab === "Appointments" || tab === "Online visits";
  const {
    data: d,
    error,
    loading,
    refresh,
  } = useLoad(
    "dashboard",
    {
      page: String(page),
      status: listTab ? filter : "",
      online: tab === "Online visits" ? "1" : "0",
      scope: tab === "Overview" ? "upcoming" : "all",
      month: listTab && view === "calendar" ? month : "",
      patient: doc && tab === "Patient record" ? pid : "",
    },
    true,
    tab,
  );
  const goto = (t: string) =>
    go("/" + user!.role + "/dashboard?tab=" + encodeURIComponent(t));
  useEffect(() => {
    setFilter("All statuses");
    setPage(0);
    setSelected(null);
    setActError("");
  }, [tab]);
  const signout = async () => {
    setBusy(true);
    try {
      await api("logout", {});
      onAuth(null);
      go("/");
      toast("You have been signed out.");
    } catch (e: any) {
      setActError(e.message);
    } finally {
      setBusy(false);
    }
  };
  const visits = d?.appointments || [],
    unread = d?.unread || 0,
    upcoming = visits
      .filter(
        (a: any) =>
          a.day >= pkToday() && ["Pending", "Confirmed"].includes(a.status),
      )
      .sort(
        (a: any, b: any) =>
          a.day.localeCompare(b.day) || a.start_min - b.start_min,
      );
  const title =
    tab === "Overview" ? (doc ? "Clinic overview" : "Your care overview") : tab;
  return (
    <div className="workspace">
      <aside className="sidebar">
        <div className="workspace-label">
          <span className="online-dot" />
          {doc ? "DOCTOR WORKSPACE" : "PATIENT WORKSPACE"}
        </div>
        <div className="sidebar-profile">
          <span className="avatar">
            {user!.name
              .split(" ")
              .slice(0, 2)
              .map((s) => s[0])
              .join("")}
          </span>
          <div>
            <strong>{user!.name}</strong>
            <small>{doc ? "Clinic doctor" : "Patient account"}</small>
          </div>
        </div>
        <nav aria-label="Workspace navigation">
          {nav.map(([x, i]) => (
            <button
              key={x}
              className={
                tab === x || (tab === "Patient record" && x === "Patients")
                  ? "active"
                  : ""
              }
              onClick={() => goto(x)}
            >
              <Icon name={i} size={18} />
              {x}
              {x === "Notifications" && unread > 0 && <i>{unread}</i>}
            </button>
          ))}
        </nav>
        <button className="signout" onClick={signout} disabled={busy}>
          <Icon name="logout" size={17} />
          Sign out
        </button>
      </aside>
      <main className="dash-main">
        <div className="dash-title">
          <div>
            <Eyebrow>{doc ? "CLINIC MANAGEMENT" : "PATIENT PORTAL"}</Eyebrow>
            <h1>{title}</h1>
            {tab === "Overview" && (
              <p>
                {doc
                  ? "Appointments, requests, and patient care in one place."
                  : "Your appointments, documents, and health updates in one place."}
              </p>
            )}
          </div>
          <button
            className="icon-btn"
            aria-label="Refresh workspace"
            onClick={refresh}
          >
            <Icon name="refresh" size={17} />
          </button>
        </div>
        <div className="mobile-workspace-select">
          <label>
            Workspace section
            <select
              aria-label="Workspace section"
              value={tab === "Patient record" ? "Patients" : tab}
              onChange={(e) => goto(e.target.value)}
            >
              {nav.map(([n]) => (
                <option key={n}>{n}</option>
              ))}
            </select>
          </label>
          <button aria-label="Sign out" onClick={signout}>
            <Icon name="logout" size={16} />
          </button>
        </div>
        {preview && (
          <div className="preview-note">
            <Icon name="info" size={14} />
            Preview workspace · Sample details only. Storage is temporary.
          </div>
        )}
        <ErrorBox message={actError} />
        {loading ? (
          <Loading />
        ) : error ? (
          <LoadError error={error} retry={refresh} />
        ) : (
          <>
            {tab === "Overview" && (
              <>
                <div className="stats-grid">
                  {(doc
                    ? [
                        [
                          "Today's visits",
                          d.stats.todayCount,
                          "calendar",
                          "mint",
                        ],
                        ["Pending requests", d.stats.pending, "clock", "peach"],
                        ["Online visits", d.stats.online, "video", "purple"],
                        ["Total patients", d.totalPatients, "patients", "blue"],
                        ["Completed", d.stats.completed, "check", "mint"],
                        ["Cancelled", d.stats.cancelled, "calendar", "peach"],
                      ]
                    : [
                        [
                          "Upcoming visits",
                          d.stats.upcoming,
                          "calendar",
                          "mint",
                        ],
                        [
                          "Online visits",
                          d.stats.upcomingOnline,
                          "video",
                          "purple",
                        ],
                        ["Unread updates", unread, "bell", "blue"],
                      ]
                  ).map(([l, n, i, t]) => (
                    <div className="stat" key={l}>
                      <span className={"service-icon " + t}>
                        <Icon name={i} size={20} />
                      </span>
                      <b>{n}</b>
                      <small>{l}</small>
                    </div>
                  ))}
                </div>
                <div className="content-head">
                  <div>
                    <h2>Upcoming appointments</h2>
                    <p>Requests and confirmed visits · Pakistan time</p>
                  </div>
                  <Button to="/book" icon="plus">
                    Book a visit
                  </Button>
                </div>
                <VisitList
                  visits={upcoming.slice(0, 5)}
                  onVisit={setSelected}
                  compact
                />
                <div className="content-head spaced">
                  <h2>Quick access</h2>
                </div>
                <div className="quick-grid">
                  {(doc
                    ? [
                        ["Patients", "patients", "Open patient records"],
                        ["Availability", "schedule", "Manage clinic hours"],
                        ["Notifications", "bell", "Review clinic updates"],
                      ]
                    : [
                        ["Reports", "upload", "Upload a medical report"],
                        ["Prescriptions", "prescription", "View prescriptions"],
                        [
                          "Medical records",
                          "records",
                          "Open your care timeline",
                        ],
                      ]
                  ).map(([t, i, l]) => (
                    <button key={t} onClick={() => goto(t)}>
                      <Icon name={i} size={20} />
                      <span>{l}</span>
                      <Icon name="right" size={15} />
                    </button>
                  ))}
                </div>
              </>
            )}
            {(tab === "Appointments" || tab === "Online visits") && (
              <>
                <div className="filterbar">
                  <select
                    aria-label="Filter appointment status"
                    value={filter}
                    onChange={(e) => {
                      setPage(0);
                      setFilter(e.target.value);
                    }}
                  >
                    {[
                      "All statuses",
                      "Pending",
                      "Confirmed",
                      "Cancelled",
                      "Completed",
                    ].map((x) => (
                      <option key={x}>{x}</option>
                    ))}
                  </select>
                  <div className="pills">
                    {["list", "calendar"].map((v) => (
                      <button
                        key={v}
                        className={v === view ? "selected" : ""}
                        onClick={() => setView(v)}
                      >
                        <Icon name={v} size={15} />
                        {v === "list" ? "List" : "Calendar"}
                      </button>
                    ))}
                  </div>
                  <Button
                    to={
                      tab === "Online visits"
                        ? "/book?type=Online%20Video%20Consultation"
                        : "/book"
                    }
                    icon="plus"
                  >
                    Book a visit
                  </Button>
                </div>
                {view === "calendar" ? (
                  <CalendarView
                    month={month}
                    setMonth={setMonth}
                    visits={visits.filter(
                      (a: any) =>
                        (filter === "All statuses" || a.status === filter) &&
                        (tab !== "Online visits" ||
                          a.type === "Online Video Consultation"),
                    )}
                    onVisit={setSelected}
                  />
                ) : (
                  <VisitList
                    visits={visits.filter(
                      (a: any) =>
                        (filter === "All statuses" || a.status === filter) &&
                        (tab !== "Online visits" ||
                          a.type === "Online Video Consultation"),
                    )}
                    onVisit={setSelected}
                  />
                )}
              </>
            )}
            {tab === "Notifications" && (
              <>
                <div className="content-head">
                  <p>
                    {unread} unread update{unread !== 1 ? "s" : ""}
                  </p>
                  <Button
                    kind="secondary"
                    icon="read"
                    disabled={!unread}
                    busy={busy}
                    onClick={async () => {
                      setBusy(true);
                      try {
                        await api("notification.read", {});
                        refresh();
                      } catch (e: any) {
                        setActError(e.message);
                      } finally {
                        setBusy(false);
                      }
                    }}
                  >
                    Mark all read
                  </Button>
                </div>
                {d.notifications.length ? (
                  d.notifications.map((n: any) => (
                    <div
                      className={"notification " + (!n.read_at ? "unread" : "")}
                      key={n.id}
                    >
                      <Icon name="bell" size={18} />
                      <div>
                        <small>
                          {n.category} · {dateLabel(n.created_at, true)}
                        </small>
                        <p>{n.message}</p>
                      </div>
                      {!n.read_at && (
                        <button
                          className="text-link"
                          onClick={async () => {
                            try {
                              await api("notification.read", { id: n.id });
                              refresh();
                            } catch (e: any) {
                              setActError(e.message);
                            }
                          }}
                        >
                          Mark read
                        </button>
                      )}
                    </div>
                  ))
                ) : (
                  <Empty title="You’re all caught up" icon="bell">
                    Clinic notifications will appear here when there is an
                    update.
                  </Empty>
                )}
              </>
            )}
            {!doc &&
              [
                "My profile",
                "Medical records",
                "Prescriptions",
                "Reports",
                "Payments",
              ].includes(tab) && <RecordView pid={user!.id} tab={tab} />}
            {!doc && tab === "Health assistant" && (
              <Education aiEnabled={d.aiEnabled} />
            )}
            {doc && tab === "Patients" && <PatientDirectory />}
            {doc && tab === "Availability" && <Availability />}
            {doc && tab === "Service content" && <ServiceEditor />}
            {doc && tab === "Patient record" && (
              <>
                <div className="record-tools">
                  <button
                    className="back-link"
                    onClick={() => goto("Patients")}
                  >
                    <Icon name="back" size={14} />
                    Patient directory
                  </button>
                  <Button
                    to={"/book?patient=" + encodeURIComponent(pid)}
                    icon="calendar"
                    kind="secondary"
                  >
                    Book for patient
                  </Button>
                </div>
                <div className="pills record-tabs">
                  {[
                    "Profile",
                    "Medical records",
                    "Prescriptions",
                    "Reports",
                    "Payments",
                    "Visits",
                  ].map((t) => (
                    <button
                      key={t}
                      className={sub === t ? "selected" : ""}
                      onClick={() => setSub(t)}
                    >
                      {t}
                    </button>
                  ))}
                </div>
                {sub === "Visits" ? (
                  <VisitList
                    visits={visits.filter((a: any) => a.patient_id === pid)}
                    onVisit={setSelected}
                  />
                ) : (
                  <RecordView pid={pid} tab={sub} visit={visit} />
                )}
              </>
            )}
            {(listTab || (tab === "Patient record" && sub === "Visits")) &&
              d.pages > 1 && (
                <div className="pagination">
                  <Button
                    kind="secondary"
                    icon="left"
                    onClick={() => setPage(d.page - 1)}
                    disabled={d.page === 0}
                  >
                    Previous
                  </Button>
                  <span>
                    Page {d.page + 1} of {d.pages} · {d.count} appointments
                  </span>
                  <Button
                    kind="secondary"
                    end="right"
                    onClick={() => setPage(d.page + 1)}
                    disabled={d.page + 1 >= d.pages}
                  >
                    Next
                  </Button>
                </div>
              )}
            {!nav.some(([s]) => s === tab) && tab !== "Patient record" && (
              <Empty
                title="Section not found"
                action={
                  <Button onClick={() => goto("Overview")}>
                    Return to overview
                  </Button>
                }
              >
                Choose a section from your workspace menu.
              </Empty>
            )}
          </>
        )}
        {selected && (
          <VisitDetail
            a={selected}
            onClose={() => setSelected(null)}
            refresh={refresh}
            zoomEnabled={d?.zoomEnabled}
          />
        )}
      </main>
      <nav className="mobile-bottom" aria-label="Quick workspace navigation">
        {(doc
          ? doctorNav.slice(0, 4)
          : [patientNav[0], patientNav[1], patientNav[4], patientNav[9]]
        ).map(([t, i]) => (
          <button
            className={t === tab ? "active" : ""}
            key={t}
            onClick={() => goto(t)}
          >
            <Icon name={i} size={19} />
            <small>{t === "Medical records" ? "Records" : t}</small>
          </button>
        ))}
      </nav>
    </div>
  );
}
