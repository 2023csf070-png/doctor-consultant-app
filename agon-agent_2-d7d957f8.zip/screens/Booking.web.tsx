import React, { useEffect, useState } from "react";
import { api, dateLabel, pkToday, timeLabel, TYPES } from "../lib/api";
import {
  Badge,
  Button,
  Empty,
  ErrorBox,
  Eyebrow,
  Field,
  Icon,
  Link,
  Loading,
  Notice,
  useClinic,
  useLoad,
} from "../components/UI.web";
import { ReportUpload } from "../components/Upload.web";
export function SlotPicker({
  day,
  setDay,
  time,
  setTime,
}: {
  day: string;
  setDay: (s: string) => void;
  time: number | null;
  setTime: (n: number | null) => void;
}) {
  const { data, error, loading, refresh } = useLoad("slots", { day });
  const first = pkToday();
  const dates = Array.from({ length: 6 }, (_, i) =>
    new Date(new Date(first + "T12:00:00Z").getTime() + i * 86400000)
      .toISOString()
      .slice(0, 10),
  );
  const change = (d: string) => {
    if (d) {
      setDay(d);
      setTime(null);
    }
  };
  return (
    <div className="slot-picker">
      <div className="form-section-title">
        <h3>Select a date</h3>
        <label className="date-select">
          <Icon name="calendar" size={15} />
          <input
            aria-label="Select appointment date"
            type="date"
            value={day}
            min={first}
            max={new Date(Date.now() + 90 * 86400000)
              .toISOString()
              .slice(0, 10)}
            onChange={(e) => change(e.target.value)}
          />
        </label>
      </div>
      <div className="date-rail">
        {dates.map((d) => (
          <button
            type="button"
            key={d}
            className={d === day ? "chosen" : ""}
            onClick={() => change(d)}
          >
            <small>
              {new Date(d + "T12:00:00Z").toLocaleDateString("en-GB", {
                weekday: "short",
              })}
            </small>
            <b>{d.slice(8)}</b>
            <small>
              {new Date(d + "T12:00:00Z").toLocaleDateString("en-GB", {
                month: "short",
              })}
            </small>
          </button>
        ))}
      </div>
      <div className="form-section-title">
        <h3>Available times</h3>
        <span className="tiny-label">Pakistan time · PKT</span>
      </div>
      {loading ? (
        <Loading label="Checking live availability…" />
      ) : error ? (
        <>
          <ErrorBox message={error} />
          <Button kind="quiet" onClick={refresh}>
            Reload times
          </Button>
        </>
      ) : data?.slots?.length ? (
        <>
          {[0, 1].map((v) => {
            const group = data.slots.filter((m: number) =>
              v ? m >= 900 : m < 900,
            );
            return (
              group.length > 0 && (
                <div className="time-group" key={v}>
                  <small>{v ? "Evening session" : "Daytime session"}</small>
                  <div className="times">
                    {group.map((m: number) => (
                      <button
                        key={m}
                        type="button"
                        className={time === m ? "chosen" : ""}
                        aria-pressed={time === m}
                        onClick={() => setTime(m)}
                      >
                        {timeLabel(m)}
                      </button>
                    ))}
                  </div>
                </div>
              )
            );
          })}
        </>
      ) : (
        <Empty icon="calendar" title="No available slots">
          Choose another date to see available appointments.
        </Empty>
      )}
    </div>
  );
}
export function Booking() {
  const { user, path, go, booking, setBooking, preview } = useClinic();
  const q = new URLSearchParams(path.split("?")[1]);
  const initialType = q.get("type") || booking?.type || TYPES[0];
  const [type, setType] = useState(
      TYPES.includes(initialType) ? initialType : TYPES[0],
    ),
    [day, setDay] = useState(booking?.day || pkToday()),
    [time, setTime] = useState<number | null>(booking?.time ?? null),
    [step, setStep] = useState(user && booking?.resume ? 2 : 1),
    [reason, setReason] = useState(""),
    [report, setReport] = useState(""),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [confirmed, setConfirmed] = useState<any>(null),
    [pid, setPid] = useState(q.get("patient") || "");
  const people = useLoad("patients", undefined, user?.role === "doctor");
  const online = type === TYPES[2];
  const advance = () => {
    if (time === null) {
      setError("Select an available time to continue.");
      return;
    }
    setError("");
    setBooking({ type, day, time, resume: true });
    if (!user) go("/patient/login?next=" + encodeURIComponent("/book"));
    else setStep(2);
  };
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const r = await api("book", {
        type,
        day,
        start_min: time,
        reason,
        report_id: report || null,
        patient_id: pid || null,
      });
      setConfirmed(r);
      setBooking(null);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };
  if (confirmed)
    return (
      <main className="booking-page">
        <div className="confirmation panel">
          <div className="success-mark">
            <Icon name="check" size={32} />
          </div>
          <Eyebrow>REQUEST RECEIVED</Eyebrow>
          <h1>Appointment requested</h1>
          <p>
            Your request has been saved. The doctor will review it, and your
            portal will show the confirmation.
          </p>
          <Badge>Pending</Badge>
          <div className="confirmation-details">
            <span>
              Booking reference<strong>{confirmed.reference}</strong>
            </span>
            <span>
              Consultation<strong>{confirmed.type}</strong>
            </span>
            <span>
              Date & time
              <strong>
                {dateLabel(confirmed.day)} · {timeLabel(confirmed.start_min)}{" "}
                PKT
              </strong>
            </span>
          </div>
          <Button
            to={"/" + user?.role + "/dashboard?tab=Appointments"}
            end="arrow"
          >
            View appointments
          </Button>
        </div>
      </main>
    );
  return (
    <main className="booking-page">
      <div className="container">
        <div className="breadcrumbs">
          <Link to="/">Home</Link>
          <Icon name="right" size={12} />
          Book appointment
        </div>
        <Eyebrow>YOUR NEXT VISIT</Eyebrow>
        <h1>Book an appointment</h1>
        <p className="page-lead">
          Choose a consultation and a time that works for you.
        </p>
        <div className="booking-steps">
          <span className={step === 1 ? "current" : "complete"}>
            <i>{step > 1 ? <Icon name="check" size={13} /> : 1}</i>Choose a time
          </span>
          <b />
          <span className={step === 2 ? "current" : ""}>
            <i>2</i>Visit details
          </span>
          <b />
          <span>
            <i>3</i>Confirmation
          </span>
        </div>
        <div className="booking-layout">
          <section className="panel booking-form">
            {step === 1 ? (
              <>
                <div className="form-section-title">
                  <h2>Consultation type</h2>
                </div>
                <div className="visit-types">
                  <button
                    className={!online ? "chosen" : ""}
                    onClick={() => setType(TYPES[0])}
                  >
                    <Icon name="stethoscope" size={24} />
                    <span>
                      In-clinic visit<small>Meet your doctor in person</small>
                    </span>
                    <i />
                  </button>
                  <button
                    className={online ? "chosen" : ""}
                    onClick={() => setType(TYPES[2])}
                  >
                    <Icon name="video" size={24} />
                    <span>
                      Video consultation<small>Connect from home</small>
                    </span>
                    <i />
                  </button>
                </div>
                {!online && (
                  <Field label="Visit purpose">
                    <select
                      value={type}
                      onChange={(e) => setType(e.target.value)}
                    >
                      {TYPES.filter((t) => t !== TYPES[2]).map((t) => (
                        <option key={t}>{t}</option>
                      ))}
                    </select>
                  </Field>
                )}
                <SlotPicker
                  day={day}
                  setDay={setDay}
                  time={time}
                  setTime={setTime}
                />
                <ErrorBox message={error} />
                <Button onClick={advance} end="arrow" disabled={time === null}>
                  Continue to visit details
                </Button>
                {!user && (
                  <p className="small-muted">
                    <Icon name="lock" size={13} />
                    Sign in at the next step to keep your booking private.
                  </p>
                )}
              </>
            ) : (
              <form className="form-stack" onSubmit={submit}>
                <div className="form-section-title">
                  <h2>Your visit details</h2>
                  <button
                    className="text-link"
                    type="button"
                    onClick={() => setStep(1)}
                  >
                    Change time
                  </button>
                </div>
                {preview && (
                  <Notice>
                    Preview workspace: please use sample information only.
                  </Notice>
                )}
                {user?.role === "doctor" && (
                  <Field label="Patient">
                    <select
                      value={pid}
                      onChange={(e) => setPid(e.target.value)}
                      required
                    >
                      <option value="">Choose a patient</option>
                      {people.data?.patients.map((p: any) => (
                        <option value={p.id} key={p.id}>
                          {p.name} · {p.phone}
                        </option>
                      ))}
                    </select>
                  </Field>
                )}
                <Field
                  label="Reason for your visit"
                  hint="Briefly describe what you would like to discuss with the doctor."
                >
                  <textarea
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    rows={4}
                    maxLength={2000}
                    required
                    placeholder="What brings you to the clinic?"
                  />
                </Field>
                <div>
                  <h3 className="field-title">
                    Medical report <small>Optional</small>
                  </h3>
                  <ReportUpload
                    onDone={(r) => setReport(r.id)}
                    patientId={pid}
                  />
                </div>
                <Notice icon="calendar">
                  This is an appointment request. Your visit is confirmed after
                  the doctor reviews it.
                </Notice>
                <ErrorBox message={error} />
                <Button type="submit" icon="calendar" busy={busy}>
                  Request appointment
                </Button>
              </form>
            )}
          </section>
          <aside className="booking-aside">
            <div className="summary-head">
              <span className="service-icon mint">
                <Icon name="clipboard" size={24} />
              </span>
              <Eyebrow>BOOKING SUMMARY</Eyebrow>
              <h2>Your visit at a glance</h2>
            </div>
            <div className="summary-row">
              <Icon name="stethoscope" />
              <div>
                <small>Your doctor</small>
                <strong>Dr. Faisal Jhandir</strong>
              </div>
            </div>
            <div className="summary-row">
              <Icon name={online ? "video" : "clinic"} />
              <div>
                <small>Consultation</small>
                <strong>{type}</strong>
              </div>
            </div>
            <div className="summary-row">
              <Icon name="calendar" />
              <div>
                <small>Date & time</small>
                <strong>{dateLabel(day, true)}</strong>
                <span>
                  {time === null
                    ? "Select an available slot"
                    : timeLabel(time) + " · PKT"}
                </span>
              </div>
            </div>
            <div className="summary-row">
              <Icon name="pin" />
              <div>
                <small>{online ? "Location" : "Clinic location"}</small>
                <strong>
                  {online
                    ? "Private online meeting"
                    : "Bashir Alam Clinic, Multan"}
                </strong>
              </div>
            </div>
            <a href="tel:+923020460461" className="summary-help">
              <Icon name="phone" size={16} />
              Need help? 0302 0460461
            </a>
          </aside>
        </div>
      </div>
    </main>
  );
}
