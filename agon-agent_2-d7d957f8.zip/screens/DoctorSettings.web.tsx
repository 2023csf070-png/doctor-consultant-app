import React, { useEffect, useState } from "react";
import { api, pkToday, time24, toMinute, timeLabel } from "../lib/api";
import {
  Button,
  Empty,
  ErrorBox,
  Field,
  Icon,
  Loading,
  LoadError,
  Modal,
  Notice,
  useClinic,
  useLoad,
} from "../components/UI.web";
const days = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];
export function Availability() {
  const loaded = useLoad("availability"),
    [rows, setRows] = useState<any[]>([]),
    [duration, setDuration] = useState(30),
    [modal, setModal] = useState(false),
    [kind, setKind] = useState("Blocked"),
    [err, setErr] = useState(""),
    [busy, setBusy] = useState(false);
  const { toast } = useClinic();
  useEffect(() => {
    if (loaded.data) {
      setRows(loaded.data.weekly);
      setDuration(loaded.data.duration);
    }
  }, [loaded.data]);
  const act = async (op: string, body: any) => {
    setErr("");
    setBusy(true);
    try {
      await api(op, body);
      toast("Clinic availability updated.");
      setModal(false);
      loaded.refresh();
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };
  if (loaded.loading) return <Loading />;
  if (loaded.error)
    return <LoadError error={loaded.error} retry={loaded.refresh} />;
  return (
    <>
      <div className="content-head">
        <div>
          <h2>Weekly availability</h2>
          <p>Configure working sessions and breaks in Pakistan time.</p>
        </div>
      </div>
      <form
        className="panel form-stack"
        onSubmit={(e) => {
          e.preventDefault();
          act("availability.save", { weekly: rows, duration });
        }}
      >
        <Field label="Appointment duration">
          <select
            value={duration}
            onChange={(e) => setDuration(Number(e.target.value))}
          >
            {[10, 15, 20, 30, 45, 60, 90, 120].map((d) => (
              <option key={d} value={d}>
                {d} minutes
              </option>
            ))}
          </select>
        </Field>
        <div className="schedule-grid">
          {days.map((day, d) => (
            <div className="schedule-day" key={day}>
              <strong>{day}</strong>
              <div>
                {rows.map(
                  (w, i) =>
                    w.weekday === d && (
                      <div className="session-edit" key={i}>
                        <input
                          type="time"
                          aria-label={day + " session start"}
                          required
                          value={time24(w.start_min)}
                          onChange={(e) =>
                            setRows(
                              rows.map((r, n) =>
                                n === i
                                  ? {
                                      ...r,
                                      start_min: toMinute(e.target.value),
                                    }
                                  : r,
                              ),
                            )
                          }
                        />
                        <span>–</span>
                        <input
                          type="time"
                          aria-label={day + " session end"}
                          required
                          value={time24(w.end_min)}
                          onChange={(e) =>
                            setRows(
                              rows.map((r, n) =>
                                n === i
                                  ? { ...r, end_min: toMinute(e.target.value) }
                                  : r,
                              ),
                            )
                          }
                        />
                        <button
                          type="button"
                          className="icon-btn"
                          aria-label={"Remove " + day + " session"}
                          onClick={() =>
                            setRows(rows.filter((_, n) => n !== i))
                          }
                        >
                          <Icon name="x" size={14} />
                        </button>
                      </div>
                    ),
                )}
                {!rows.some((r) => r.weekday === d) && <small>Closed</small>}
              </div>
              <button
                type="button"
                className="text-link"
                onClick={() =>
                  setRows([
                    ...rows,
                    { weekday: d, start_min: 540, end_min: 840 },
                  ])
                }
              >
                <Icon name="plus" size={14} />
                Session
              </button>
            </div>
          ))}
        </div>
        <ErrorBox message={!modal ? err : ""} />
        <Button type="submit" busy={busy} icon="check">
          Save working hours
        </Button>
      </form>
      <div className="content-head spaced">
        <div>
          <h2>Schedule exceptions</h2>
          <p>Holidays, blocked times, and additional clinic hours.</p>
        </div>
        <Button
          kind="secondary"
          icon="plus"
          onClick={() => {
            setModal(true);
            setErr("");
          }}
        >
          Add exception
        </Button>
      </div>
      {loaded.data?.exceptions.length ? (
        loaded.data.exceptions.map((x: any) => (
          <div key={x.id} className="record-row">
            <Icon name="calendar" />
            <div>
              <strong>
                {x.kind} · {x.day}
              </strong>
              <p>
                {x.kind === "Holiday"
                  ? "Closed all day"
                  : timeLabel(x.start_min) + " – " + timeLabel(x.end_min)}
              </p>
            </div>
            <Button
              kind="quiet"
              busy={busy}
              onClick={() => act("exception.remove", { id: x.id })}
            >
              Remove
            </Button>
          </div>
        ))
      ) : (
        <Empty title="No upcoming exceptions" icon="calendar">
          Your normal weekly hours apply.
        </Empty>
      )}
      {modal && (
        <Modal title="Add schedule exception" onClose={() => setModal(false)}>
          <form
            className="form-stack"
            onSubmit={(e) => {
              e.preventDefault();
              const f = new FormData(e.currentTarget);
              act("exception.save", {
                kind,
                day: f.get("day"),
                start_min: toMinute(String(f.get("start") || "00:00")),
                end_min: toMinute(String(f.get("end") || "23:59")),
              });
            }}
          >
            <Field label="Exception type">
              <select value={kind} onChange={(e) => setKind(e.target.value)}>
                {["Blocked", "Holiday", "Extra"].map((x) => (
                  <option key={x}>{x}</option>
                ))}
              </select>
            </Field>
            <Field label="Date">
              <input type="date" name="day" min={pkToday()} required />
            </Field>
            {kind !== "Holiday" && (
              <div className="form-grid">
                <Field label="Start time">
                  <input name="start" type="time" required />
                </Field>
                <Field label="End time">
                  <input name="end" type="time" required />
                </Field>
              </div>
            )}
            <ErrorBox message={err} />
            <Button type="submit" busy={busy}>
              Save exception
            </Button>
          </form>
        </Modal>
      )}
    </>
  );
}
export function ServiceEditor() {
  const { services, refreshServices, toast } = useClinic(),
    [selected, setSelected] = useState<any>(null),
    [err, setErr] = useState(""),
    [busy, setBusy] = useState(false);
  return (
    <>
      <div className="content-head">
        <div>
          <h2>Service content</h2>
          <p>Changes appear on the public clinic website.</p>
        </div>
      </div>
      {services.map((s) => (
        <div className="record-row" key={s.id}>
          <span className={"service-icon " + s.tone}>
            <Icon name={s.icon} />
          </span>
          <div>
            <strong>{s.name}</strong>
            <p>{s.description}</p>
          </div>
          <button
            className="text-link"
            onClick={() => {
              setSelected(s);
              setErr("");
            }}
          >
            Edit
          </button>
        </div>
      ))}
      {selected && (
        <Modal title="Edit clinic service" onClose={() => setSelected(null)}>
          <form
            className="form-stack"
            onSubmit={async (e) => {
              e.preventDefault();
              setErr("");
              setBusy(true);
              const b = Object.fromEntries(new FormData(e.currentTarget));
              try {
                await api("service.save", { ...b, id: selected.id });
                await refreshServices();
                setSelected(null);
                toast("Public service content updated.");
              } catch (e: any) {
                setErr(e.message);
              } finally {
                setBusy(false);
              }
            }}
          >
            <Field label="Service title">
              <input
                name="name"
                defaultValue={selected.name}
                maxLength={80}
                required
              />
            </Field>
            <Field label="Card description">
              <textarea
                name="description"
                defaultValue={selected.description}
                rows={2}
                maxLength={180}
                required
              />
            </Field>
            <Field label="Full service detail">
              <textarea
                name="detail"
                defaultValue={selected.detail}
                rows={4}
                maxLength={1500}
                required
              />
            </Field>
            <ErrorBox message={err} />
            <Button type="submit" busy={busy}>
              Publish changes
            </Button>
          </form>
        </Modal>
      )}
    </>
  );
}
