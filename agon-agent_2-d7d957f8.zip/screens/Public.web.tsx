import React, { useEffect, useRef, useState } from "react";
import { Image } from "expo-image";
import {
  Button,
  Eyebrow,
  Icon,
  Link,
  Logo,
  Modal,
  useClinic,
  Empty,
} from "../components/UI.web";
import { FOOTER_DISCLAIMER, MAP, PHONE, Service } from "../lib/api";
export function Header() {
  const { path, user } = useClinic(),
    [menu, setMenu] = useState(false);
  useEffect(() => setMenu(false), [path]);
  return (
    <header className="site-header">
      <div className="container header-inner">
        <Logo />
        <nav
          className={"main-nav " + (menu ? "is-open" : "")}
          aria-label="Main navigation"
        >
          {[
            ["Home", "/"],
            ["About", "/about"],
            ["Services", "/services"],
            ["Contact", "/contact"],
          ].map(([label, to]) => (
            <Link
              key={to}
              to={to}
              className={path.split("?")[0] === to ? "active" : ""}
              aria-current={path === to ? "page" : undefined}
            >
              {label}
            </Link>
          ))}
        </nav>
        <div className="header-actions">
          <Link
            to={user ? "/" + user.role + "/dashboard" : "/patient/login"}
            className="portal-link"
          >
            <Icon name="user" size={17} />
            <span>{user ? "My Workspace" : "Patient Portal"}</span>
            <Icon name="external" size={15} />
          </Link>
          <button
            className="mobile-menu"
            aria-label={menu ? "Close navigation" : "Open navigation"}
            aria-expanded={menu}
            onClick={() => setMenu(!menu)}
          >
            <Icon name={menu ? "x" : "menu"} />
          </button>
        </div>
      </div>
    </header>
  );
}
export function Footer() {
  return (
    <footer>
      <div className="container">
        <div className="footer-top">
          <div>
            <Logo />
            <p>
              In-clinic and online consultations
              <br />
              with Dr. Faisal Jhandir in Multan.
            </p>
          </div>
          <div>
            <h4>Explore</h4>
            <Link to="/about">About the clinic</Link>
            <Link to="/services">Our services</Link>
            <Link to="/contact">Contact & directions</Link>
          </div>
          <div>
            <h4>Patient care</h4>
            <Link to="/book">Book appointment</Link>
            <Link to="/online-consultation">Online consultation</Link>
            <Link to="/patient/login">Patient portal</Link>
          </div>
          <div>
            <h4>Clinic information</h4>
            <a href="tel:+923020460461">{PHONE}</a>
            <Link to="/privacy">Privacy policy</Link>
            <Link to="/terms">Terms & conditions</Link>
          </div>
        </div>
        <p className="disclaimer">{FOOTER_DISCLAIMER}</p>
        <div className="footer-bottom">
          <span>© {new Date().getFullYear()} Bashir Alam Clinic, Multan.</span>
          <Link to="/doctor/login">
            <Icon name="lock" size={12} /> Doctor portal
          </Link>
        </div>
      </div>
    </footer>
  );
}
export function Emergency() {
  return (
    <div className="emergency">
      <Icon name="alert" size={17} />
      <span>
        <strong>Need emergency care?</strong> Seek immediate local emergency
        medical care. Do not wait for an online appointment.
      </span>
    </div>
  );
}
export function ClinicInfo() {
  return (
    <div className="clinic-info">
      <div className="info-item">
        <span className="info-icon">
          <Icon name="clock" size={25} />
        </span>
        <div>
          <span className="info-label">Clinic hours</span>
          <strong>
            9 AM – 2 PM <i /> 5 PM – 10 PM
          </strong>
          <small>Pakistan Standard Time</small>
        </div>
      </div>
      <div className="info-item">
        <span className="info-icon">
          <Icon name="phone" size={24} />
        </span>
        <div>
          <span className="info-label">Call the clinic</span>
          <strong>{PHONE}</strong>
          <a href="tel:+923020460461">
            Call now <Icon name="external" size={12} />
          </a>
        </div>
      </div>
      <div className="info-item">
        <span className="info-icon">
          <Icon name="pin" size={25} />
        </span>
        <div>
          <span className="info-label">Visit our clinic</span>
          <strong>Multan, Punjab</strong>
          <a href={MAP} target="_blank" rel="noreferrer">
            Get directions <Icon name="external" size={12} />
          </a>
        </div>
      </div>
    </div>
  );
}
function Hero() {
  const scene = useRef<HTMLDivElement>(null);
  return (
    <section className="hero-band">
      <div className="hero-grain" />
      <div className="container">
        <div className="hero">
          <div className="hero-copy">
            <div className="hero-tag">
              <span /> IN-CLINIC & ONLINE CARE
            </div>
            <h1>
              Your Health,
              <br />
              <em>
                Our Priority<span>.</span>
              </em>
            </h1>
            <p>
              Book your appointment online and consult with your doctor
              conveniently from anywhere through secure online consultation.
            </p>
            <div className="button-row hero-buttons">
              <Button to="/book" icon="calendar">
                Book Appointment
              </Button>
              <Button to="/online-consultation" kind="secondary" icon="video">
                Online Consultation
              </Button>
            </div>
            <div className="hero-doctor">
              <span>
                <Icon name="stethoscope" size={15} />
              </span>
              Care with <strong>Dr. Faisal Jhandir</strong>
            </div>
          </div>
          <div
            className="hero-scene"
            ref={scene}
            onPointerMove={(e) => {
              if (
                e.pointerType === "mouse" &&
                !window.matchMedia("(prefers-reduced-motion: reduce)").matches
              ) {
                const b = e.currentTarget.getBoundingClientRect();
                scene.current?.style.setProperty(
                  "--rx",
                  ((e.clientX - b.x) / b.width - 0.5) * 2 + "deg",
                );
                scene.current?.style.setProperty(
                  "--ry",
                  ((e.clientY - b.y) / b.height - 0.5) * -2 + "deg",
                );
              }
            }}
            onPointerLeave={() => {
              scene.current?.style.setProperty("--rx", "0deg");
              scene.current?.style.setProperty("--ry", "0deg");
            }}
          >
            <div className="dot-pattern" />
            <div className="image-backing" />
            <div className="hero-image">
              <Image
                source={require("../assets/images/consultation.webp")}
                contentFit="cover"
                style={{ width: "100%", height: "100%" }}
                accessibilityLabel="A doctor discussing a patient's care during an in-clinic consultation"
              />
            </div>
            <div className="floating-plus" aria-hidden="true">
              <Icon name="plus" size={32} stroke={3.4} />
            </div>
            <div className="image-caption">
              <span className="caption-icon">
                <Icon name="shield" size={25} />
              </span>
              <span>
                <small>PATIENT-CENTRED CARE</small>
                <strong>In-clinic & online</strong>
              </span>
              <span className="caption-dot" />
            </div>
            <span className="decor-plus" aria-hidden="true">
              +
            </span>
          </div>
        </div>
        <ClinicInfo />
      </div>
    </section>
  );
}
export function ServiceCards({ items }: { items: Service[] }) {
  const [s, setS] = useState<Service | null>(null);
  return (
    <>
      <div className="service-grid">
        {items.map((x, i) => (
          <button
            key={x.id}
            className={"service-card card-" + x.tone}
            onClick={() => setS(x)}
          >
            <div className="service-top">
              <span className={"service-icon " + x.tone}>
                <Icon name={x.icon} size={25} stroke={1.65} />
              </span>
              <Icon name="external" size={17} className="service-arrow" />
            </div>
            <h3>{x.name}</h3>
            <p>{x.description}</p>
            <div className="card-bottom-line" />
          </button>
        ))}
      </div>
      {s && (
        <Modal title={s.name} onClose={() => setS(null)}>
          <span className={"service-icon " + s.tone}>
            <Icon name={s.icon} size={28} />
          </span>
          <p className="modal-description">{s.detail}</p>
          <div className="detail-mini">
            <Icon name="stethoscope" />
            Dr. Faisal Jhandir <span>·</span> Multan
          </div>
          <Button
            to={
              s.id === "online"
                ? "/online-consultation"
                : ["records", "prescription", "guidance"].includes(s.id)
                  ? "/patient/dashboard?tab=" +
                    encodeURIComponent(
                      s.id === "records"
                        ? "Medical records"
                        : s.id === "prescription"
                          ? "Prescriptions"
                          : "Health assistant",
                    )
                  : "/book?type=" +
                    encodeURIComponent(
                      s.id === "followup"
                        ? "Follow-up Consultation"
                        : s.id === "disease"
                          ? "Disease Consultation"
                          : "General Consultation",
                    )
            }
            end="arrow"
          >
            {["records", "prescription", "guidance"].includes(s.id)
              ? "Open patient portal"
              : "Book a consultation"}
          </Button>
        </Modal>
      )}
    </>
  );
}
export function CTA() {
  return (
    <div className="consult-cta">
      <div className="cta-symbol">
        <Icon name="care" size={32} />
      </div>
      <div>
        <h2>Need Medical Consultation?</h2>
        <p>Book your appointment today or consult with the doctor online.</p>
      </div>
      <Button to="/book" end="arrow">
        Book Appointment
      </Button>
      <Link to="/online-consultation" className="cta-link">
        Consult online <Icon name="external" size={14} />
      </Link>
    </div>
  );
}
export function Home() {
  const { services } = useClinic();
  useEffect(() => {
    if (
      !("IntersectionObserver" in window) ||
      window.matchMedia("(prefers-reduced-motion: reduce)").matches
    )
      return;
    const observer = new IntersectionObserver((entries) => {
      for (const entry of entries)
        if (entry.isIntersecting) {
          entry.target.classList.add("reveal-in");
          observer.unobserve(entry.target);
        }
    });
    document.querySelectorAll(".service-card,.consult-cta").forEach((el) => {
      if (el.getBoundingClientRect().top > window.innerHeight)
        observer.observe(el);
    });
    return () => observer.disconnect();
  }, [services]);
  return (
    <>
      <Hero />
      <section className="container services-section">
        <div className="section-heading">
          <div>
            <Eyebrow>OUR SERVICES</Eyebrow>
            <h2>Care for every step</h2>
            <p>
              From everyday health concerns to ongoing care, we’re here for you.
            </p>
          </div>
          <Link to="/services" className="text-link">
            View all services <Icon name="arrow" size={16} />
          </Link>
        </div>
        <ServiceCards items={services} />
      </section>
      <section className="container home-bottom">
        <CTA />
        <Emergency />
      </section>
    </>
  );
}
function PageIntro({
  label,
  title,
  children,
}: {
  label: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="page-intro">
      <div className="container">
        <div className="breadcrumbs">
          <Link to="/">Home</Link>
          <Icon name="right" size={12} />
          {label}
        </div>
        <Eyebrow>{label.toUpperCase()}</Eyebrow>
        <h1>{title}</h1>
        <p>{children}</p>
      </div>
    </div>
  );
}
export function Services() {
  const { services } = useClinic(),
    [filter, setFilter] = useState("All services"),
    [search, setSearch] = useState("");
  const result = services.filter(
    (x) =>
      (filter === "All services" || x.group === filter) &&
      (x.name + " " + x.description)
        .toLowerCase()
        .includes(search.toLowerCase()),
  );
  return (
    <>
      <PageIntro label="Our services" title="Care for every step">
        Explore in-clinic consultations, online visits, and your private patient
        services.
      </PageIntro>
      <section className="container inner-space">
        <div className="filterbar">
          <div className="pills">
            {["All services", "In-clinic", "Online", "Patient support"].map(
              (x) => (
                <button
                  className={filter === x ? "selected" : ""}
                  key={x}
                  onClick={() => setFilter(x)}
                >
                  {x}
                </button>
              ),
            )}
          </div>
          <label className="search">
            <Icon name="search" size={17} />
            <input
              aria-label="Search services"
              placeholder="Search services"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </label>
        </div>
        {result.length ? (
          <ServiceCards items={result} />
        ) : (
          <Empty title="No matching services" icon="search">
            Try a different search or category.
          </Empty>
        )}
        <CTA />
      </section>
    </>
  );
}
export function About() {
  return (
    <>
      <PageIntro label="About the clinic" title="Personal care, close to home.">
        Bashir Alam Clinic brings in-person and online consultations together in
        Multan.
      </PageIntro>
      <section className="container inner-space">
        <div className="about-grid">
          <div className="about-photo">
            <Image
              source={require("../assets/images/clinic-notes.webp")}
              contentFit="cover"
              style={{ width: "100%", height: "100%" }}
              accessibilityLabel="A clinician reviewing a patient's notes"
            />
          </div>
          <div>
            <Eyebrow>MEET YOUR CLINIC</Eyebrow>
            <h2>Bashir Alam Clinic</h2>
            <p className="prose">
              Consult with Dr. Faisal Jhandir near MDA Officers Cooperative
              Housing Society, Multan. Choose to see your doctor at the clinic
              or request an online video consultation.
            </p>
            <p className="prose">
              Your patient portal keeps appointments, reports, doctor’s notes,
              and prescriptions in one private place. Clinical decisions and
              prescriptions are always made by your doctor.
            </p>
            <div className="doctor-ident">
              <span className="service-icon mint">
                <Icon name="stethoscope" />
              </span>
              <div>
                <strong>Dr. Faisal Jhandir</strong>
                <small>Clinic doctor · Bashir Alam Clinic</small>
              </div>
            </div>
          </div>
        </div>
        <ClinicInfo />
        <CTA />
      </section>
    </>
  );
}
export function Contact() {
  return (
    <>
      <PageIntro label="Contact" title="Let’s get you connected.">
        Call the clinic, plan your visit, or find your way to us in Multan.
      </PageIntro>
      <section className="container inner-space">
        <div className="contact-grid">
          <article className="panel">
            <span className="service-icon mint">
              <Icon name="phone" />
            </span>
            <h2>Contact the clinic</h2>
            <p className="prose">
              For appointment questions or help using your patient portal, call
              during clinic hours.
            </p>
            <a href="tel:+923020460461" className="big-phone">
              {PHONE}
            </a>
            <a href="tel:+923020460461" className="btn btn-primary">
              <Icon name="phone" size={17} />
              Call Now
            </a>
            <div className="contact-hours">
              <Icon name="clock" />
              <div>
                <strong>Clinic hours · PKT</strong>
                <p>
                  Morning: 9:00 AM – 2:00 PM
                  <br />
                  Evening: 5:00 PM – 10:00 PM
                </p>
              </div>
            </div>
          </article>
          <article className="panel location-panel">
            <div className="map-art" aria-hidden="true">
              <div className="map-river" />
              <div className="map-road r1" />
              <div className="map-road r2" />
              <div className="map-road r3" />
              <span className="map-marker">
                <Icon name="clinic" size={28} />
              </span>
              <span className="map-tag">Bashir Alam Clinic</span>
            </div>
            <h2>Visit us in Multan</h2>
            <p className="prose">
              Near MDA Officers Cooperative Housing Society, Multan, Punjab,
              Pakistan.
            </p>
            <div className="map-code">
              <Icon name="pin" size={16} />
              6GC7+3XQ, Multan, 60000
            </div>
            <a
              href={MAP}
              target="_blank"
              rel="noreferrer"
              className="btn btn-secondary"
            >
              Get Directions <Icon name="external" size={16} />
            </a>
          </article>
        </div>
        <Emergency />
      </section>
    </>
  );
}
const privacy = [
  [
    "Your clinic information",
    "The clinic collects the identity and contact details you provide during registration, including CNIC, date of birth, and address, to identify the correct patient and manage clinical care. Only enter information needed for your care.",
  ],
  [
    "Who can access your records",
    "You can view your own records. Your authorised clinic doctor can view and update your clinical history, appointments, notes, reports, and prescriptions. Sensitive access and changes are recorded in an audit log.",
  ],
  [
    "Private storage and sessions",
    "Medical reports and clinical text are encrypted in private storage. Report downloads require an authorised session. Passwords are hashed, and browser sessions use HTTP-only cookies. Sign out when using a shared device.",
  ],
  [
    "Consultations and external providers",
    "When configured, Zoom receives the time and duration needed to create a private meeting. Payment providers process payments in their own checkout. No card details are stored in the clinic platform. Optional integrations remain inactive until connected.",
  ],
  [
    "Education and your choices",
    "The private educational guide runs without sending questions to an external AI service. If AI topic matching is configured, you may explicitly opt in for a question; only the question is shared, never your profile or clinical records. Do not include identifying details in education questions. Call the clinic to request an access review, correction, or deletion, subject to clinical record retention obligations.",
  ],
  [
    "Contact",
    "For privacy questions or account assistance, contact Bashir Alam Clinic on 0302 0460461 during clinic hours.",
  ],
];
const terms = [
  [
    "Using the clinic platform",
    "Use accurate information and keep your account credentials private. You may access only records and appointments that belong to you or that you are authorised to manage.",
  ],
  [
    "Appointment requests",
    "Selecting a slot and submitting a request creates a pending appointment, not a confirmed visit. Check your patient portal for confirmation or changes. All appointment times use Pakistan Standard Time.",
  ],
  [
    "Online consultations",
    "Online visits require doctor confirmation and a private meeting prepared by the clinic. Do not share meeting details. A video visit may not be suitable for every concern; your doctor may recommend an in-person visit.",
  ],
  [
    "Clinical information and prescriptions",
    "Only the authorised doctor can create or change clinical records and prescriptions. Educational content cannot diagnose a condition or advise starting or stopping medicines.",
  ],
  [
    "Payments",
    "Payment requests are shown in your private portal. A payment is marked paid only after verified provider confirmation. Contact the clinic about fees, payment questions, or refunds before proceeding.",
  ],
  [
    "Emergencies",
    "The platform is not an emergency service. If you think you may have an emergency, seek immediate local emergency medical care rather than waiting for a booking or a message.",
  ],
];
export function Legal({ isPrivacy }: { isPrivacy: boolean }) {
  return (
    <>
      <PageIntro
        label="Clinic information"
        title={isPrivacy ? "Privacy Policy" : "Terms & Conditions"}
      >
        {isPrivacy
          ? "How your information is used, stored, and protected."
          : "A guide to using clinic services and your patient portal."}
      </PageIntro>
      <article className="container legal inner-space">
        {(isPrivacy ? privacy : terms).map(([t, p], i) => (
          <section key={t}>
            <small>{String(i + 1).padStart(2, "0")}</small>
            <div>
              <h2>{t}</h2>
              <p>{p}</p>
            </div>
          </section>
        ))}
        <Emergency />
      </article>
    </>
  );
}
export function Online() {
  return (
    <>
      <PageIntro
        label="Online consultation"
        title="Your consultation, wherever you are."
      >
        Request a private video visit with Dr. Faisal Jhandir, without a trip to
        the clinic.
      </PageIntro>
      <div className="container inner-space">
        <div className="online-split">
          <div className="panel">
            <Eyebrow>HOW IT WORKS</Eyebrow>
            <h2>Three steps to your online visit</h2>
            {[
              [
                "Choose your time",
                "Select an available online consultation slot and tell your doctor the reason for your visit.",
              ],
              [
                "Receive confirmation",
                "Your doctor reviews the request. Follow the status and notification in your private portal.",
              ],
              [
                "Join your consultation",
                "When your meeting is prepared, your secure Join Online Consultation action appears in your appointment.",
              ],
            ].map(([h, p], i) => (
              <div className="step-item" key={h}>
                <span>0{i + 1}</span>
                <div>
                  <h3>{h}</h3>
                  <p>{p}</p>
                </div>
              </div>
            ))}
            <Button to="/book?type=Online%20Video%20Consultation" icon="video">
              Request Online Consultation
            </Button>
          </div>
          <aside className="online-aside">
            <div className="video-art">
              <Icon name="video" size={55} stroke={1.35} />
              <span>
                <Icon name="shield" size={24} />
              </span>
            </div>
            <h2>A private space for your care</h2>
            <p>
              Only you and your authorised doctor can access your appointment’s
              meeting details.
            </p>
            <div className="detail-mini">
              <Icon name="clock" size={18} />
              All times shown in PKT
            </div>
            <Link
              to="/patient/dashboard?tab=Online%20visits"
              className="text-link"
            >
              View my online visits <Icon name="arrow" size={16} />
            </Link>
          </aside>
        </div>
        <Emergency />
      </div>
    </>
  );
}
