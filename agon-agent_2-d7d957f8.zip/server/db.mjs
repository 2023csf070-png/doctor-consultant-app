import {
  readFileSync,
  mkdirSync,
  existsSync,
  writeFileSync,
  chmodSync,
} from "node:fs";
import { join, resolve } from "node:path";
import {
  randomBytes,
  createHash,
  createHmac,
  createCipheriv,
  createDecipheriv,
  randomUUID,
  scrypt,
  timingSafeEqual,
} from "node:crypto";
import { promisify } from "node:util";
import { SCHEMA, SERVICES } from "./compiled-assets.mjs";
const derive = promisify(scrypt);
export const preview = !!process.env.VERCEL && !process.env.LIBSQL_URL;
export const dataDir = resolve(
  process.env.CLINIC_DATA_DIR ||
    (process.env.VERCEL ? "/tmp/bashir-alam-preview" : ".clinic"),
);
let secret,
  instance,
  queue = Promise.resolve();
export class Problem extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}
export const fail = (n, m) => {
  throw new Problem(n, m);
};
export const id = () => randomUUID();
export const sha = (s) => createHash("sha256").update(s).digest("hex");
function key() {
  if (secret) return secret;
  if (process.env.DATA_ENCRYPTION_KEY) {
    secret = Buffer.from(process.env.DATA_ENCRYPTION_KEY, "base64");
    if (secret.length !== 32) throw Error("Invalid data key");
    return secret;
  }
  if (
    process.env.LIBSQL_URL ||
    (process.env.NODE_ENV === "production" && !preview)
  )
    throw Error("A persistent encryption key is required");
  mkdirSync(dataDir, { recursive: true, mode: 0o700 });
  const p = join(dataDir, "data.key");
  if (!existsSync(p)) {
    try {
      writeFileSync(p, randomBytes(32), { mode: 0o600, flag: "wx" });
    } catch (e) {
      if (e.code !== "EEXIST") throw e;
    }
  }
  return (secret = readFileSync(p));
}
export const blind = (s) => createHmac("sha256", key()).update(s).digest("hex");
export function seal(value) {
  const iv = randomBytes(12),
    c = createCipheriv("aes-256-gcm", key(), iv);
  const b = Buffer.concat([c.update(String(value), "utf8"), c.final()]);
  return Buffer.concat([iv, c.getAuthTag(), b]).toString("base64");
}
export function unseal(value) {
  const b = Buffer.from(value, "base64"),
    c = createDecipheriv("aes-256-gcm", key(), b.subarray(0, 12));
  c.setAuthTag(b.subarray(12, 28));
  return Buffer.concat([c.update(b.subarray(28)), c.final()]).toString("utf8");
}
export async function hashPassword(p) {
  const salt = randomBytes(16).toString("hex");
  return (
    salt +
    ":" +
    Buffer.from(
      await derive(p, salt, 64, {
        N: 32768,
        r: 8,
        p: 1,
        maxmem: 64 * 1024 * 1024,
      }),
    ).toString("hex")
  );
}
export async function verifyPassword(p, h) {
  const [salt, hash] = h.split(":");
  const result = await derive(p, salt, 64, {
    N: 32768,
    r: 8,
    p: 1,
    maxmem: 64 * 1024 * 1024,
  });
  return timingSafeEqual(Buffer.from(hash, "hex"), result);
}
function remoteAdapter(c) {
  return {
    async all(q, a = []) {
      return (await c.execute({ sql: q, args: a })).rows.map((x) => ({ ...x }));
    },
    async one(q, a = []) {
      return (await this.all(q, a))[0];
    },
    async run(q, a = []) {
      return c.execute({ sql: q, args: a });
    },
    async tx(f) {
      const tx = await c.transaction("write");
      try {
        const r = await f(remoteAdapter(tx));
        await tx.commit();
        return r;
      } catch (e) {
        await tx.rollback().catch(() => {});
        throw e;
      } finally {
        tx.close();
      }
    },
  };
}
async function open() {
  key();
  let db;
  const schema = SCHEMA;
  if (process.env.LIBSQL_URL) {
    const { createClient } = await import("@libsql/client/web");
    const c = createClient({
      url: process.env.LIBSQL_URL,
      authToken: process.env.LIBSQL_AUTH_TOKEN,
    });
    await c.executeMultiple(schema);
    db = remoteAdapter(c);
  } else {
    mkdirSync(dataDir, { recursive: true, mode: 0o700 });
    const { DatabaseSync } = await import("node:sqlite");
    const path = join(dataDir, "clinic.sqlite");
    const c = new DatabaseSync(path);
    chmodSync(path, 0o600);
    c.exec("PRAGMA journal_mode=WAL; PRAGMA busy_timeout=4000;" + schema);
    db = {
      async all(q, a = []) {
        return c.prepare(q).all(...a);
      },
      async one(q, a = []) {
        return c.prepare(q).get(...a);
      },
      async run(q, a = []) {
        return c.prepare(q).run(...a);
      },
      async tx(f) {
        c.exec("BEGIN IMMEDIATE");
        try {
          const v = await f(db);
          c.exec("COMMIT");
          return v;
        } catch (e) {
          c.exec("ROLLBACK");
          throw e;
        }
      },
    };
  }
  await db.tx(async (t) => {
    if (await t.one("SELECT value FROM clinic_meta WHERE key='initialised'"))
      return;
    await t.run(
      "INSERT OR IGNORE INTO doctors(id,name,duration) VALUES(?,?,?)",
      ["clinic-doctor", "Dr. Faisal Jhandir", 30],
    );
    for (let d = 0; d < 7; d++)
      for (const [s, e] of [
        [540, 840],
        [1020, 1320],
      ])
        await t.run(
          "INSERT OR IGNORE INTO availability(doctor_id,weekday,start_min,end_min)VALUES(?,?,?,?)",
          ["clinic-doctor", d, s, e],
        );
    const services = SERVICES;
    for (const [i, s] of services.entries())
      await t.run("INSERT OR IGNORE INTO services VALUES(?,?,?,?,?,?,?,?)", [
        s.id,
        s.name,
        s.description,
        s.detail,
        s.icon,
        s.tone,
        s.group,
        i,
      ]);
    await t.run("INSERT OR IGNORE INTO clinic_meta VALUES('initialised','1')");
  });
  return db;
}
export const database = () =>
  instance ||
  (instance = open().catch((e) => {
    instance = null;
    throw e;
  }));
export async function withDatabase(f) {
  if (process.env.LIBSQL_URL) return f(await database());
  const next = queue.then(async () => f(await database()));
  queue = next.catch(() => {});
  return next;
}
export const audit = (db, actor, action, resource) =>
  db.run(
    "INSERT INTO audit_logs(id,actor_id,action,resource_id) VALUES(?,?,?,?)",
    [id(), actor || null, action, resource || null],
  );
export const today = () =>
  new Date(Date.now() + 5 * 3600000).toISOString().slice(0, 10);
export const pkMinute = () => {
  const d = new Date(Date.now() + 5 * 3600000);
  return d.getUTCHours() * 60 + d.getUTCMinutes();
};
export const dayValid = (s) =>
  typeof s === "string" &&
  /^\d{4}-\d{2}-\d{2}$/.test(s) &&
  !isNaN(Date.parse(s)) &&
  new Date(s).toISOString().slice(0, 10) === s;
export function text(v, name, max = 200, required = true) {
  if (
    typeof v !== "string" ||
    v.trim().length > max ||
    (required && !v.trim()) ||
    /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(v)
  )
    fail(422, `Please enter a valid ${name}.`);
  return v.trim();
}
export const phoneNumber = (s) => {
  const n = String(s || "").replace(/[\s()-]/g, "");
  return n.startsWith("+92")
    ? "0" + n.slice(3)
    : n.startsWith("92") && n.length === 12
      ? "0" + n.slice(2)
      : n;
};
export function newPassword(v) {
  if (typeof v !== "string" || v.length < 12 || v.length > 128)
    fail(422, "Use a password between 12 and 128 characters.");
  return v;
}
export async function limit(db, key, max = 30, period = 900000) {
  const now = Date.now(),
    bucket = blind(key);
  await db.run(
    "INSERT INTO rate_limits VALUES(?,1,?) ON CONFLICT(bucket) DO UPDATE SET count=CASE WHEN expires_at<? THEN 1 ELSE count+1 END,expires_at=CASE WHEN expires_at<? THEN excluded.expires_at ELSE expires_at END",
    [bucket, now + period, now, now],
  );
  if (
    (await db.one("SELECT count FROM rate_limits WHERE bucket=?", [bucket]))
      .count > max
  )
    fail(429, "Too many requests. Please try again later.");
}
export async function notify(db, user, message, category, event = null) {
  if (user)
    await db.run(
      "INSERT OR IGNORE INTO notifications(id,user_id,message,category,event_key) VALUES(?,?,?,?,?)",
      [id(), user, message, category, event],
    );
}
export const doctorUser = async (db) =>
  (await db.one("SELECT user_id FROM doctors WHERE id='clinic-doctor'"))
    ?.user_id;
export function requireRole(u, role) {
  if (!u) fail(401, "Please sign in to continue.");
  if (role && u.role !== role)
    fail(403, "You do not have access to this workspace.");
}
export async function assertPatient(db, u, p) {
  requireRole(u);
  if (typeof p !== "string" || p.length !== 36) fail(404, "Record not found.");
  if (u.role === "patient" && p !== u.id) fail(404, "Record not found.");
  const r = await db.one(
    "SELECT p.id FROM patients p LEFT JOIN doctors d ON d.id=p.doctor_id WHERE p.id=? AND (?='patient' OR d.user_id=?)",
    [p, u.role, u.id],
  );
  if (!r) fail(404, "Record not found.");
  return p;
}
export async function ownedAppointment(db, u, k) {
  requireRole(u);
  const a = await db.one("SELECT * FROM appointments WHERE id=?", [k || ""]);
  if (!a) fail(404, "Appointment not found.");
  await assertPatient(db, u, a.patient_id);
  return a;
}
export async function slots(db, day, exclude = "", past = false) {
  if (
    !dayValid(day) ||
    (!past &&
      (day < today() ||
        day > new Date(Date.now() + 91 * 86400000).toISOString().slice(0, 10)))
  )
    fail(422, "Choose a date within the next 90 days.");
  const duration = (
    await db.one("SELECT duration FROM doctors WHERE id='clinic-doctor'")
  ).duration;
  const rows = await db.all(
    "SELECT start_min,end_min FROM availability WHERE doctor_id='clinic-doctor' AND weekday=?",
    [new Date(day + "T12:00:00Z").getUTCDay()],
  );
  const exceptions = await db.all(
    "SELECT * FROM availability_exceptions WHERE doctor_id='clinic-doctor' AND day=?",
    [day],
  );
  const busy = await db.all(
    "SELECT start_min,start_min+duration end_min FROM appointments WHERE doctor_id='clinic-doctor' AND day=? AND status!='Cancelled' AND id!=?",
    [day, exclude],
  );
  const times = new Set();
  if (!exceptions.some((x) => x.kind === "Holiday"))
    for (const w of [...rows, ...exceptions.filter((x) => x.kind === "Extra")])
      for (let m = w.start_min; m + duration <= w.end_min; m += duration) {
        if (!past && day === today() && m <= pkMinute()) continue;
        if (
          ![...busy, ...exceptions.filter((x) => x.kind === "Blocked")].some(
            (x) => m < x.end_min && m + duration > x.start_min,
          )
        )
          times.add(m);
      }
  return {
    day,
    duration,
    slots: [...times].sort((a, b) => a - b),
    timezone: "Asia/Karachi",
  };
}
