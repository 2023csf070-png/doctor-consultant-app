import {
  id,
  fail,
  text,
  dayValid,
  today,
  pkMinute,
  seal,
  unseal,
  assertPatient,
  requireRole,
  ownedAppointment,
  notify,
  doctorUser,
  audit,
  limit,
} from "./db.mjs";
import { selectEducationTopic } from "./education.mjs";
export const disclaimer =
  "This AI information is for educational purposes only and is not a medical diagnosis. Please consult your doctor for professional medical advice.";
const education = [
  {
    id: "reports",
    test: /report|blood|cbc|haemoglobin|hemoglobin|lab|reference|hba1c/i,
    answer:
      "A laboratory report usually lists a test name, a measured value, a unit, and a reference range. A result outside that range does not, by itself, establish a diagnosis. Your doctor interprets it alongside your symptoms, history, and other findings. You can upload the report privately and bring your questions to your consultation.",
  },
  {
    id: "medicines",
    test: /medicin|tablet|drug|dose|prescri|stop|start|antibiotic/i,
    answer:
      "Your prescription records the medicine name, dose, frequency, and duration chosen by your doctor. If a label is unclear, ask your doctor or pharmacist before making any change. This guide cannot recommend a medicine, choose a dose, or advise starting or stopping treatment.",
  },
  {
    id: "visit",
    test: /prepare|visit|appointment|consult|bring/i,
    answer:
      "For your next consultation, bring a list of your current medicines, known allergies, relevant reports, and questions. It may help to note when a concern started and how it has changed. For a video visit, choose a private place and test your connection beforehand.",
  },
  {
    id: "followup",
    test: /follow.?up|progress/i,
    answer:
      "A follow-up is an opportunity to review your progress and discuss any new concerns with your doctor. Your doctor may record a suggested date in your prescription. A suggested date is not a confirmed appointment; request a suitable time in the booking calendar.",
  },
];
export async function clinicalOp(op, c) {
  const { db, u, b, q, res } = c;
  if (op === "patient.record") {
    const pid = u?.role === "patient" ? q.id || u.id : q.id;
    await assertPatient(db, u, pid);
    const p = await db.one(
      "SELECT u.id,u.name,u.email,u.phone,p.father_name,p.cnic_enc,p.dob,p.gender,p.city,p.address_enc FROM patients p JOIN users u ON u.id=p.id WHERE p.id=?",
      [pid],
    );
    const { cnic_enc, address_enc, ...personal } = p;
    const records = (
      await db.all(
        "SELECT * FROM medical_records WHERE patient_id=? ORDER BY created_at DESC LIMIT 200",
        [pid],
      )
    ).map(({ content_enc, ...r }) => ({ ...r, content: unseal(content_enc) }));
    const notes = (
      await db.all(
        "SELECT id,report_id,appointment_id,body_enc,created_at FROM doctor_notes WHERE patient_id=? ORDER BY created_at DESC LIMIT 200",
        [pid],
      )
    ).map(({ body_enc, ...r }) => ({ ...r, body: unseal(body_enc) }));
    const reports = (
      await db.all(
        "SELECT id,filename_enc,mime,size,created_at,appointment_id FROM medical_reports WHERE patient_id=? ORDER BY created_at DESC LIMIT 100",
        [pid],
      )
    ).map(({ filename_enc, ...r }) => ({
      ...r,
      filename: unseal(filename_enc),
    }));
    const rx = await db.all(
      "SELECT * FROM prescriptions WHERE patient_id=? ORDER BY created_at DESC LIMIT 100",
      [pid],
    );
    const items = await db.all(
      "SELECT i.* FROM prescription_items i JOIN prescriptions p ON p.id=i.prescription_id WHERE p.patient_id=? ORDER BY i.position",
      [pid],
    );
    const prescriptions = rx.map(({ diagnosis_enc, notes_enc, ...p }) => ({
      ...p,
      diagnosis: unseal(diagnosis_enc),
      notes: unseal(notes_enc),
      items: items
        .filter((i) => i.prescription_id === p.id)
        .map((i) => ({
          medicine: unseal(i.medicine_enc),
          dosage: unseal(i.dosage_enc),
          frequency: unseal(i.frequency_enc),
          duration: unseal(i.duration_enc),
          instructions: unseal(i.instructions_enc),
        })),
    }));
    const payments = await db.all(
      "SELECT id,amount_minor,currency,provider,status,created_at FROM payments WHERE patient_id=? ORDER BY created_at DESC LIMIT 100",
      [pid],
    );
    const consultations = (
      await db.all(
        "SELECT id,appointment_id,impression_enc,followup,created_at FROM consultations WHERE patient_id=? ORDER BY created_at DESC LIMIT 100",
        [pid],
      )
    ).map(({ impression_enc, ...r }) => ({
      ...r,
      impression: unseal(impression_enc),
    }));
    await audit(db, u.id, "clinical.record.viewed", pid);
    return {
      profile: {
        ...personal,
        cnic: unseal(cnic_enc),
        address: unseal(address_enc),
      },
      records,
      notes,
      reports,
      prescriptions,
      payments,
      consultations,
      cardEnabled: !!(
        process.env.STRIPE_SECRET_KEY &&
        process.env.STRIPE_WEBHOOK_SECRET &&
        process.env.PUBLIC_ORIGIN
      ),
    };
  }
  if (op === "report.upload") {
    requireRole(u);
    await limit(db, "upload:" + u.id, 20, 3600000);
    const pid = u.role === "patient" ? u.id : b.patient_id;
    await assertPatient(db, u, pid);
    const filename = text(b.filename, "filename", 150).replace(
      /[\/\\\r\n]/g,
      "_",
    );
    if (!/\.(pdf|jpe?g|png)$/i.test(filename))
      fail(422, "Choose a PDF, JPG, JPEG, or PNG file.");
    if (
      typeof b.data !== "string" ||
      b.data.length > 2800000 ||
      !b.data.match(/^[A-Za-z0-9+/]+={0,2}$/)
    )
      fail(422, "Choose a valid file no larger than 2 MB.");
    const bytes = Buffer.from(b.data, "base64");
    if (bytes.length > 2 * 1024 * 1024 || bytes.length < 16)
      fail(422, "The report must be between 16 bytes and 2 MB.");
    const ext = filename.split(".").pop().toLowerCase();
    let mime = "";
    if (
      bytes.subarray(0, 5).toString() === "%PDF-" &&
      bytes.subarray(-1024).includes(Buffer.from("%%EOF")) &&
      ext === "pdf"
    ) {
      if (
        /\/(?:JavaScript|JS|OpenAction|Launch|EmbeddedFile|RichMedia|XFA)\b/i.test(
          bytes.toString("latin1"),
        )
      )
        fail(
          422,
          "Active or embedded PDF content is not accepted. Upload a flattened report.",
        );
      mime = "application/pdf";
    } else if (
      bytes.subarray(0, 8).toString("hex") === "89504e470d0a1a0a" &&
      bytes.subarray(12, 16).toString() === "IHDR" &&
      bytes.subarray(-8, -4).toString() === "IEND" &&
      ext === "png"
    ) {
      if (bytes.readUInt32BE(16) * bytes.readUInt32BE(20) > 40000000)
        fail(422, "Image dimensions are too large.");
      mime = "image/png";
    } else if (
      bytes.subarray(0, 3).toString("hex") === "ffd8ff" &&
      bytes.subarray(-2).toString("hex") === "ffd9" &&
      ["jpg", "jpeg"].includes(ext)
    )
      mime = "image/jpeg";
    if (!mime || mime !== b.mime)
      fail(422, "The file contents do not match the selected file type.");
    const k = id();
    await db.tx(async (t) => {
      const total = await t.one(
        "SELECT COALESCE(SUM(size),0) n FROM medical_reports WHERE patient_id=?",
        [pid],
      );
      if (total.n + bytes.length > 100 * 1024 * 1024)
        fail(
          413,
          "The private storage limit has been reached. Contact the clinic.",
        );
      await t.run(
        "INSERT INTO medical_reports(id,patient_id,filename_enc,mime,size,content_enc) VALUES(?,?,?,?,?,?)",
        [k, pid, seal(filename), mime, bytes.length, seal(b.data)],
      );
      await notify(
        t,
        await doctorUser(t),
        "A private medical report is ready for review.",
        "Reports",
      );
      await audit(t, u.id, "report.uploaded", k);
    });
    return { id: k, filename, size: bytes.length };
  }
  if (op === "report.download") {
    requireRole(u);
    const r = await db.one(
      "SELECT patient_id,filename_enc,mime,content_enc FROM medical_reports WHERE id=?",
      [q.id || ""],
    );
    if (!r) fail(404, "Report not found.");
    await assertPatient(db, u, r.patient_id);
    await audit(db, u.id, "report.downloaded", q.id);
    res.setHeader("Content-Type", r.mime);
    res.setHeader(
      "Content-Disposition",
      "attachment; filename*=UTF-8''" +
        encodeURIComponent(unseal(r.filename_enc)),
    );
    res.setHeader("Content-Security-Policy", "default-src 'none'; sandbox");
    res.end(Buffer.from(unseal(r.content_enc), "base64"));
    return null;
  }
  if (
    op === "record.add" ||
    op === "note.add" ||
    op === "consultation.save" ||
    op === "prescription.save"
  ) {
    requireRole(u, "doctor");
    const pid = b.patient_id;
    await assertPatient(db, u, pid);
    let a;
    if (b.appointment_id) {
      a = await ownedAppointment(db, u, b.appointment_id);
      if (a.patient_id !== pid)
        fail(422, "The visit does not belong to this patient.");
    }
    if (b.report_id) {
      const r = await db.one(
        "SELECT patient_id FROM medical_reports WHERE id=?",
        [b.report_id],
      );
      if (r?.patient_id !== pid) fail(404, "Report not found.");
    }
    const k = id();
    return db.tx(async (t) => {
      if (op === "record.add") {
        if (
          ![
            "Medical history",
            "Allergies",
            "Current medicines",
            "Conditions",
            "Clinical impression",
          ].includes(b.category)
        )
          fail(422, "Select a clinical record category.");
        await t.run(
          "INSERT INTO medical_records(id,patient_id,doctor_id,category,content_enc) VALUES(?,?,?,?,?)",
          [
            k,
            pid,
            "clinic-doctor",
            b.category,
            seal(text(b.content, "clinical record", 6000)),
          ],
        );
      }
      if (op === "note.add")
        await t.run(
          "INSERT INTO doctor_notes(id,patient_id,doctor_id,report_id,appointment_id,body_enc) VALUES(?,?,?,?,?,?)",
          [
            k,
            pid,
            "clinic-doctor",
            b.report_id || null,
            b.appointment_id || null,
            seal(text(b.content, "doctor note", 6000)),
          ],
        );
      if (op === "consultation.save") {
        if (!a || !["Confirmed", "Completed"].includes(a.status))
          fail(409, "A confirmed appointment is required.");
        if (a.day > today() || (a.day === today() && a.start_min > pkMinute()))
          fail(409, "Record the summary after the consultation starts.");
        if (
          await t.one("SELECT id FROM consultations WHERE appointment_id=?", [
            a.id,
          ])
        )
          fail(
            409,
            "Consultation summary is already saved. Add a new note instead.",
          );
        if (b.followup && (!dayValid(b.followup) || b.followup < today()))
          fail(422, "Choose a valid follow-up date.");
        await t.run(
          "INSERT INTO consultations(id,appointment_id,patient_id,doctor_id,impression_enc,followup) VALUES(?,?,?,?,?,?)",
          [
            k,
            a.id,
            pid,
            "clinic-doctor",
            seal(text(b.content, "clinical impression", 6000)),
            b.followup || null,
          ],
        );
      }
      if (op === "prescription.save") {
        const diagnosis = text(b.diagnosis, "clinical impression", 2000),
          notes = text(b.notes || "", "notes", 3000, false);
        if (b.followup && (!dayValid(b.followup) || b.followup < today()))
          fail(422, "Choose a valid follow-up date.");
        if (!Array.isArray(b.items) || !b.items.length || b.items.length > 30)
          fail(422, "Add between 1 and 30 medicine items.");
        await t.run(
          "INSERT INTO prescriptions(id,patient_id,doctor_id,appointment_id,diagnosis_enc,notes_enc,followup) VALUES(?,?,?,?,?,?,?)",
          [
            k,
            pid,
            "clinic-doctor",
            b.appointment_id || null,
            seal(diagnosis),
            seal(notes),
            b.followup || null,
          ],
        );
        for (const [i, m] of b.items.entries())
          await t.run(
            "INSERT INTO prescription_items VALUES(?,?,?,?,?,?,?,?)",
            [
              id(),
              k,
              i,
              seal(text(m.medicine, "medicine name", 180)),
              seal(text(m.dosage, "dosage", 120)),
              seal(text(m.frequency, "frequency", 120)),
              seal(text(m.duration, "duration", 120)),
              seal(text(m.instructions || "", "instructions", 500, false)),
            ],
          );
        await notify(
          t,
          pid,
          "A new prescription from your doctor is available.",
          "Prescriptions",
        );
      } else
        await notify(
          t,
          pid,
          "Your doctor has added an update to your medical record.",
          "Records",
        );
      await audit(t, u.id, op, k);
      return { id: k, saved: true };
    });
  }
  if (op === "education") {
    requireRole(u, "patient");
    await limit(db, "education:" + u.id, 40, 3600000);
    const prompt = text(b.question, "question", 800);
    let topic = null;
    const urgent =
      /chest pain|cannot breathe|can.t breathe|severe bleed|unconscious|suicid|overdose|stroke|emergency/i.test(
        prompt,
      );
    if (!urgent && b.ai_consent === true)
      topic = await selectEducationTopic(
        prompt,
        education.map((x) => x.id),
      );
    let answer;
    if (urgent || topic === "emergency")
      answer =
        "Please seek immediate local emergency medical care or call your local emergency service. Do not wait for an online reply or a clinic appointment. This guide cannot assess the urgency of your symptoms.";
    else
      answer =
        education.find((e) => (topic ? e.id === topic : e.test.test(prompt)))
          ?.answer ||
        "I can explain general report terminology, prescription labels, and how to prepare for a visit. I cannot assess personal symptoms, diagnose a condition, or choose treatment. For a concern about your health, arrange a consultation with your doctor. If you think it may be an emergency, seek immediate local emergency care.";
    return {
      answer,
      disclaimer,
      mode: topic
        ? "AI-matched, curated educational guidance"
        : "Curated educational guidance",
    };
  }
}
