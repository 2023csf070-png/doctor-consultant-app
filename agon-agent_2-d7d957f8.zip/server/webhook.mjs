import { withDatabase, Problem } from "./db.mjs";
import { stripeEvent } from "./providers.mjs";
export const config = { api: { bodyParser: false } };
export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") {
    res.statusCode = 405;
    return res.end();
  }
  try {
    const chunks = [];
    let n = 0;
    for await (const chunk of req) {
      n += chunk.length;
      if (n > 100000) throw new Problem(413, "Too large");
      chunks.push(chunk);
    }
    await withDatabase((db) =>
      stripeEvent(
        db,
        Buffer.concat(chunks).toString("utf8"),
        req.headers["stripe-signature"],
      ),
    );
    res.end('{"received":true}');
  } catch (e) {
    res.statusCode = e instanceof Problem ? e.status : 500;
    res.end('{"error":"Provider confirmation was not accepted."}');
  }
}
