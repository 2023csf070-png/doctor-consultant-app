import { withDatabase, Problem, fail, preview, limit } from "./db.mjs";
import { session, authOp } from "./auth.mjs";
import { workflow } from "./workflow.mjs";
import { clinicalOp } from "./clinical.mjs";
import { providerOp } from "./providers.mjs";
import { PRIVATE_SHELL } from "./compiled-assets.mjs";
const reads = new Set([
  "page",
  "session",
  "services",
  "slots",
  "availability",
  "patients",
  "dashboard",
  "patient.record",
  "report.download",
  "zoom.join",
]);
async function body(req) {
  if (req.body && typeof req.body === "object") return req.body;
  if (typeof req.body === "string") {
    if (req.body.length > 3000000) fail(413, "Request too large.");
    try {
      return JSON.parse(req.body);
    } catch {
      fail(400, "Invalid request.");
    }
  }
  const chunks = [];
  let n = 0;
  for await (const chunk of req) {
    n += chunk.length;
    if (n > 3000000) fail(413, "The upload is too large.");
    chunks.push(chunk);
  }
  try {
    return n ? JSON.parse(Buffer.concat(chunks).toString("utf8")) : {};
  } catch {
    fail(400, "Invalid request.");
  }
}
export default async function handler(req, res) {
  res.setHeader("Cache-Control", "private, no-store, max-age=0");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  try {
    const url = new URL(req.url, "http://clinic.local"),
      q = Object.fromEntries(url.searchParams),
      op = q.op || "session";
    if (req.method !== (reads.has(op) ? "GET" : "POST"))
      fail(405, "This request method is not allowed.");
    const mutation = req.method === "POST";
    if (mutation) {
      if (!(req.headers["content-type"] || "").startsWith("application/json"))
        fail(415, "JSON content is required.");
      const origin = req.headers.origin;
      if (origin) {
        let expected = process.env.PUBLIC_ORIGIN;
        if (!expected)
          expected =
            (req.headers["x-forwarded-proto"] === "https" || process.env.VERCEL
              ? "https"
              : "http") +
            "://" +
            req.headers.host;
        if (origin !== expected)
          fail(403, "The request origin is not permitted.");
      }
      if (req.headers["sec-fetch-site"] === "cross-site")
        fail(403, "Cross-site requests are not allowed.");
    }
    const b = mutation ? await body(req) : {};
    if (!b || Array.isArray(b) || typeof b !== "object")
      fail(422, "Invalid request data.");
    const result = await withDatabase(async (db) => {
      const ip = String(
        process.env.VERCEL
          ? req.headers["x-vercel-forwarded-for"] ||
              req.headers["x-real-ip"] ||
              "edge"
          : req.socket?.remoteAddress || "local",
      ).split(",")[0];
      await limit(db, "api:" + ip, 360, 60000);
      const u = await session(db, req);
      if (op === "page") {
        const role = q.role === "doctor" ? "doctor" : "patient";
        res.setHeader("X-Robots-Tag", "noindex, nofollow");
        if (!u || u.role !== role) {
          res.statusCode = 302;
          res.setHeader(
            "Location",
            "/" +
              role +
              "/login?next=" +
              encodeURIComponent("/" + role + "/dashboard"),
          );
          res.end();
          return null;
        }
        res.setHeader("Content-Type", "text/html; charset=utf-8");
        res.end(PRIVATE_SHELL);
        return null;
      }
      if (
        mutation &&
        u &&
        !["login", "signup", "forgot", "reset"].includes(op) &&
        req.headers["x-csrf-token"] !== u.csrf
      )
        fail(403, "Your session check failed. Reload and try again.");
      const ctx = { db, req, res, q, b, u, ip };
      for (const fn of [authOp, workflow, clinicalOp, providerOp]) {
        const v = await fn(op, ctx);
        if (v !== undefined) return v;
      }
      fail(404, "This clinic action was not found.");
    });
    if (!res.writableEnded) {
      res.statusCode = 200;
      res.end(
        JSON.stringify({ ...result, ...(op === "session" ? { preview } : {}) }),
      );
    }
  } catch (e) {
    if (res.writableEnded) return;
    let status = e instanceof Problem ? e.status : 500,
      message =
        e instanceof Problem
          ? e.message
          : "The clinic service could not complete your request. Please try again.";
    if (
      /slot unavailable|UNIQUE constraint failed: appointments/.test(e.message)
    ) {
      status = 409;
      message = "This slot has just been booked. Please choose another time.";
    }
    if (status === 500)
      console.error(
        "Clinic operation failed:",
        e.name === "Error" ? "service_error" : String(e.name).slice(0, 50),
      );
    res.statusCode = status;
    res.end(JSON.stringify({ error: message }));
  }
}
export const config = { api: { bodyParser: { sizeLimit: "3mb" } } };
