import {
  id,
  fail,
  seal,
  unseal,
  text,
  phoneNumber,
  dayValid,
  today,
  pkMinute,
  slots,
  requireRole,
  assertPatient,
  ownedAppointment,
  notify,
  doctorUser,
  audit,
  blind,
} from "./db.mjs";
import { removeZoom } from "./providers.mjs";
import { dashboard } from "./dashboard.mjs";
export const visitTypes = [
  "General Consultation",
  "Disease Consultation",
  "Online Video Consultation",
  "Follow-up Consultation",
];
const time = (t) =>
  `${String(Math.floor(t / 60)).padStart(2, "0")}:${String(t % 60).padStart(2, "0")}`;
const validStart = (n) => Number.isInteger(n) && n >= 0 && n <= 1439;
const openStatus = (a) => {
  if (!["Pending", "Confirmed"].includes(a.status))
    fail(409, "This appointment is already closed.");
};
async function validateSchedule(t) {
  const active = await t.all(
    "SELECT * FROM appointments WHERE day>=? AND status IN ('Pending','Confirmed')",
    [today()],
  );
  for (const a of active) {
    const v = await slots(t, a.day, a.id, true);
    if (!v.slots.includes(a.start_min) || a.duration !== v.duration)
      fail(
        409,
        "This change conflicts with an existing appointment. Reschedule or cancel that visit first.",
      );
  }
}
export async function workflow(op, c) {
  const { db, u, b, q } = c;
  if (op === "services")
    return {
      services: await db.all(
        'SELECT id,name,description,detail,icon,tone,category AS "group" FROM services ORDER BY position',
      ),
    };
  if (op === "slots") return slots(db, q.day);
  if (op === "availability") {
    requireRole(u, "doctor");
    return {
      weekly: await db.all(
        "SELECT weekday,start_min,end_min FROM availability ORDER BY weekday,start_min",
      ),
      exceptions: await db.all(
        "SELECT * FROM availability_exceptions WHERE day>=? ORDER BY day,start_min",
        [today()],
      ),
      duration: (
        await db.one("SELECT duration FROM doctors WHERE user_id=?", [u.id])
      ).duration,
    };
  }
  if (op === "availability.save") {
    requireRole(u, "doctor");
    if (
      !Array.isArray(b.weekly) ||
      b.weekly.length > 70 ||
      !Number.isInteger(b.duration) ||
      b.duration < 10 ||
      b.duration > 120
    )
      fail(422, "Choose a slot duration between 10 and 120 minutes.");
    const seen = [];
    for (const w of b.weekly) {
      if (
        !Number.isInteger(w.weekday) ||
        w.weekday < 0 ||
        w.weekday > 6 ||
        !validStart(w.start_min) ||
        !Number.isInteger(w.end_min) ||
        w.end_min > 1440 ||
        w.end_min - w.start_min < b.duration
      )
        fail(422, "Each session must fit at least one full appointment.");
      if (
        seen.some(
          (x) =>
            x.weekday === w.weekday &&
            x.start_min < w.end_min &&
            x.end_min > w.start_min,
        )
      )
        fail(422, "Working sessions must not overlap.");
      seen.push(w);
    }
    await db.tx(async (t) => {
      await t.run("DELETE FROM availability WHERE doctor_id='clinic-doctor'");
      for (const w of seen)
        await t.run(
          "INSERT INTO availability(doctor_id,weekday,start_min,end_min) VALUES('clinic-doctor',?,?,?)",
          [w.weekday, w.start_min, w.end_min],
        );
      await t.run("UPDATE doctors SET duration=? WHERE user_id=?", [
        b.duration,
        u.id,
      ]);
      await validateSchedule(t);
      await audit(t, u.id, "availability.updated", "clinic-doctor");
    });
    return { saved: true };
  }
  if (op === "exception.save" || op === "exception.remove") {
    requireRole(u, "doctor");
    await db.tx(async (t) => {
      if (op === "exception.remove")
        await t.run(
          "DELETE FROM availability_exceptions WHERE id=? AND doctor_id='clinic-doctor'",
          [text(b.id, "exception ID", 64)],
        );
      else {
        if (
          !dayValid(b.day) ||
          b.day < today() ||
          !["Holiday", "Blocked", "Extra"].includes(b.kind)
        )
          fail(422, "Choose a valid date and exception type.");
        const a = b.kind === "Holiday" ? 0 : b.start_min,
          e = b.kind === "Holiday" ? 1440 : b.end_min;
        if (!validStart(a) || !Number.isInteger(e) || e <= a || e > 1440)
          fail(422, "End time must follow start time.");
        if (
          await t.one(
            "SELECT id FROM availability_exceptions WHERE day=? AND start_min<? AND end_min>?",
            [b.day, e, a],
          )
        )
          fail(409, "An exception already covers this time.");
        if (
          b.kind === "Extra" &&
          (await t.one(
            "SELECT id FROM availability WHERE weekday=? AND start_min<? AND end_min>?",
            [new Date(b.day + "T12:00:00Z").getUTCDay(), e, a],
          ))
        )
          fail(
            409,
            "Special availability must not overlap normal clinic hours.",
          );
        await t.run("INSERT INTO availability_exceptions VALUES(?,?,?,?,?,?)", [
          id(),
          "clinic-doctor",
          b.day,
          b.kind,
          a,
          e,
        ]);
      }
      await validateSchedule(t);
      await audit(t, u.id, "availability.exception", "clinic-doctor");
    });
    return { saved: true };
  }
  if (op === "service.save") {
    requireRole(u, "doctor");
    const name = text(b.name, "service title", 80),
      description = text(b.description, "service description", 180),
      detail = text(b.detail, "service detail", 1500);
    if (!(await db.one("SELECT id FROM services WHERE id=?", [b.id || ""])))
      fail(404, "Service not found.");
    await db.run(
      "UPDATE services SET name=?,description=?,detail=? WHERE id=?",
      [name, description, detail, b.id],
    );
    await audit(db, u.id, "service.updated", b.id);
    return { saved: true };
  }
  if (op === "book") {
    requireRole(u);
    const pid = u.role === "patient" ? u.id : b.patient_id;
    await assertPatient(db, u, pid);
    if (!visitTypes.includes(b.type) || !validStart(b.start_min))
      fail(422, "Choose a consultation type and available time.");
    const reason = text(b.reason, "reason for visiting", 2000),
      aid = id(),
      reference = "BAC-" + id().slice(0, 8).toUpperCase();
    return db.tx(async (t) => {
      const s = await slots(t, b.day);
      if (!s.slots.includes(b.start_min))
        fail(
          409,
          "That time is no longer available. Please choose another slot.",
        );
      await t.run(
        "INSERT INTO appointments(id,reference,patient_id,doctor_id,type,day,start_min,duration,reason_enc) VALUES(?,?,?,?,?,?,?,?,?)",
        [
          aid,
          reference,
          pid,
          "clinic-doctor",
          b.type,
          b.day,
          b.start_min,
          s.duration,
          seal(reason),
        ],
      );
      if (b.report_id) {
        const r = await t.one(
          "SELECT patient_id,appointment_id FROM medical_reports WHERE id=?",
          [b.report_id],
        );
        if (!r || r.patient_id !== pid || r.appointment_id)
          fail(422, "That report cannot be attached to this visit.");
        await t.run("UPDATE medical_reports SET appointment_id=? WHERE id=?", [
          aid,
          b.report_id,
        ]);
      }
      await notify(
        t,
        pid,
        `Appointment ${reference} requested. Awaiting doctor confirmation.`,
        "Appointments",
      );
      await notify(
        t,
        await doctorUser(t),
        `New ${b.type === "Online Video Consultation" ? "online " : ""}appointment request for ${b.day} at ${time(b.start_min)}.`,
        "Appointments",
      );
      await audit(t, u.id, "appointment.created", aid);
      return {
        id: aid,
        reference,
        status: "Pending",
        day: b.day,
        start_min: b.start_min,
        type: b.type,
      };
    });
  }
  if (op === "appointment.change") {
    requireRole(u);
    return db.tx(async (t) => {
      const a = await ownedAppointment(t, u, b.id);
      openStatus(a);
      let status = b.status;
      if (b.action === "reschedule") {
        const s = await slots(t, b.day, a.id);
        if (!validStart(b.start_min) || !s.slots.includes(b.start_min))
          fail(409, "The selected time is unavailable.");
        await removeZoom(t, a.id);
        status = u.role === "patient" ? "Pending" : "Confirmed";
        await t.run(
          "UPDATE appointments SET day=?,start_min=?,duration=?,status=? WHERE id=?",
          [b.day, b.start_min, s.duration, status, a.id],
        );
      } else {
        if (u.role === "patient" && status !== "Cancelled")
          fail(403, "Only the doctor can confirm or complete a visit.");
        if (!["Confirmed", "Cancelled", "Completed"].includes(status))
          fail(422, "Invalid appointment status.");
        if (
          status === "Completed" &&
          (a.status !== "Confirmed" ||
            a.day > today() ||
            (a.day === today() && a.start_min > pkMinute()))
        )
          fail(
            409,
            "Only a confirmed visit that has started can be completed.",
          );
        if (status === a.status)
          fail(409, "The appointment already has that status.");
        if (
          status === "Confirmed" &&
          (a.day < today() ||
            (a.day === today() && a.start_min + a.duration < pkMinute()))
        )
          fail(409, "Reschedule this past request before confirming.");
        if (status === "Cancelled") await removeZoom(t, a.id);
        await t.run("UPDATE appointments SET status=? WHERE id=?", [
          status,
          a.id,
        ]);
      }
      const msg = `Appointment ${a.reference} ${b.action === "reschedule" ? "rescheduled to " + b.day + " at " + time(b.start_min) : status.toLowerCase()}.`;
      await notify(t, a.patient_id, msg, "Appointments");
      if (u.role === "patient")
        await notify(t, await doctorUser(t), msg, "Appointments");
      await audit(
        t,
        u.id,
        "appointment." +
          (b.action === "reschedule" ? "rescheduled" : status.toLowerCase()),
        a.id,
      );
      return { status };
    });
  }
  if (op === "patients") {
    requireRole(u, "doctor");
    const s = String(q.search || "").slice(0, 100),
      pattern = "%" + s.replace(/[\%_]/g, "") + "%";
    const patients = await db.all(
      "SELECT u.id,u.name,u.phone,p.city,p.gender,p.dob,u.created_at FROM patients p JOIN users u ON p.id=u.id JOIN doctors d ON d.id=p.doctor_id WHERE d.user_id=? AND (u.name LIKE ? OR u.phone LIKE ? OR u.id LIKE ? OR p.cnic_hash=?) ORDER BY u.created_at DESC LIMIT 100",
      [
        u.id,
        pattern,
        pattern,
        "%" + s.replace(/^P-/i, "") + "%",
        blind(s.replace(/[-\s]/g, "")),
      ],
    );
    await audit(db, u.id, "patient.directory.viewed", null);
    return { patients };
  }
  if (op === "dashboard") return dashboard(db, u, q);
  if (op === "notification.read") {
    requireRole(u);
    if (b.id)
      await db.run(
        "UPDATE notifications SET read_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=?",
        [b.id, u.id],
      );
    else
      await db.run(
        "UPDATE notifications SET read_at=CURRENT_TIMESTAMP WHERE user_id=? AND read_at IS NULL",
        [u.id],
      );
    return { saved: true };
  }
  if (op === "profile.save") {
    requireRole(u, "patient");
    const name = text(b.name, "name", 100),
      city = text(b.city, "city", 80),
      address = text(b.address, "address", 450),
      phone = phoneNumber(b.phone);
    if (!/^03\d{9}$/.test(phone))
      fail(422, "Enter a valid Pakistani mobile number.");
    await db.tx(async (t) => {
      if (
        await t.one("SELECT id FROM users WHERE phone=? AND id!=?", [
          phone,
          u.id,
        ])
      )
        fail(409, "That phone number cannot be used.");
      await t.run("UPDATE users SET name=?,phone=? WHERE id=?", [
        name,
        phone,
        u.id,
      ]);
      await t.run("UPDATE patients SET city=?,address_enc=? WHERE id=?", [
        city,
        seal(address),
        u.id,
      ]);
      await audit(t, u.id, "profile.updated", u.id);
    });
    return { saved: true };
  }
}
