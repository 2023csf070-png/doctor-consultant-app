import {
  requireRole,
  assertPatient,
  unseal,
  today,
  pkMinute,
  notify,
  audit,
} from "./db.mjs";
import { aiAvailable } from "./education.mjs";
/** Patient/doctor scoping is shared by counts, calendar and paginated list queries. */
export async function dashboard(db, u, q) {
  requireRole(u);
  const scope = u.role === "doctor" ? "d.user_id=?" : "a.patient_id=?";
  const source = " FROM appointments a JOIN doctors d ON d.id=a.doctor_id ";
  const current = today();
  const upcoming =
    "(a.day>? OR (a.day=? AND a.start_min+a.duration>?)) AND a.status IN ('Pending','Confirmed')";
  const nowArgs = [current, current, pkMinute()];
  const stats = await db.one(
    `SELECT COUNT(*) total,COUNT(CASE WHEN a.day=? THEN 1 END) todayCount,COUNT(CASE WHEN a.status='Pending' THEN 1 END) pending,COUNT(CASE WHEN a.status='Completed' THEN 1 END) completed,COUNT(CASE WHEN a.status='Cancelled' THEN 1 END) cancelled,COUNT(CASE WHEN a.type='Online Video Consultation' THEN 1 END) online,COUNT(CASE WHEN ${upcoming} THEN 1 END) upcoming,COUNT(CASE WHEN ${upcoming} AND a.type='Online Video Consultation' THEN 1 END) upcomingOnline${source}WHERE ${scope}`,
    [current, ...nowArgs, ...nowArgs, u.id],
  );
  let where = scope;
  const args = [u.id];
  if (q.patient && u.role === "doctor") {
    await assertPatient(db, u, q.patient);
    where += " AND a.patient_id=?";
    args.push(q.patient);
  }
  if (q.scope === "upcoming") {
    where += " AND " + upcoming;
    args.push(...nowArgs);
  }
  if (["Pending", "Confirmed", "Cancelled", "Completed"].includes(q.status)) {
    where += " AND a.status=?";
    args.push(q.status);
  }
  if (q.online === "1") where += " AND a.type='Online Video Consultation'";
  const calendar =
    typeof q.month === "string" && /^\d{4}-(0[1-9]|1[0-2])$/.test(q.month);
  if (calendar) {
    where += " AND a.day>=? AND a.day<=?";
    args.push(q.month + "-01", q.month + "-31");
  }
  const count = (
    await db.one("SELECT COUNT(*) n" + source + "WHERE " + where, args)
  ).n;
  const size = calendar ? 4500 : 50,
    pages = Math.max(1, Math.ceil(count / size)),
    page = Math.max(
      0,
      Math.min(Number.parseInt(q.page || "0", 10) || 0, pages - 1),
    );
  const order =
    q.scope === "upcoming"
      ? "a.day ASC,a.start_min ASC"
      : "a.day DESC,a.start_min DESC";
  const rows = await db.all(
    `SELECT a.id,a.reference,a.patient_id,a.day,a.type,a.start_min,a.duration,a.status,a.reason_enc,p.name patient_name,CASE WHEN z.appointment_id IS NULL THEN 0 ELSE 1 END has_zoom ${source} JOIN users p ON p.id=a.patient_id LEFT JOIN zoom_meetings z ON z.appointment_id=a.id WHERE ${where} ORDER BY ${order} LIMIT ? OFFSET ?`,
    [...args, size, page * size],
  );
  const appointments = rows.map(({ reason_enc, ...a }) => ({
    ...a,
    reason: unseal(reason_enc),
  }));
  if (u.role === "patient") {
    for (const a of await db.all(
      "SELECT id,day,start_min FROM appointments WHERE patient_id=? AND day=? AND status='Confirmed' AND type='Online Video Consultation' AND start_min+duration>?",
      [u.id, current, pkMinute()],
    )) {
      const label =
        String(Math.floor(a.start_min / 60)).padStart(2, "0") +
        ":" +
        String(a.start_min % 60).padStart(2, "0");
      await notify(
        db,
        u.id,
        `Your online consultation is scheduled today at ${label} PKT.`,
        "Reminder",
        "online:" + a.id + ":" + a.day,
      );
    }
    for (const p of await db.all(
      "SELECT id FROM prescriptions WHERE patient_id=? AND followup=?",
      [u.id, current],
    ))
      await notify(
        db,
        u.id,
        "Your doctor recommended a follow-up today. Review your prescription.",
        "Follow-up",
        "followup:" + p.id,
      );
  }
  const notifications = await db.all(
    "SELECT id,message,category,read_at,created_at FROM notifications WHERE user_id=? ORDER BY created_at DESC,rowid DESC LIMIT 100",
    [u.id],
  );
  const unread = (
    await db.one(
      "SELECT COUNT(*) n FROM notifications WHERE user_id=? AND read_at IS NULL",
      [u.id],
    )
  ).n;
  const totalPatients =
    u.role === "doctor"
      ? (
          await db.one(
            "SELECT COUNT(*) n FROM patients p JOIN doctors d ON d.id=p.doctor_id WHERE d.user_id=?",
            [u.id],
          )
        ).n
      : 0;
  await audit(db, u.id, "dashboard.viewed", u.id);
  return {
    appointments,
    notifications,
    unread,
    totalPatients,
    today: current,
    stats,
    page,
    pages,
    count,
    aiEnabled: aiAvailable(),
    zoomEnabled: !!(
      process.env.ZOOM_ACCOUNT_ID &&
      process.env.ZOOM_CLIENT_ID &&
      process.env.ZOOM_CLIENT_SECRET &&
      process.env.ZOOM_USER_ID
    ),
  };
}
