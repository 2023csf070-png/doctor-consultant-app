import { randomBytes } from "node:crypto";
import { verifyMfa } from "./mfa.mjs";
import { mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import {
  id,
  sha,
  blind,
  seal,
  fail,
  text,
  phoneNumber,
  dayValid,
  today,
  newPassword,
  hashPassword,
  verifyPassword,
  requireRole,
  limit,
  notify,
  doctorUser,
  audit,
  dataDir,
} from "./db.mjs";
const token = () => randomBytes(32).toString("hex");
const safeUser = (u) => ({
  id: u.id,
  name: u.name,
  email: u.email,
  role: u.role,
});
const cookie = (name, value, time, secure) =>
  `${name}=${value}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${time}${secure ? "; Secure" : ""}`;
export async function session(db, req) {
  const raw = (req.headers.authorization || "").startsWith("Bearer ")
    ? req.headers.authorization.slice(7)
    : (/(?:^|;\s*)clinic_session=([a-f0-9]{64})(?:;|$)/.exec(
        req.headers.cookie || "",
      ) || [])[1];
  if (!raw || raw.length !== 64) return null;
  const s = await db.one(
    "SELECT u.id,u.name,u.email,u.role,s.csrf,s.token_hash FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?",
    [sha(raw), Date.now()],
  );
  return s || null;
}
async function start(db, req, res, u) {
  const raw = token(),
    csrf = token(),
    secure =
      !!process.env.VERCEL ||
      process.env.NODE_ENV === "production" ||
      req.headers["x-forwarded-proto"] === "https";
  await db.run("DELETE FROM sessions WHERE expires_at<?", [Date.now()]);
  await db.run("INSERT INTO sessions VALUES(?,?,?,?)", [
    sha(raw),
    u.id,
    csrf,
    Date.now() + 8 * 3600000,
  ]);
  res.setHeader("Set-Cookie", cookie("clinic_session", raw, 8 * 3600, secure));
  return {
    user: safeUser(u),
    csrf,
    ...(req.headers["x-clinic-client"] === "native" && !req.headers.origin
      ? { sessionToken: raw }
      : {}),
  };
}
export async function authOp(op, c) {
  const { db, req, res, b, u, ip } = c;
  if (op === "session")
    return { user: u ? safeUser(u) : null, csrf: u?.csrf || null };
  if (op === "signup") {
    await limit(db, "signup:" + ip, 8, 3600000);
    const name = text(b.name, "full name", 100),
      father = text(b.father_name, "father or husband name", 100),
      email = text(b.email, "email", 180).toLowerCase(),
      phone = phoneNumber(b.phone),
      cnic = String(b.cnic || "").replace(/[-\s]/g, "");
    const pw = newPassword(b.password);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
      fail(422, "Enter a valid email address.");
    if (!/^03\d{9}$/.test(phone))
      fail(422, "Enter a Pakistani mobile number, for example 03XX XXXXXXX.");
    if (!/^\d{13}$/.test(cnic)) fail(422, "CNIC must contain 13 digits.");
    if (!dayValid(b.dob) || b.dob > today() || b.dob < "1900-01-01")
      fail(422, "Enter a valid date of birth.");
    if (!["Male", "Female", "Other", "Prefer not to say"].includes(b.gender))
      fail(422, "Please select your gender.");
    if (pw !== b.confirmation) fail(422, "The passwords do not match.");
    if (b.consent !== true) fail(422, "Privacy consent is required.");
    const address = text(b.address, "address", 450),
      city = text(b.city, "city", 80),
      uid = id(),
      hash = await hashPassword(pw);
    await db.tx(async (t) => {
      if (
        (await t.one("SELECT id FROM users WHERE email=? OR phone=?", [
          email,
          phone,
        ])) ||
        (await t.one("SELECT id FROM patients WHERE cnic_hash=?", [
          blind(cnic),
        ]))
      )
        fail(
          409,
          "An account already uses these details. Sign in or use password recovery.",
        );
      await t.run(
        "INSERT INTO users(id,role,name,email,phone,password_hash) VALUES(?,?,?,?,?,?)",
        [uid, "patient", name, email, phone, hash],
      );
      await t.run(
        "INSERT INTO patients(id,doctor_id,father_name,cnic_hash,cnic_enc,dob,gender,address_enc,city) VALUES(?,?,?,?,?,?,?,?,?)",
        [
          uid,
          "clinic-doctor",
          father,
          blind(cnic),
          seal(cnic),
          b.dob,
          b.gender,
          seal(address),
          city,
        ],
      );
      await notify(
        t,
        await doctorUser(t),
        "A new patient has registered.",
        "Patients",
      );
      await audit(t, uid, "account.created", uid);
    });
    return { created: true };
  }
  if (op === "login") {
    const login = text(
        b.identifier,
        "email, phone, or username",
        180,
      ).toLowerCase(),
      pw =
        typeof b.password === "string" &&
        b.password.length > 0 &&
        b.password.length <= 128
          ? b.password
          : fail(422, "Enter a valid password.");
    await limit(db, "login:" + ip, 25);
    await limit(db, "identity:" + login, 12);
    const role = b.role === "doctor" ? "doctor" : "patient";
    const user = await db.one(
      "SELECT * FROM users WHERE role=? AND (email=? OR phone=? OR username=?)",
      [role, login, phoneNumber(login), login],
    );
    const hash = user?.password_hash || "unspecified:" + "0".repeat(128);
    const valid = await verifyPassword(pw, hash);
    if (!valid || !user) fail(401, "The sign-in details are incorrect.");
    if (
      role === "doctor" &&
      !(await db.one("SELECT id FROM doctors WHERE user_id=?", [user.id]))
    )
      fail(403, "Doctor access is not provisioned.");
    if (role === "doctor") await verifyMfa(db, user.id, b.otp);
    await audit(db, user.id, "session.started", user.id);
    return start(db, req, res, user);
  }
  if (op === "logout") {
    requireRole(u);
    await db.run("DELETE FROM sessions WHERE token_hash=?", [u.token_hash]);
    res.setHeader(
      "Set-Cookie",
      cookie(
        "clinic_session",
        "",
        0,
        !!process.env.VERCEL || process.env.NODE_ENV === "production",
      ),
    );
    return { signedOut: true };
  }
  if (op === "forgot") {
    await limit(db, "reset:" + ip, 6, 3600000);
    const email = text(b.email, "email", 180).toLowerCase();
    const localMail =
      process.env.CLINIC_TEST_MAIL === "1" &&
      process.env.NODE_ENV !== "production" &&
      !process.env.VERCEL;
    if (!process.env.SMTP_HOST && !localMail)
      fail(
        503,
        "Email recovery is not connected. Please call the clinic on 0302 0460461 for account assistance.",
      );
    const usr = await db.one(
      "SELECT id,email FROM users WHERE email=? AND role=?",
      [email, b.role === "doctor" ? "doctor" : "patient"],
    );
    if (usr) {
      const reset = token(),
        origin =
          process.env.PUBLIC_ORIGIN ||
          (localMail ? "http://localhost:8080" : "");
      if (!origin) fail(503, "Password recovery is not configured.");
      const link = `${origin}/reset-password#${reset}`;
      await db.tx(async (t) => {
        await t.run(
          "DELETE FROM reset_tokens WHERE user_id=? OR expires_at<?",
          [usr.id, Date.now()],
        );
        await t.run("INSERT INTO reset_tokens VALUES(?,?,?)", [
          sha(reset),
          usr.id,
          Date.now() + 20 * 60000,
        ]);
      });
      if (localMail) {
        mkdirSync(join(dataDir, "test-mail"), { mode: 0o700, recursive: true });
        writeFileSync(join(dataDir, "test-mail", usr.id + ".txt"), link, {
          mode: 0o600,
        });
      } else {
        try {
          const { default: mailer } = await import("nodemailer");
          const client = mailer.createTransport({
            host: process.env.SMTP_HOST,
            port: Number(process.env.SMTP_PORT || 465),
            secure: process.env.SMTP_PORT !== "587",
            requireTLS: true,
            auth: {
              user: process.env.SMTP_USER,
              pass: process.env.SMTP_PASSWORD,
            },
          });
          await client.sendMail({
            from: process.env.MAIL_FROM,
            to: usr.email,
            subject: "Bashir Alam Clinic — account recovery",
            text: `Use this private link within 20 minutes to reset your password.\n\n${link}\n\nIf you did not request this, ignore this email.`,
          });
        } catch {
          await db.run("DELETE FROM reset_tokens WHERE token_hash=?", [
            sha(reset),
          ]);
        }
      }
      await audit(db, usr.id, "recovery.requested", usr.id);
    }
    return {
      message:
        "If your email matches an account, check your inbox for a private reset link. It expires in 20 minutes.",
    };
  }
  if (op === "reset") {
    await limit(db, "reset-submit:" + ip, 12);
    const k = text(b.token, "reset token", 64),
      pw = newPassword(b.password);
    if (pw !== b.confirmation) fail(422, "The passwords do not match.");
    const hash = await hashPassword(pw);
    await db.tx(async (t) => {
      const r = await t.one(
        "SELECT user_id FROM reset_tokens WHERE token_hash=? AND expires_at>?",
        [sha(k), Date.now()],
      );
      if (!r)
        fail(
          400,
          "This recovery link is invalid or expired. Request a new link.",
        );
      await t.run("UPDATE users SET password_hash=? WHERE id=?", [
        hash,
        r.user_id,
      ]);
      await t.run("DELETE FROM sessions WHERE user_id=?", [r.user_id]);
      await t.run("DELETE FROM reset_tokens WHERE user_id=?", [r.user_id]);
      await audit(t, r.user_id, "password.reset", r.user_id);
    });
    return {
      message:
        "Your password has been updated. Sign in with your new password.",
    };
  }
}
