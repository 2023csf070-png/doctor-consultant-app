import {
  id,
  fail,
  seal,
  unseal,
  requireRole,
  assertPatient,
  ownedAppointment,
  audit,
  notify,
  text,
} from "./db.mjs";
import { createHmac, timingSafeEqual } from "node:crypto";
async function zoom(path, method = "GET", body) {
  if (
    ![
      "ZOOM_ACCOUNT_ID",
      "ZOOM_CLIENT_ID",
      "ZOOM_CLIENT_SECRET",
      "ZOOM_USER_ID",
    ].every((k) => process.env[k])
  )
    fail(
      503,
      "Zoom is not connected. Contact the clinic for an online consultation.",
    );
  const token = await fetch(
    "https://zoom.us/oauth/token?" +
      new URLSearchParams({
        grant_type: "account_credentials",
        account_id: process.env.ZOOM_ACCOUNT_ID,
      }),
    {
      method: "POST",
      headers: {
        Authorization:
          "Basic " +
          Buffer.from(
            process.env.ZOOM_CLIENT_ID + ":" + process.env.ZOOM_CLIENT_SECRET,
          ).toString("base64"),
      },
      signal: AbortSignal.timeout(10000),
    },
  );
  if (!token.ok)
    fail(502, "The video provider could not connect. Please try again later.");
  const { access_token } = await token.json();
  const r = await fetch("https://api.zoom.us/v2/" + path, {
    method,
    headers: {
      Authorization: "Bearer " + access_token,
      "Content-Type": "application/json",
    },
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(10000),
  });
  if (!r.ok && !(method === "DELETE" && r.status === 404))
    fail(502, "The video provider could not complete this request.");
  return method === "DELETE" ? {} : r.json();
}
export async function removeZoom(db, aid) {
  const z = await db.one(
    "SELECT meeting_id FROM zoom_meetings WHERE appointment_id=?",
    [aid],
  );
  if (z) {
    await zoom("meetings/" + encodeURIComponent(z.meeting_id), "DELETE");
    await db.run("DELETE FROM zoom_meetings WHERE appointment_id=?", [aid]);
  }
}
export async function providerOp(op, c) {
  const { db, u, b, q } = c;
  if (op === "zoom.create") {
    requireRole(u, "doctor");
    return db.tx(async (t) => {
      const a = await ownedAppointment(t, u, b.id);
      if (a.status !== "Confirmed" || a.type !== "Online Video Consultation")
        fail(409, "Confirm an online appointment before preparing a meeting.");
      if (
        await t.one(
          "SELECT appointment_id FROM zoom_meetings WHERE appointment_id=?",
          [a.id],
        )
      )
        return { ready: true };
      const z = await zoom(
        "users/" +
          encodeURIComponent(process.env.ZOOM_USER_ID || "") +
          "/meetings",
        "POST",
        {
          topic: "Private clinic consultation",
          type: 2,
          start_time:
            a.day +
            "T" +
            String(Math.floor(a.start_min / 60)).padStart(2, "0") +
            ":" +
            String(a.start_min % 60).padStart(2, "0") +
            ":00",
          timezone: "Asia/Karachi",
          duration: a.duration,
          settings: {
            waiting_room: true,
            join_before_host: false,
            meeting_authentication: false,
            auto_recording: "none",
          },
        },
      );
      const link = new URL(z.join_url);
      if (link.protocol !== "https:" || !/(^|\.)zoom\.us$/.test(link.hostname))
        fail(502, "The provider returned an invalid meeting.");
      await t.run(
        "INSERT INTO zoom_meetings(appointment_id,meeting_id,join_enc) VALUES(?,?,?)",
        [a.id, String(z.id), seal(link.href)],
      );
      await notify(
        t,
        a.patient_id,
        "Your secure meeting is ready in your appointments.",
        "Online visit",
      );
      await audit(t, u.id, "meeting.created", a.id);
      return { ready: true };
    });
  }
  if (op === "zoom.join") {
    const a = await ownedAppointment(db, u, q.id);
    if (a.status !== "Confirmed")
      fail(409, "This appointment is not available to join.");
    const z = await db.one(
      "SELECT join_enc FROM zoom_meetings WHERE appointment_id=?",
      [a.id],
    );
    if (!z) fail(404, "Your meeting has not been prepared yet.");
    await audit(db, u.id, "meeting.accessed", a.id);
    return { url: unseal(z.join_enc) };
  }
  if (op === "payment.request") {
    requireRole(u, "doctor");
    await assertPatient(db, u, b.patient_id);
    if (
      !Number.isInteger(b.amount_minor) ||
      b.amount_minor < 100 ||
      b.amount_minor > 100000000
    )
      fail(422, "Enter a valid amount in PKR.");
    if (
      !["Card", "JazzCash", "Easypaisa", "Bank transfer"].includes(b.provider)
    )
      fail(422, "Select a supported payment method.");
    const k = id();
    await db.tx(async (t) => {
      await t.run(
        "INSERT INTO payments(id,patient_id,amount_minor,provider,status) VALUES(?,?,?,?,'Pending')",
        [k, b.patient_id, b.amount_minor, b.provider],
      );
      await audit(t, u.id, "payment.requested", k);
      await notify(
        t,
        b.patient_id,
        "A payment request is available in your portal.",
        "Payments",
      );
    });
    return { saved: true };
  }
  if (op === "payment.checkout") {
    requireRole(u, "patient");
    const p = await db.one(
      "SELECT * FROM payments WHERE id=? AND patient_id=?",
      [text(b.id, "payment", 64), u.id],
    );
    if (!p) fail(404, "Payment not found.");
    if (p.status !== "Pending") fail(409, "This payment is not pending.");
    if (
      p.provider !== "Card" ||
      !process.env.STRIPE_SECRET_KEY ||
      !process.env.STRIPE_WEBHOOK_SECRET ||
      !process.env.PUBLIC_ORIGIN
    )
      fail(
        503,
        "This payment provider is not connected. No payment has been taken.",
      );
    const r = await fetch("https://api.stripe.com/v1/checkout/sessions", {
      method: "POST",
      headers: {
        Authorization: "Bearer " + process.env.STRIPE_SECRET_KEY,
        "Content-Type": "application/x-www-form-urlencoded",
        "Idempotency-Key": p.id,
      },
      body: new URLSearchParams({
        mode: "payment",
        "line_items[0][price_data][currency]": "pkr",
        "line_items[0][price_data][unit_amount]": String(p.amount_minor),
        "line_items[0][price_data][product_data][name]": "Clinic consultation",
        "line_items[0][quantity]": "1",
        "metadata[payment_id]": p.id,
        success_url:
          process.env.PUBLIC_ORIGIN + "/patient/dashboard?tab=Payments",
        cancel_url:
          process.env.PUBLIC_ORIGIN + "/patient/dashboard?tab=Payments",
      }),
      signal: AbortSignal.timeout(10000),
    });
    if (!r.ok) fail(502, "The provider could not prepare checkout.");
    const session = await r.json();
    await db.run("UPDATE payments SET external_id=? WHERE id=?", [
      session.id,
      p.id,
    ]);
    return { url: session.url };
  }
}
export async function stripeEvent(db, raw, signature) {
  if (!process.env.STRIPE_WEBHOOK_SECRET) fail(503, "Provider unavailable.");
  const fields = String(signature || "")
      .split(",")
      .map((x) => x.split("=")),
    ts = fields.find((x) => x[0] === "t")?.[1];
  if (
    !ts ||
    !Number.isFinite(Number(ts)) ||
    Math.abs(Date.now() / 1000 - Number(ts)) > 300
  )
    fail(400, "Invalid provider signature.");
  const digest = createHmac("sha256", process.env.STRIPE_WEBHOOK_SECRET)
    .update(ts + "." + raw)
    .digest("hex");
  if (
    !fields.some(
      ([k, v]) =>
        k === "v1" &&
        /^[a-f0-9]{64}$/.test(v) &&
        timingSafeEqual(Buffer.from(v), Buffer.from(digest)),
    )
  )
    fail(400, "Invalid provider signature.");
  const e = JSON.parse(raw);
  await db.tx(async (t) => {
    if (await t.one("SELECT id FROM payment_events WHERE id=?", [e.id])) return;
    const s = e.data?.object;
    if (
      [
        "checkout.session.completed",
        "checkout.session.async_payment_succeeded",
        "checkout.session.async_payment_failed",
      ].includes(e.type)
    ) {
      const p = await t.one(
        "SELECT * FROM payments WHERE id=? AND external_id=?",
        [s.metadata?.payment_id || "", s.id],
      );
      if (!p || s.amount_total !== p.amount_minor || s.currency !== "pkr")
        fail(409, "Payment reconciliation failed.");
      if (
        p.status === "Pending" &&
        (s.payment_status === "paid" || e.type.endsWith("_failed"))
      ) {
        const status = s.payment_status === "paid" ? "Paid" : "Failed";
        if (status === "Paid" && typeof s.payment_intent === "string")
          await t.run(
            "INSERT OR IGNORE INTO verified_payment_intents(payment_id,provider_intent) VALUES(?,?)",
            [p.id, s.payment_intent],
          );
        await t.run("UPDATE payments SET status=? WHERE id=?", [status, p.id]);
        await notify(
          t,
          p.patient_id,
          "Your payment status has been updated.",
          "Payments",
        );
        await audit(t, null, "provider.payment." + status, p.id);
      }
    }
    if (e.type === "charge.refunded" && s.refunded === true) {
      const p = await t.one(
        "SELECT p.* FROM payments p JOIN verified_payment_intents v ON v.payment_id=p.id WHERE v.provider_intent=?",
        [s.payment_intent || ""],
      );
      if (!p || s.currency !== "pkr" || p.amount_minor !== s.amount_refunded)
        fail(409, "Refund reconciliation failed.");
      if (p.status === "Paid") {
        await t.run("UPDATE payments SET status='Refunded' WHERE id=?", [p.id]);
        await notify(
          t,
          p.patient_id,
          "The provider confirmed your refund.",
          "Payments",
        );
        await audit(t, null, "provider.payment.Refunded", p.id);
      }
    }
    await t.run("INSERT INTO payment_events(id) VALUES(?)", [e.id]);
  });
  return { received: true };
}
