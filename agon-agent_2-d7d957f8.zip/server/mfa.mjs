import { createHmac, timingSafeEqual } from "node:crypto";
import { fail } from "./db.mjs";
// Optional TOTP is provisioned by the operator, never in the public application.
export function totp(secret, step) {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  let bits = "";
  for (const c of secret.toUpperCase().replace(/\s|=/g, "")) {
    const i = alphabet.indexOf(c);
    if (i < 0) throw Error("Invalid authenticator configuration");
    bits += i.toString(2).padStart(5, "0");
  }
  const bytes = Buffer.from(
    (bits.match(/.{8}/g) || []).map((x) => parseInt(x, 2)),
  );
  if (bytes.length < 20)
    throw Error("An authenticator secret must have at least 160 bits");
  const b = Buffer.alloc(8);
  b.writeBigUInt64BE(BigInt(step));
  const h = createHmac("sha1", bytes).update(b).digest(),
    offset = h[19] & 15;
  return String((h.readUInt32BE(offset) & 0x7fffffff) % 1000000).padStart(
    6,
    "0",
  );
}
export async function verifyMfa(db, uid, code) {
  const secret = process.env.DOCTOR_TOTP_SECRET;
  if (!secret) return;
  if (!/^\d{6}$/.test(String(code || "")))
    fail(401, "Enter the six-digit code from your authenticator.");
  const now = Math.floor(Date.now() / 30000);
  const step = [now - 1, now, now + 1].find((s) =>
    timingSafeEqual(Buffer.from(totp(secret, s)), Buffer.from(String(code))),
  );
  if (!step) fail(401, "The authenticator code is invalid or expired.");
  await db.tx(async (t) => {
    const previous = await t.one(
      "SELECT last_step FROM mfa_counters WHERE user_id=?",
      [uid],
    );
    if (previous && previous.last_step >= step)
      fail(401, "Please wait for a new authenticator code.");
    await t.run(
      "INSERT INTO mfa_counters(user_id,last_step) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET last_step=excluded.last_step",
      [uid, step],
    );
  });
}
