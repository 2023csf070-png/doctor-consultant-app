import { fail } from "./db.mjs";
export const aiAvailable = () =>
  Boolean(process.env.AI_EDUCATION_MODEL && process.env.OPENAI_API_KEY);
// The model can only choose an allowlisted educational topic, never generate patient-facing treatment.
// No profile, report, medical record, or account identifier is sent to a model.
export async function selectEducationTopic(question, topics) {
  if (!aiAvailable())
    fail(
      503,
      "AI topic matching is not connected. Use the private education guide instead.",
    );
  const r = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + process.env.OPENAI_API_KEY,
    },
    body: JSON.stringify({
      model: process.env.AI_EDUCATION_MODEL,
      store: false,
      messages: [
        {
          role: "system",
          content:
            "Classify an educational question. Never diagnose or advise treatment. Return only JSON with key topic, exactly one of: " +
            topics.join(", ") +
            ", other, emergency. Use emergency for possible urgent symptoms. Use other for questions requesting medical decisions. Never return prose or medicine advice.",
        },
        { role: "user", content: question },
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 80,
    }),
    signal: AbortSignal.timeout(12000),
  });
  if (!r.ok)
    fail(
      502,
      "The AI provider is unavailable. Switch off AI matching to use the private education guide.",
    );
  const data = await r.json();
  try {
    const topic = JSON.parse(data.choices[0].message.content).topic;
    return [...topics, "emergency"].includes(topic) ? topic : "other";
  } catch {
    return "other";
  }
}
