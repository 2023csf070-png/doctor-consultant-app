# Bashir Alam Clinic — Multan

A working clinic website and private patient/doctor platform. The Expo/TypeScript project has a responsive web interface and native iOS/Android navigation. The Node API, relational database, authentication, file storage, and clinical workflows run independently of the client.

**Do not enter real patient information into the hosted sample workspace.** Without a configured remote database, the Vercel deployment uses explicitly labelled, temporary SQLite storage. This is an interactive preview, not a clinical data host. A self-hosted installation with a persistent volume, or a configured private libSQL database, persists records across restarts. Production use requires the deployment checklist below. No default doctor credentials, demo patients, prescriptions, meeting URLs, or successful payments are seeded.

## Run the complete application

Use Node 24 and npm. The commands below are for the system operator, not for patients.

```sh
npm install
npm run typecheck
npm run lint
npm test
npm run build
npm run serve
```

`build` exports **all three platforms** and creates the SEO documents. `serve` serves the web application and its API together, on port 8080 by default. Set `PORT` to override it. `expo start` alone is a frontend development tool; it is not the clinic backend.

The local development database is `.clinic/clinic.sqlite`. The local encryption key is created separately in `.clinic/data.key`, with restricted permissions. Both are excluded from version control and deployment uploads. A generated development key must not be mistaken for a backed-up production secret. The public pages work without patient accounts. Appointments, files, notifications, and clinical records require an authorised session.

## Production storage and secrets

Copy `.env.example` to `.env` on a trusted server, or enter variables in the hosting provider's secret manager. Never commit `.env` or paste credentials into frontend code, issue descriptions, or logs.

| Setting | Purpose |
|---|---|
| `PUBLIC_ORIGIN` | Exact public HTTPS origin, without a trailing slash. Used for origin validation, verified checkout redirects, and password recovery links. |
| `DATA_ENCRYPTION_KEY` | A stable 32-byte key encoded in Base64. Generate privately with `openssl rand -base64 32`. Preserve a protected backup: losing it makes encrypted information unreadable. |
| `LIBSQL_URL`, `LIBSQL_AUTH_TOKEN` | Private, persistent libSQL database for serverless or multi-instance hosting. Use a dedicated database and scoped token. A serverless `/tmp` directory is **not** durable storage. |
| `CLINIC_DATA_DIR` | Alternative: a persistent, encrypted, access-controlled filesystem volume for a single Node host using SQLite WAL. Not a public/static directory. |
| `NODE_ENV=production` | Requires a persistent encryption key for a live installation and secure browser cookies. Terminate TLS at a trusted proxy. |
| `EXPO_PUBLIC_API_ORIGIN` | Native builds only: the public HTTPS address of this clinic backend. This is a public address, **never a secret**. Web clients use same-origin requests. |

The schema is created from `server/schema.sql`. Local SQLite and remote libSQL share parameterised queries and write transactions. AES-256-GCM protects clinical free text, prescriptions, report bytes, addresses, CNIC, and meeting links. A keyed lookup supports exact CNIC search without plaintext indexing. Operational fields such as names, email, phone, appointment times, and statuses remain queryable; underlying storage and backups must also be encrypted and access-controlled.

### Provision Dr. Faisal Jhandir

There is **no public doctor-registration API**. An operator with trusted server/database access sets `DOCTOR_EMAIL`, `DOCTOR_USERNAME`, and a strong `DOCTOR_PASSWORD` of at least 12 characters, then runs:

```sh
npm run provision:doctor
```

Run this against the **same persistent database and encryption key** used by the deployed API. The command refuses to replace an existing doctor and never prints a password. Remove the provisioning password from the environment afterwards. Give the doctor the credentials through a separate secure channel. Staff sign in at `/doctor/login`; patients use `/patient/login`. Knowing a dashboard or record URL does not authorise access.

Optional doctor MFA: provision a random Base32 TOTP secret of at least 160 bits through the clinic's secure offline enrollment process. Set `DOCTOR_TOTP_SECRET` in the server environment and enroll the same secret in the doctor's authenticator. Codes use six digits and 30-second intervals, with a one-step clock tolerance and database-backed replay prevention. Recovery or disablement requires a trusted operator; there is no public bypass.

## Working journeys

- **Patient:** register → sign in by email or mobile → select a live slot → optionally upload a private report → submit a pending request → receive a doctor confirmation → review consultation notes, prescriptions, and follow-up date.
- **Doctor:** secure sign-in → overview → appointment details → confirm, decline, reschedule, cancel, or complete → open the assigned patient's record → write notes, clinical history, a consultation summary, or a multi-item prescription.
- **Booking rules:** two default daily sessions, 09:00–14:00 and 17:00–22:00, in `Asia/Karachi`. The initial seven-day schedule and 30-minute slots are operational defaults, not a claim about the doctor's actual workdays. Review them before launch. The doctor can edit each weekday's sessions, add breaks between sessions, holidays, blocked times, and extra availability. An update conflicting with an existing visit is rejected. A write transaction plus an active-slot unique index and interval-overlap triggers prevent duplicate bookings. Pending is not Confirmed.
- **Private records:** doctor-only clinical authoring; patients can change only name, phone, address, and city. Clinical entries are append-only through the API. Sensitive reads, changes, meeting access, downloads, and account events are audited.
- **Medical reports:** PDF/JPG/JPEG/PNG, up to 2 MiB per report and 100 MiB per patient. The server checks extension, declared MIME, signatures, bounds, and common active PDF content. Files are encrypted in private relational storage, never placed in `public/`. Every download checks ownership, uses attachment disposition, `nosniff`, and `no-store`. These checks are not a substitute for an organisation's malware-scanning policy.
- **Prescriptions:** only the authorised doctor supplies the diagnosis and medicine information. Patients can open their own prescription and use **Print / save PDF**. The browser print dialog provides PDF export. Nothing is automatically prescribed.
- **Communications:** in-app alerts for clinic activity, read/unread state, and date-based online/follow-up reminders when the portal is accessed. No claim of email/SMS delivery is made from an in-app event. The outbox schema separates Queued, Accepted, Delivered, and Failed states for future opt-in messaging providers.

## Integrations

### Password recovery / SMTP

Configure `SMTP_HOST`, `SMTP_PORT` (465 with TLS or 587 with required STARTTLS), `SMTP_USER`, `SMTP_PASSWORD`, `MAIL_FROM`, and `PUBLIC_ORIGIN`. Use a verified sender. Recovery uses a random 256-bit token stored only as a hash, expiring after 20 minutes. The token is carried in the URL fragment, not in server request logs. Successful reset consumes it and invalidates existing sessions. The public response does not reveal whether a matching user exists. With SMTP absent, recovery reports that it is unavailable and provides the clinic phone number instead of pretending to send mail.

`CLINIC_TEST_MAIL=1` is a test-only local mailbox option. It is refused on Vercel and in production. Test tokens are never returned by an API.

### Zoom

Set `ZOOM_ACCOUNT_ID`, `ZOOM_CLIENT_ID`, `ZOOM_CLIENT_SECRET`, and `ZOOM_USER_ID` for the clinic's own Server-to-Server OAuth app and authorised host. Grant the account-scoped permissions needed to create/manage the host's scheduled meetings. Verify host entitlement, account policies, and waiting-room settings directly with the provider.

The doctor confirms an **online** visit, then selects **Prepare Zoom meeting**. Only a successful provider response creates the private meeting record. Its join URL is encrypted and available through a separate audited endpoint only to the assigned doctor and booked patient. OAuth access tokens and host start tokens never reach a client. The doctor joins signed into the proper Zoom host account. Rescheduling/cancellation removes an existing provider meeting, and a new meeting must be prepared. An unconfigured or failed provider never produces a fabricated join link.

### Payments

The doctor can create a **Pending** payment request in the patient record. Supported architectural methods are Card, JazzCash, Easypaisa, and Bank transfer; PKR amounts are stored in minor units. The patient client cannot set a payment status.

Optional card checkout requires `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, verified merchant eligibility, and `PUBLIC_ORIGIN`. Configure the HTTPS callback `/api/payment-webhook.v1`. Subscribe to `checkout.session.completed`, asynchronous checkout success/failure, and `charge.refunded`. The backend checks the signature on the raw body, timestamp, event ID, stored checkout identity, amount, currency, and actual payment status. Full refunds are reconciled against the original verified payment intent. Browser return URLs are not payment proof.

JazzCash, Easypaisa, and bank transfer are **inactive adapter slots**, not simulated payment gateways. Before enabling one, implement its merchant-specific charge creation and signed callback/reconciliation contract using the provider's issued credentials, register idempotency keys, and test amount/currency/refund verification. Never mark a transfer paid from a patient screenshot. No wallet merchant account or card credentials are included.

### Educational assistant

By default the private guide selects from curated educational content locally; the interface states this explicitly. It cannot diagnose, prescribe, or change medicine. Every answer includes the requested disclaimer and possible urgent symptoms prompt immediate local emergency care. It does not promise triage accuracy.

Optional AI topic matching uses `OPENAI_API_KEY` and an explicitly configured `AI_EDUCATION_MODEL` supporting structured JSON responses. It requires the patient's express opt-in. **Only the question** is submitted; clinical records, reports, profile identifiers, and medicine lists are not sent. The model can select an allowlisted education topic, not write the patient-facing medical answer. Provider output outside the allowlist is discarded. AI report-document analysis and automated medical recommendations are not enabled.

### Email/SMS/WhatsApp/push architecture

In-app notifications are the source of truth. `delivery_outbox` supports channel, provider receipt, and separate delivery states. External notification delivery is intentionally not active. A production adapter must obtain patient consent, send only a generic portal-update message, and verify the provider's delivery receipt before setting **Delivered**. SMTP password recovery is a separate transactional flow. No external reminder is silently claimed as sent. For proactive, idempotent in-app reminders, schedule `npm run reminders` every 15 minutes on a trusted server using the same persistent database. Run `npm run check:production` as a preflight before clinical use.

## Deployment

`npm run build` produces `dist/`, a privacy-safe application shell for authorised routes, and native JS bundles. `api/clinic.v1.js` is the Node serverless entry point. `middleware.js` sends private document requests through the server-side session guard. The same guard runs in `scripts/serve.mjs` for self-hosted installations. The dotted API entry remains routable behind static-site SPA fallbacks.

For your own Vercel deployment use `deployment/vercel.production.json` as the project's `vercel.json`. Set the build command to `npm run build`, output directory to `dist`, and configure server-only environment variables. Deploy the **whole repository**, not just `dist/`: publishing only static files does not publish an API. Add the persistent libSQL credentials before real registrations. The preview deployment helper may install its own static routing configuration; the production configuration is preserved separately.

For a single-host deployment, run `npm run serve` under a process supervisor with a durable `CLINIC_DATA_DIR`, HTTPS reverse proxy, request limits, restricted filesystem permissions, and a secure backup policy. The service does not expose the workspace, database, or private upload directory as static resources.

Native builds use bottom tabs, stack detail views, native input controls, pull-to-refresh, system colour schemes, and protected session credentials in Expo SecureStore. The native patient app handles registration, booking, cancellations, records, prescriptions, and notifications. Advanced clinical authoring and report-management workflows are available in the full secure web workspace. Set the native API origin before building with Expo/EAS; the application does not invent a backend address. A JavaScript export is not an App Store/Play Store binary or submission.

## Validation

```sh
npm test                      # disposable, real SQLite database and HTTP server
npm run typecheck
npm run lint
npm run build                 # iOS, Android, web, plus SEO
python scripts/browser-test.py # Playwright/Chromium required; terminates its test server
```

The tests create randomly generated credentials and explicitly synthetic patient information in temporary directories, then remove them. API integration tests cover signup, email/phone login, console provisioning, role/ownership checks, CSRF, protected pages, concurrent competing bookings, schedule conflicts, holidays, rescheduling, status changes, notes, prescriptions, report validation/private downloads, notifications, education, signed payment callbacks, optional MFA, reset token reuse/session revocation, and persistence across a new process.

Browser tests exercise both patient and doctor workflows against the real API, including account creation during booking, report upload/download, doctor acceptance, recording clinical history, writing/printing a prescription, notification read state, rescheduling, cancellation, and logout. Layouts are checked from 320px to 1920px. Generated screenshots and a **synthetic** printable prescription are placed in ignored `test-artifacts/`. No external payment is collected and no live Zoom host is used by the test suite.

## Before accepting real patients

1. Obtain the clinic operator's approval of the site, doctor identity, working days, actual fees, privacy notice, retention policy, and emergency wording.
2. Configure the durable database, encryption key, private network/host access, HTTPS, backups, deletion/retention process, and authorised administrators. Run a restore drill including the encryption key. Do not rotate the key by simply replacing it: re-encrypt stored data in a controlled migration.
3. Provision the doctor privately, enable MFA, and verify the patient/doctor journeys with non-clinical sample information. Review audit logs and configure privacy-preserving monitoring.
4. Complete the clinic's independent security, clinical, legal, data-residency, and provider-contract reviews. This implementation does not claim regulatory certification or an external security audit.
5. Connect and test each approved provider in its sandbox and then live environment. Keep unused providers off. Verify real recovery email delivery and meeting creation rather than relying on test fixtures.
6. Add the clinic's actual public domain, confirm canonical tags and sitemap, verify mobile devices, and complete a final operator acceptance test.

See `docs/ASSETS.md` for image/font attribution. No testimonials, invented medical qualifications, patient statistics, or real patient examples are included.
