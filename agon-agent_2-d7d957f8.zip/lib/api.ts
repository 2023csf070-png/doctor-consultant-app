export type User = {
  id: string;
  name: string;
  email: string;
  role: "patient" | "doctor";
};
export type Service = {
  id: string;
  name: string;
  description: string;
  detail: string;
  icon: string;
  tone: string;
  group: string;
};
export const PHONE = "0302 0460461";
export const MAP =
  "https://www.google.com/maps/search/?api=1&query=6GC7%2B3XQ%2C+Multan%2C+Pakistan";
export const FOOTER_DISCLAIMER =
  "The information provided through this website and its AI features is intended for general educational purposes and does not replace professional medical diagnosis, treatment, or emergency care. Always consult a qualified healthcare professional for medical advice.";
export const TYPES = [
  "General Consultation",
  "Disease Consultation",
  "Online Video Consultation",
  "Follow-up Consultation",
];
export const pkToday = () =>
  new Date(Date.now() + 18000000).toISOString().slice(0, 10);
export const dateLabel = (s: string, short = false) =>
  new Date(
    s.length === 10
      ? s + "T12:00:00+05:00"
      : s.includes(" ")
        ? s.replace(" ", "T") + "Z"
        : s,
  ).toLocaleDateString("en-GB", {
    day: "numeric",
    month: short ? "short" : "long",
    year: "numeric",
    timeZone: "Asia/Karachi",
  });
export const timeLabel = (m: number) =>
  `${Math.floor(m / 60) % 12 || 12}:${String(m % 60).padStart(2, "0")} ${m < 720 ? "AM" : "PM"}`;
export const time24 = (m: number) =>
  `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
export const toMinute = (t: string) =>
  Number(t.split(":")[0]) * 60 + Number(t.split(":")[1]);
let csrf = "",
  nativeToken = "";
export const setSession = (c: string, t?: string) => {
  csrf = c || "";
  if (t !== undefined) nativeToken = t;
};
export const getCsrf = () => csrf;
export const apiBase = () =>
  typeof window !== "undefined" && window.location?.origin
    ? ""
    : process.env.EXPO_PUBLIC_API_ORIGIN || "";
export async function api<T = any>(
  op: string,
  data?: Record<string, any>,
  query?: Record<string, string>,
): Promise<T> {
  const native = !!apiBase();
  const response = await fetch(
    apiBase() +
      "/api/clinic.v1?" +
      new URLSearchParams({ op, ...query }).toString(),
    {
      method: data ? "POST" : "GET",
      credentials: "include",
      headers: {
        ...(data ? { "Content-Type": "application/json" } : {}),
        ...(csrf ? { "X-CSRF-Token": csrf } : {}),
        ...(native ? { "X-Clinic-Client": "native" } : {}),
        ...(nativeToken ? { Authorization: "Bearer " + nativeToken } : {}),
      },
      body: data ? JSON.stringify(data) : undefined,
    },
  );
  let result;
  try {
    result = await response.json();
  } catch {
    throw Error(
      "The clinic service is unavailable. Please try again or call the clinic.",
    );
  }
  if (!response.ok) {
    if (
      response.status === 401 &&
      op !== "login" &&
      typeof window !== "undefined" &&
      typeof window.dispatchEvent === "function"
    )
      window.dispatchEvent(new Event("clinic-session-expired"));
    throw Error(result.error || "Your request could not be completed.");
  }
  return result;
}
