/** Server-adapter contract for future opt-in external notifications.
 * Keep adapters out of client bundles. The live application sends in-app events only.
 * Acceptance is NOT proof of delivery. Do not put diagnoses, meeting links, or CNIC in messages.
 */
export type DeliveryChannel = "email" | "sms" | "whatsapp" | "push";
export interface GenericClinicMessage {
  outboxId: string;
  recipient: string;
  consentId: string;
  body: "You have an update from Bashir Alam Clinic. Sign in to your private portal.";
}
export interface NotificationAdapter {
  channel: DeliveryChannel;
  send(
    message: GenericClinicMessage,
  ): Promise<{ state: "Accepted"; providerReceipt: string }>;
  verifyReceipt(
    rawBody: Uint8Array,
    signedHeaders: Record<string, string>,
  ): Promise<{
    providerReceipt: string;
    state: "Delivered" | "Failed";
    eventId: string;
  }>;
}
