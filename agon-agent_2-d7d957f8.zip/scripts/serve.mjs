import http from "node:http";
import { readFile, stat } from "node:fs/promises";
import path from "node:path";
import clinic from "../server/handler.mjs";
import webhook from "../server/webhook.mjs";
import sitemap from "../api/sitemap.mjs";
export function createServer() {
  return http.createServer(async (req, res) => {
    try {
      const pathname = decodeURIComponent(
        new URL(req.url, "http://localhost").pathname,
      );
      if (pathname === "/sitemap.xml") return sitemap(req, res);
      if (/^\/(patient|doctor)\/dashboard\/?$/.test(pathname)) {
        req.url = "/api/clinic?op=page&role=" + pathname.split("/")[1];
        return clinic(req, res);
      }
      if (["/api/clinic", "/api/clinic.v1"].includes(pathname))
        return clinic(req, res);
      if (
        ["/api/payment-webhook", "/api/payment-webhook.v1"].includes(pathname)
      )
        return webhook(req, res);
      if (pathname.startsWith("/api/")) {
        res.statusCode = 404;
        return res.end();
      }
      const root = path.resolve("dist");
      let file = path.resolve(root, "." + pathname);
      if (!file.startsWith(root + path.sep) && file !== root) {
        res.statusCode = 403;
        return res.end();
      }
      try {
        if (!(await stat(file)).isFile()) file = path.join(file, "index.html");
      } catch {
        if (path.extname(pathname)) {
          res.statusCode = 404;
          return res.end();
        }
        file = path.join(root, "index.html");
      }
      const ct = {
        ".html": "text/html; charset=utf-8",
        ".js": "application/javascript",
        ".css": "text/css",
        ".woff2": "font/woff2",
        ".ttf": "font/ttf",
        ".json": "application/json",
        ".png": "image/png",
        ".webp": "image/webp",
        ".jpg": "image/jpeg",
        ".svg": "image/svg+xml",
        ".xml": "application/xml",
        ".txt": "text/plain",
      };
      res.setHeader(
        "Content-Type",
        ct[path.extname(file)] || "application/octet-stream",
      );
      res.setHeader("X-Content-Type-Options", "nosniff");
      res.setHeader("Referrer-Policy", "no-referrer");
      res.end(await readFile(file));
    } catch {
      res.statusCode = 500;
      res.end("Service unavailable.");
    }
  });
}
if (process.argv[1]?.endsWith("/serve.mjs"))
  createServer().listen(Number(process.env.PORT || 8080), "0.0.0.0", () =>
    console.log("Clinic server ready."),
  );
