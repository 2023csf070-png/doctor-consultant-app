import {
  withDatabase,
  id,
  newPassword,
  hashPassword,
  audit,
} from "../server/db.mjs";
const {
  DOCTOR_EMAIL: email,
  DOCTOR_PASSWORD: pw,
  DOCTOR_USERNAME: username,
} = process.env;
if (!email || !pw || !username || !/^\S+@\S+\.\S+$/.test(email))
  throw Error(
    "Set DOCTOR_EMAIL, DOCTOR_USERNAME, and DOCTOR_PASSWORD in the protected server environment.",
  );
const hash = await hashPassword(newPassword(pw));
await withDatabase((db) =>
  db.tx(async (t) => {
    const existing = await t.one(
      "SELECT user_id FROM doctors WHERE id='clinic-doctor'",
    );
    if (existing.user_id)
      throw Error(
        "The clinic doctor is already provisioned. Use password recovery.",
      );
    const uid = id();
    await t.run(
      "INSERT INTO users(id,role,name,email,username,password_hash) VALUES(?,?,?,?,?,?)",
      [
        uid,
        "doctor",
        "Dr. Faisal Jhandir",
        email.toLowerCase(),
        username,
        hash,
      ],
    );
    await t.run("UPDATE doctors SET user_id=? WHERE id='clinic-doctor'", [uid]);
    await audit(t, uid, "doctor.provisioned", uid);
  }),
);
console.log("Doctor account provisioned. No credentials were printed.");
