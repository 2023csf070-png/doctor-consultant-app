import { withDatabase, today, notify, doctorUser } from "../server/db.mjs";
// Run from a trusted scheduler, e.g. every 15 minutes. Idempotent in-app events only.
const count = await withDatabase((db) =>
  db.tx(async (t) => {
    const day = today(),
      now = Date.now(),
      end = now + 86400000;
    const tomorrow = new Date(end + 18000000).toISOString().slice(0, 10);
    const host = await doctorUser(t);
    let count = 0;
    for (const a of await t.all(
      "SELECT id,patient_id,day,start_min FROM appointments WHERE status='Confirmed' AND type='Online Video Consultation' AND day BETWEEN ? AND ?",
      [day, tomorrow],
    )) {
      const hh = String(Math.floor(a.start_min / 60)).padStart(2, "0"),
        mm = String(a.start_min % 60).padStart(2, "0"),
        at = new Date(a.day + "T" + hh + ":" + mm + ":00+05:00").getTime();
      if (at < now || at > end) continue;
      await notify(
        t,
        a.patient_id,
        `Your online consultation is scheduled for ${a.day} at ${hh}:${mm} PKT.`,
        "Reminder",
        "online:" + a.id + ":" + a.day,
      );
      if (host)
        await notify(
          t,
          host,
          `An online visit is scheduled for ${a.day} at ${hh}:${mm} PKT.`,
          "Reminder",
          "host-online:" + a.id + ":" + a.day,
        );
      count++;
    }
    for (const p of await t.all(
      "SELECT id,patient_id FROM prescriptions WHERE followup=?",
      [day],
    )) {
      await notify(
        t,
        p.patient_id,
        "Your doctor recommended a follow-up today. Review your prescription.",
        "Follow-up",
        "followup:" + p.id,
      );
      count++;
    }
    for (const c of await t.all(
      "SELECT id,patient_id FROM consultations WHERE followup=?",
      [day],
    )) {
      await notify(
        t,
        c.patient_id,
        "Your consultation summary recommends a follow-up today.",
        "Follow-up",
        "visit-followup:" + c.id,
      );
      count++;
    }
    return count;
  }),
);
console.log(
  `Checked ${count} eligible reminders. In-app events are deduplicated; no external delivery is claimed.`,
);
