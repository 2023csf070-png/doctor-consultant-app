import { existsSync } from "node:fs";
const missing = [];
if (!/^https:\/\/[^/]+$/.test(process.env.PUBLIC_ORIGIN || ""))
  missing.push("Set an exact HTTPS PUBLIC_ORIGIN.");
if (Buffer.from(process.env.DATA_ENCRYPTION_KEY || "", "base64").length !== 32)
  missing.push("Configure a backed-up, 32-byte DATA_ENCRYPTION_KEY.");
if (process.env.VERCEL && !process.env.LIBSQL_URL)
  missing.push(
    "Do not use temporary serverless storage for real patients. Configure LIBSQL_URL.",
  );
if (process.env.LIBSQL_URL && !process.env.LIBSQL_AUTH_TOKEN)
  missing.push("Set the scoped private database credential.");
if (!process.env.LIBSQL_URL && !process.env.CLINIC_DATA_DIR)
  missing.push(
    "Configure an explicit durable local volume or remote database.",
  );
if (!existsSync("dist/index.html"))
  missing.push("Build the web and native application first.");
if (missing.length) {
  console.error(
    "Production preflight is not complete:\n- " + missing.join("\n- "),
  );
  process.exitCode = 1;
} else {
  const { withDatabase } = await import("../server/db.mjs");
  await withDatabase(async (db) => {
    const host = await db.one(
      "SELECT user_id FROM doctors WHERE id='clinic-doctor'",
    );
    if (!host?.user_id) {
      console.error("Provision the authorised doctor before launch.");
      process.exitCode = 1;
    } else
      console.log(
        "Storage configuration and doctor provisioning checks passed.",
      );
  });
  console.log(
    "A configuration check is not a security audit or provider-delivery test. Complete the operational checklist in README.md.",
  );
}
