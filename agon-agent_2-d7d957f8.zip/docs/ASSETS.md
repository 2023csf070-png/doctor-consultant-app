# Public design assets

- Consultation photograph: Pexels photo 7579831, used under the Pexels license. An illustrative appointment, not a portrait of Dr. Faisal Jhandir or a photograph of the actual clinic.
- Clinical notes photograph: Pexels photo 7088483, used under the Pexels license.
- Both images are optimised local WebP files. No external image host is contacted by a visitor.
- DM Sans and Manrope are self-hosted Latin-subset variable WOFF2 fonts, distributed under the SIL Open Font License. License texts are included in `public/fonts`.
- Lucide icons (ISC) are individually imported; Ionicons are preloaded for the native interface. The mint medical cross and pulse mark is an original vector treatment.
