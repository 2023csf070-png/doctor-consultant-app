export { default, config } from "../server/webhook.mjs";
