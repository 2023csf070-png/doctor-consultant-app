export { default, config } from "../server/handler.mjs";
