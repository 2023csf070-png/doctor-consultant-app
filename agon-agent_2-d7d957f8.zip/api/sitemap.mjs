export default function handler(req, res) {
  const host = String(req.headers.host || "").replace(/[^a-zA-Z0-9.:-]/g, "");
  const origin = process.env.PUBLIC_ORIGIN || "https://" + host;
  res.setHeader("Content-Type", "application/xml; charset=utf-8");
  res.setHeader("Cache-Control", "public, max-age=3600");
  res.end(
    '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' +
      [
        "/",
        "/about",
        "/services",
        "/book",
        "/online-consultation",
        "/contact",
        "/privacy",
        "/terms",
      ]
        .map((p) => "<url><loc>" + origin + p + "</loc></url>")
        .join("") +
      "</urlset>",
  );
}
