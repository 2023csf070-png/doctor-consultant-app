// All identities, file contents, provider responses, and payment events here are isolated test fixtures.
import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync, readFileSync, existsSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { randomBytes, createHmac } from "node:crypto";
import { execFileSync } from "node:child_process";
const tmp = mkdtempSync(join(tmpdir(), "clinic-integration-"));
Object.assign(process.env, {
  NODE_ENV: "test",
  CLINIC_DATA_DIR: tmp,
  CLINIC_TEST_MAIL: "1",
  DATA_ENCRYPTION_KEY: randomBytes(32).toString("base64"),
});
for (const k of [
  "LIBSQL_URL",
  "LIBSQL_AUTH_TOKEN",
  "VERCEL",
  "SMTP_HOST",
  "ZOOM_CLIENT_ID",
  "STRIPE_SECRET_KEY",
  "DOCTOR_TOTP_SECRET",
])
  delete process.env[k];
const { createServer } = await import("../scripts/serve.mjs");
const { database, sha, seal, id, today, unseal } = await import(
  "../server/db.mjs"
);
const { totp } = await import("../server/mfa.mjs");
const server = createServer();
await new Promise((r) => server.listen(0, "127.0.0.1", r));
const origin = "http://127.0.0.1:" + server.address().port;
process.env.PUBLIC_ORIGIN = origin;
const password = randomBytes(20).toString("base64url"),
  doctorPassword = randomBytes(20).toString("base64url");
const patient = (n) => ({
  name: "Sample Patient " + n,
  father_name: "Sample Guardian",
  cnic: "000000000000" + n,
  dob: "1995-05-12",
  gender: "Prefer not to say",
  phone: "0300000000" + n,
  email: "sample" + n + "@example.invalid",
  address: "Sample address",
  city: "Multan",
  password,
  confirmation: password,
  consent: true,
});
async function request(op, data, session, query = {}, headers = {}) {
  const r = await fetch(
    origin + "/api/clinic?" + new URLSearchParams({ op, ...query }),
    {
      method: data ? "POST" : "GET",
      headers: {
        ...(data ? { "content-type": "application/json", origin: origin } : {}),
        ...(session
          ? { cookie: session.cookie, "x-csrf-token": session.csrf }
          : {}),
        ...headers,
      },
      body: data ? JSON.stringify(data) : undefined,
      redirect: "manual",
    },
  );
  const json = (r.headers.get("content-type") || "").includes("json");
  return {
    status: r.status,
    body: json ? await r.json() : Buffer.from(await r.arrayBuffer()),
    headers: r.headers,
  };
}
const expect = async (code, ...args) => {
  const r = await request(...args);
  assert.equal(r.status, code, r.body?.error || "Unexpected HTTP status");
  return r;
};
async function login(identifier, pw, role = "patient", otp) {
  const r = await expect(200, "login", { identifier, password: pw, role, otp });
  assert.match(r.headers.get("set-cookie"), /HttpOnly/);
  assert.ok(!r.body.sessionToken);
  return { ...r.body, cookie: r.headers.get("set-cookie").split(";")[0] };
}
const day = new Date(new Date(today() + "T12:00:00Z").getTime() + 86400000 * 2)
  .toISOString()
  .slice(0, 10);
const nextDay = new Date(new Date(day + "T12:00:00Z").getTime() + 86400000)
  .toISOString()
  .slice(0, 10);
let alice, bob, doc, visit, report, rx, payment, db;
await test("Clinic platform — real HTTP and transactional database integration", async (t) => {
  await t.test(
    "public clinic content and valid split-session availability",
    async () => {
      assert.equal((await expect(200, "services")).body.services.length, 8);
      const r = await expect(200, "slots", undefined, null, { day });
      assert.equal(r.body.slots.length, 20);
      assert.ok(r.body.slots.includes(540));
      assert.ok(!r.body.slots.includes(840));
      assert.ok(!r.body.slots.includes(900));
      await expect(422, "slots", undefined, null, { day: "2000-01-01" });
    },
  );
  await t.test(
    "unauthenticated APIs and private page routes are protected by the server",
    async () => {
      for (const op of [
        "dashboard",
        "patients",
        "availability",
        "patient.record",
        "report.download",
      ])
        await expect(401, op);
      for (const role of ["doctor", "patient"]) {
        const r = await fetch(origin + "/" + role + "/dashboard", {
          redirect: "manual",
        });
        assert.equal(r.status, 302);
        assert.ok(r.headers.get("location").startsWith("/" + role + "/login"));
      }
    },
  );
  await t.test(
    "registration validates identity fields, consent, and confirmation",
    async () => {
      await expect(422, "signup", { ...patient(1), cnic: "123" });
      await expect(422, "signup", { ...patient(1), confirmation: "different" });
      await expect(422, "signup", { ...patient(1), consent: false });
      await expect(200, "signup", { ...patient(1), role: "doctor" });
      await expect(200, "signup", patient(2));
      await expect(409, "signup", patient(1));
    },
  );
  await t.test(
    "doctor provisioned only from trusted server console; email, phone and role-specific login",
    async () => {
      execFileSync(process.execPath, ["scripts/provision-doctor.mjs"], {
        env: {
          ...process.env,
          DOCTOR_EMAIL: "doctor@example.invalid",
          DOCTOR_USERNAME: "fixture-doctor",
          DOCTOR_PASSWORD: doctorPassword,
        },
        stdio: "pipe",
      });
      alice = await login(patient(1).email, password);
      bob = await login(patient(2).phone, password);
      doc = await login("fixture-doctor", doctorPassword, "doctor");
      assert.equal(alice.user.role, "patient");
      await expect(401, "login", {
        identifier: patient(1).email,
        password,
        role: "doctor",
      });
      await expect(401, "login", {
        identifier: patient(2).phone,
        password: "not-the-password",
      });
      db = await database();
      const raw = await db.one("SELECT password_hash FROM users WHERE id=?", [
        alice.user.id,
      ]);
      assert.notEqual(raw.password_hash, password);
      assert.equal(
        (await expect(200, "session", undefined, alice)).body.user.id,
        alice.user.id,
      );
    },
  );
  await t.test(
    "permissions, ownership, CSRF and cross-origin mutating requests enforced",
    async () => {
      await expect(403, "patients", undefined, alice);
      await expect(404, "patient.record", undefined, alice, {
        id: bob.user.id,
      });
      await expect(
        403,
        "prescription.save",
        { patient_id: alice.user.id },
        alice,
      );
      await expect(
        403,
        "notification.read",
        {},
        alice,
        {},
        { "x-csrf-token": "not-a-session-token" },
      );
      await expect(
        403,
        "notification.read",
        {},
        alice,
        {},
        { origin: "https://other.example.invalid" },
      );
      await expect(
        403,
        "availability.save",
        { duration: 30, weekly: [] },
        alice,
      );
    },
  );
  await t.test(
    "atomic booking and simultaneous competing requests never double-book",
    async () => {
      const payload = {
        type: "Online Video Consultation",
        day,
        start_min: 540,
        reason: "Sample visit reason",
      };
      const results = await Promise.all([
        request("book", payload, alice),
        request("book", payload, bob),
      ]);
      assert.deepEqual(results.map((r) => r.status).sort(), [200, 409]);
      let winner = results.findIndex((r) => r.status === 200);
      if (winner === 1) [alice, bob] = [bob, alice];
      visit = results[winner].body;
      assert.match(visit.reference, /^BAC-/);
      assert.equal(visit.status, "Pending");
      assert.ok(
        !(
          await expect(200, "slots", undefined, null, { day })
        ).body.slots.includes(540),
      );
      await expect(409, "book", { ...payload, start_min: 900 }, alice);
    },
  );
  await t.test(
    "doctor acceptance, patient notification, and confirmed-only conferencing",
    async () => {
      await expect(
        403,
        "appointment.change",
        { id: visit.id, status: "Confirmed" },
        alice,
      );
      await expect(
        404,
        "appointment.change",
        { id: visit.id, status: "Cancelled" },
        bob,
      );
      await expect(
        200,
        "appointment.change",
        { id: visit.id, status: "Confirmed" },
        doc,
      );
      await expect(503, "zoom.create", { id: visit.id }, doc);
      await expect(404, "zoom.join", undefined, alice, { id: visit.id });
      await expect(404, "zoom.join", undefined, bob, { id: visit.id });
      const r = await expect(200, "dashboard", undefined, alice);
      assert.ok(
        r.body.notifications.some((n) => n.message.includes("confirmed")),
      );
      assert.equal(r.body.appointments[0].has_zoom, 0);
      assert.ok(!JSON.stringify(r.body).includes("zoom.us"));
      await expect(
        409,
        "appointment.change",
        { id: visit.id, status: "Completed" },
        doc,
      );
    },
  );
  await t.test(
    "schedule overlap, holiday and blocked-time constraints preserve existing bookings",
    async () => {
      const initial = (await expect(200, "availability", undefined, doc)).body;
      await expect(
        422,
        "availability.save",
        { duration: 30, weekly: [...initial.weekly, initial.weekly[0]] },
        doc,
      );
      await expect(409, "exception.save", { day, kind: "Holiday" }, doc);
      await expect(
        200,
        "exception.save",
        { day, kind: "Blocked", start_min: 600, end_min: 660 },
        doc,
      );
      const s = (await expect(200, "slots", undefined, null, { day })).body
        .slots;
      assert.ok(!s.includes(600) && !s.includes(630));
      await expect(
        200,
        "exception.save",
        { day: nextDay, kind: "Holiday" },
        doc,
      );
      assert.equal(
        (await expect(200, "slots", undefined, null, { day: nextDay })).body
          .slots.length,
        0,
      );
      const state = (await expect(200, "availability", undefined, doc)).body;
      await expect(
        200,
        "exception.remove",
        { id: state.exceptions.find((e) => e.kind === "Holiday").id },
        doc,
      );
      await expect(
        200,
        "exception.save",
        { day: nextDay, kind: "Extra", start_min: 840, end_min: 900 },
        doc,
      );
      assert.ok(
        (
          await expect(200, "slots", undefined, null, { day: nextDay })
        ).body.slots.includes(840),
      );
      await expect(
        200,
        "availability.save",
        { duration: 30, weekly: initial.weekly },
        doc,
      );
    },
  );
  await t.test(
    "rescheduling is atomic and patient changes require reconfirmation",
    async () => {
      await expect(
        200,
        "appointment.change",
        { id: visit.id, action: "reschedule", day, start_min: 570 },
        alice,
      );
      const a = (await expect(200, "dashboard", undefined, alice)).body
        .appointments[0];
      assert.equal(a.start_min, 570);
      assert.equal(a.status, "Pending");
      assert.ok(
        (
          await expect(200, "slots", undefined, null, { day })
        ).body.slots.includes(540),
      );
      await expect(
        200,
        "appointment.change",
        { id: visit.id, status: "Confirmed" },
        doc,
      );
    },
  );
  await t.test(
    "report type checks, encrypted storage and private downloads",
    async () => {
      const png = readFileSync("assets/favicon.png");
      const upload = {
        filename: "Sample-report.png",
        mime: "image/png",
        data: png.toString("base64"),
      };
      await expect(
        422,
        "report.upload",
        { ...upload, filename: "invalid.txt" },
        alice,
      );
      await expect(
        422,
        "report.upload",
        { ...upload, mime: "application/pdf" },
        alice,
      );
      report = (await expect(200, "report.upload", upload, alice)).body;
      const raw = await db.one(
        "SELECT content_enc,filename_enc FROM medical_reports WHERE id=?",
        [report.id],
      );
      assert.notEqual(raw.content_enc, upload.data);
      assert.notEqual(raw.filename_enc, upload.filename);
      await expect(404, "report.download", undefined, bob, { id: report.id });
      const f = await expect(200, "report.download", undefined, alice, {
        id: report.id,
      });
      assert.equal(f.headers.get("content-type"), "image/png");
      assert.match(f.headers.get("content-disposition"), /attachment/);
      assert.deepEqual(f.body, png);
      await expect(200, "report.download", undefined, doc, { id: report.id });
      await expect(
        200,
        "note.add",
        {
          patient_id: alice.user.id,
          report_id: report.id,
          content: "Reviewed sample report.",
        },
        doc,
      );
    },
  );
  await t.test(
    "prescriptions and clinical entries stay with the correct patient",
    async () => {
      const payload = {
        patient_id: alice.user.id,
        appointment_id: visit.id,
        diagnosis: "Non-clinical test impression",
        notes: "Fixture only",
        followup: nextDay,
        items: [
          {
            medicine: "Test item A",
            dosage: "Fixture dose",
            frequency: "Fixture frequency",
            duration: "Fixture duration",
            instructions: "Not for clinical use",
          },
          {
            medicine: "Test item B",
            dosage: "Fixture dose",
            frequency: "Fixture frequency",
            duration: "Fixture duration",
            instructions: "",
          },
        ],
      };
      await expect(
        422,
        "prescription.save",
        { ...payload, patient_id: bob.user.id },
        doc,
      );
      rx = (await expect(200, "prescription.save", payload, doc)).body.id;
      await expect(
        200,
        "record.add",
        {
          patient_id: alice.user.id,
          category: "Allergies",
          content: "Test entry — no real patient data.",
        },
        doc,
      );
      const own = (await expect(200, "patient.record", undefined, alice)).body;
      assert.ok(
        own.prescriptions.some((r) => r.id === rx && r.items.length === 2),
      );
      assert.equal(own.notes[0].report_id, report.id);
      assert.equal(
        (await expect(200, "patient.record", undefined, bob)).body.prescriptions
          .length,
        0,
      );
      assert.ok(
        !(
          await db.one("SELECT diagnosis_enc FROM prescriptions WHERE id=?", [
            rx,
          ])
        ).diagnosis_enc.includes("impression"),
      );
    },
  );
  await t.test(
    "doctor patient search by ID, name, CNIC and telephone; permitted profile edits",
    async () => {
      const p = (await expect(200, "patient.record", undefined, alice)).body
        .profile;
      for (const search of [p.id, p.name, p.phone, p.cnic])
        assert.ok(
          (
            await expect(200, "patients", undefined, doc, { search })
          ).body.patients.some((r) => r.id === p.id),
        );
      await expect(
        200,
        "profile.save",
        { ...p, city: "Sample city", role: "doctor" },
        alice,
      );
      const after = (await expect(200, "patient.record", undefined, alice)).body
        .profile;
      assert.equal(after.city, "Sample city");
      assert.equal(
        (await request("session", undefined, alice)).body.user.role,
        "patient",
      );
    },
  );
  await t.test(
    "doctor-created visits, cancellations, and completed visit summaries",
    async () => {
      const created = (
        await expect(
          200,
          "book",
          {
            patient_id: bob.user.id,
            type: "Follow-up Consultation",
            day: nextDay,
            start_min: 540,
            reason: "Sample follow-up",
            report_id: null,
          },
          doc,
        )
      ).body;
      await expect(
        200,
        "appointment.change",
        { id: created.id, status: "Cancelled" },
        bob,
      );
      assert.ok(
        (
          await request("slots", undefined, null, { day: nextDay })
        ).body.slots.includes(540),
      );
      const pastId = id(),
        pastDay = new Date(Date.now() - 3 * 86400000)
          .toISOString()
          .slice(0, 10);
      await db.run(
        "INSERT INTO appointments(id,reference,patient_id,doctor_id,type,day,start_min,duration,reason_enc,status) VALUES(?,?,?,'clinic-doctor','General Consultation',?,540,30,?,'Confirmed')",
        [
          pastId,
          "BAC-TEST-PAST",
          alice.user.id,
          pastDay,
          seal("Historical test fixture"),
        ],
      );
      await expect(
        200,
        "consultation.save",
        {
          patient_id: alice.user.id,
          appointment_id: pastId,
          content: "Completed fixture consultation",
          followup: nextDay,
        },
        doc,
      );
      await expect(
        200,
        "appointment.change",
        { id: pastId, status: "Completed" },
        doc,
      );
      await expect(
        409,
        "appointment.change",
        { id: pastId, status: "Cancelled" },
        doc,
      );
    },
  );
  await t.test(
    "service edits persist and in-app read states are private",
    async () => {
      const s = (await request("services")).body.services[0];
      await expect(403, "service.save", s, alice);
      await expect(
        200,
        "service.save",
        { ...s, description: "Test description saved by the clinic doctor." },
        doc,
      );
      assert.match(
        (await request("services")).body.services[0].description,
        /Test description/,
      );
      await expect(200, "notification.read", {}, alice);
      assert.ok(
        (await request("dashboard", undefined, alice)).body.notifications.every(
          (n) => n.read_at,
        ),
      );
      assert.ok(
        (await request("dashboard", undefined, doc)).body.notifications.some(
          (n) => !n.read_at,
        ),
      );
    },
  );
  await t.test(
    "education-only guidance and emergency redirection",
    async () => {
      const r = await expect(
        200,
        "education",
        { question: "Can you explain a lab report?" },
        alice,
      );
      assert.match(r.body.disclaimer, /not a medical diagnosis/);
      assert.match(r.body.answer, /reference range/);
      assert.match(
        (
          await expect(
            200,
            "education",
            { question: "I have chest pain" },
            alice,
          )
        ).body.answer,
        /immediate local emergency/,
      );
    },
  );
  await t.test(
    "pending payments cannot be self-confirmed and inactive providers do not charge",
    async () => {
      await expect(
        403,
        "payment.request",
        { patient_id: alice.user.id, provider: "Card", amount_minor: 150000 },
        alice,
      );
      await expect(
        200,
        "payment.request",
        { patient_id: alice.user.id, provider: "Card", amount_minor: 150000 },
        doc,
      );
      payment = (await expect(200, "patient.record", undefined, alice)).body
        .payments[0];
      assert.equal(payment.status, "Pending");
      await expect(503, "payment.checkout", { id: payment.id }, alice);
      await expect(404, "payment.checkout", { id: payment.id }, bob);
    },
  );
  await t.test(
    "signed provider receipts reconcile amount, currency, external ID, and duplicate callbacks",
    async () => {
      process.env.STRIPE_WEBHOOK_SECRET = randomBytes(32).toString("hex");
      await db.run("UPDATE payments SET external_id=? WHERE id=?", [
        "test-session",
        payment.id,
      ]);
      const event = {
        id: "fixture-event",
        type: "checkout.session.completed",
        data: {
          object: {
            id: "test-session",
            metadata: { payment_id: payment.id },
            amount_total: payment.amount_minor,
            currency: "pkr",
            payment_status: "paid",
            payment_intent: "test-intent",
          },
        },
      };
      const raw = JSON.stringify(event),
        ts = Math.floor(Date.now() / 1000);
      const sig =
        "t=" +
        ts +
        ",v1=" +
        createHmac("sha256", process.env.STRIPE_WEBHOOK_SECRET)
          .update(ts + "." + raw)
          .digest("hex");
      const send = (signature) =>
        fetch(origin + "/api/payment-webhook", {
          method: "POST",
          headers: { "stripe-signature": signature },
          body: raw,
        });
      assert.equal((await send("not-verified")).status, 400);
      assert.equal((await send(sig)).status, 200);
      assert.equal((await send(sig)).status, 200);
      assert.equal(
        (await db.one("SELECT status FROM payments WHERE id=?", [payment.id]))
          .status,
        "Paid",
      );
      assert.equal(
        (await db.one("SELECT COUNT(*) n FROM payment_events")).n,
        1,
      );
    },
  );
  await t.test(
    "verified full refund reconciles to the original provider payment intent",
    async () => {
      const event = {
        id: "fixture-refund",
        type: "charge.refunded",
        data: {
          object: {
            refunded: true,
            payment_intent: "test-intent",
            amount_refunded: payment.amount_minor,
            currency: "pkr",
          },
        },
      };
      const raw = JSON.stringify(event),
        ts = Math.floor(Date.now() / 1000);
      const signature =
        "t=" +
        ts +
        ",v1=" +
        createHmac("sha256", process.env.STRIPE_WEBHOOK_SECRET)
          .update(ts + "." + raw)
          .digest("hex");
      const r = await fetch(origin + "/api/payment-webhook", {
        method: "POST",
        headers: { "stripe-signature": signature },
        body: raw,
      });
      assert.equal(r.status, 200);
      assert.equal(
        (await db.one("SELECT status FROM payments WHERE id=?", [payment.id]))
          .status,
        "Refunded",
      );
    },
  );
  await t.test(
    "isolated Zoom adapter contract: provider response, authorised joins, and revocation",
    async (sub) => {
      const original = globalThis.fetch;
      const secret = randomBytes(20).toString("hex");
      for (const k of [
        "ZOOM_CLIENT_ID",
        "ZOOM_ACCOUNT_ID",
        "ZOOM_USER_ID",
        "ZOOM_CLIENT_SECRET",
      ])
        process.env[k] = secret;
      let deleted = false;
      const providerJoin = "https://fixture.zoom.us/j/00000000000";
      const fetchMock = sub.mock.method(
        globalThis,
        "fetch",
        async (input, opts) => {
          const url = String(input);
          if (url.startsWith("https://zoom.us/oauth/token?"))
            return Response.json({ access_token: "inert-test-token" });
          if (url.startsWith("https://api.zoom.us/v2/")) {
            if (opts.method === "DELETE") {
              deleted = true;
              return new Response(null, { status: 204 });
            }
            assert.equal(opts.headers.Authorization, "Bearer inert-test-token");
            assert.equal(JSON.parse(opts.body).settings.waiting_room, true);
            return Response.json({
              id: "00000000000",
              join_url: providerJoin,
              start_url: "never-return-this-host-token",
            });
          }
          return original(input, opts);
        },
      );
      try {
        const a = (
          await expect(
            200,
            "book",
            {
              type: "Online Video Consultation",
              day: nextDay,
              start_min: 690,
              reason: "Provider contract fixture",
            },
            alice,
          )
        ).body;
        await expect(409, "zoom.create", { id: a.id }, doc);
        await expect(
          200,
          "appointment.change",
          { id: a.id, status: "Confirmed" },
          doc,
        );
        assert.deepEqual(
          (await expect(200, "zoom.create", { id: a.id }, doc)).body,
          { ready: true },
        );
        assert.equal(
          (await expect(200, "zoom.join", undefined, alice, { id: a.id })).body
            .url,
          providerJoin,
        );
        assert.equal(
          (await expect(200, "zoom.join", undefined, doc, { id: a.id })).body
            .url,
          providerJoin,
        );
        await expect(404, "zoom.join", undefined, bob, { id: a.id });
        const dashboard = JSON.stringify(
          (await expect(200, "dashboard", undefined, alice)).body,
        );
        assert.ok(
          !dashboard.includes("zoom.us") &&
            !dashboard.includes(secret) &&
            !dashboard.includes("host-token"),
        );
        await expect(
          200,
          "appointment.change",
          { id: a.id, status: "Cancelled" },
          alice,
        );
        assert.ok(deleted);
        await expect(409, "zoom.join", undefined, alice, { id: a.id });
      } finally {
        fetchMock.mock.restore();
        for (const k of [
          "ZOOM_CLIENT_ID",
          "ZOOM_ACCOUNT_ID",
          "ZOOM_USER_ID",
          "ZOOM_CLIENT_SECRET",
        ])
          delete process.env[k];
      }
    },
  );
  await t.test(
    "private education stays local unless an AI provider is configured and consented",
    async () => {
      await expect(
        503,
        "education",
        { question: "How do I prepare for a visit?", ai_consent: true },
        alice,
      );
      const a = (
        await expect(
          200,
          "education",
          { question: "How do I prepare for a visit?", ai_consent: false },
          alice,
        )
      ).body;
      assert.equal(a.mode, "Curated educational guidance");
    },
  );
  await t.test(
    "optional authenticator codes verified before issuing a doctor session",
    async () => {
      const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
      process.env.DOCTOR_TOTP_SECRET = Array.from(
        randomBytes(32),
        (n) => chars[n % 32],
      ).join("");
      await expect(401, "login", {
        identifier: "fixture-doctor",
        password: doctorPassword,
        role: "doctor",
      });
      const code = totp(
        process.env.DOCTOR_TOTP_SECRET,
        Math.floor(Date.now() / 30000),
      );
      await login("fixture-doctor", doctorPassword, "doctor", code);
      await expect(401, "login", {
        identifier: "fixture-doctor",
        password: doctorPassword,
        role: "doctor",
        otp: code,
      });
      delete process.env.DOCTOR_TOTP_SECRET;
    },
  );
  await t.test(
    "password recovery uses single-use tokens and revokes old sessions",
    async () => {
      await expect(200, "forgot", { email: alice.user.email, role: "patient" });
      const path = join(tmp, "test-mail", alice.user.id + ".txt");
      assert.ok(existsSync(path));
      const code = readFileSync(path, "utf8").split("#")[1],
        newPw = randomBytes(20).toString("hex");
      assert.equal(
        (
          await db.one("SELECT token_hash FROM reset_tokens WHERE user_id=?", [
            alice.user.id,
          ])
        ).token_hash,
        sha(code),
      );
      await expect(200, "reset", {
        token: code,
        password: newPw,
        confirmation: newPw,
      });
      await expect(400, "reset", {
        token: code,
        password: newPw,
        confirmation: newPw,
      });
      await expect(401, "dashboard", undefined, alice);
      alice = await login(alice.user.email, newPw);
      await expect(200, "logout", {}, alice);
      assert.equal(
        (await expect(200, "session", undefined, alice)).body.user,
        null,
      );
    },
  );
  await t.test(
    "audit records and persisted relational data survive a new process",
    async () => {
      assert.ok((await db.one("SELECT COUNT(*) n FROM audit_logs")).n > 20);
      const result = execFileSync(
        process.execPath,
        [
          "--input-type=module",
          "-e",
          "import {database} from './server/db.mjs'; const d=await database();console.log((await d.one('SELECT COUNT(*) n FROM prescriptions')).n);",
        ],
        { env: process.env, encoding: "utf8" },
      );
      assert.equal(Number(result.trim()), 1);
    },
  );
}).finally(async () => {
  server.closeAllConnections();
  await new Promise((r) => server.close(r));
  rmSync(tmp, { recursive: true, force: true });
});
