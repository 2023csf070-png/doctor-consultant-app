import { next, rewrite } from "@vercel/edge";
// Resolve protected documents through the same trusted session check as clinical API reads.
export default function middleware(request) {
  const url = new URL(request.url),
    path = url.pathname;
  if (/^\/(doctor|patient)\/dashboard\/?$/.test(path)) {
    const role = path.split("/")[1];
    url.pathname = "/api/clinic.v1";
    url.searchParams.set("op", "page");
    url.searchParams.set("role", role);
    return rewrite(url);
  }
  if (path === "/sitemap.xml") {
    url.pathname = "/api/sitemap";
    return rewrite(url);
  }
  if (path === "/api/clinic") {
    url.pathname = "/api/clinic.v1";
    return rewrite(url);
  }
  if (path === "/api/payment-webhook") {
    url.pathname = "/api/payment-webhook.v1";
    return rewrite(url);
  }
  return next();
}
export const config = {
  matcher: [
    "/doctor/dashboard",
    "/patient/dashboard",
    "/sitemap.xml",
    "/api/clinic",
    "/api/payment-webhook",
  ],
};
