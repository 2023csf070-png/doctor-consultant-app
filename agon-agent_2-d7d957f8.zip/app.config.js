// Preserve the clinic identity independently of the preview host's Expo metadata.
module.exports = ({ config }) => ({
  ...config,
  name: "Bashir Alam Clinic",
  slug: "bashir-alam-clinic",
  updates: { enabled: false },
  extra: { ...config.extra, clinicTimezone: "Asia/Karachi" },
});
