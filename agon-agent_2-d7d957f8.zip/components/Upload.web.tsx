import React, { useRef, useState } from "react";
import { getCsrf } from "../lib/api";
import { ErrorBox, Icon } from "./UI.web";
export function ReportUpload({
  onDone,
  patientId,
}: {
  onDone: (v: any) => void;
  patientId?: string;
}) {
  const [progress, setProgress] = useState(-1),
    [error, setError] = useState(""),
    [done, setDone] = useState("");
  const ref = useRef<HTMLInputElement>(null);
  async function send(f: File) {
    setError("");
    setDone("");
    if (
      f.size > 2 * 1024 * 1024 ||
      !["application/pdf", "image/jpeg", "image/png"].includes(f.type)
    ) {
      setError("Choose a PDF, JPG, or PNG file no larger than 2 MB.");
      return;
    }
    setProgress(0);
    try {
      const data = await new Promise<string>((resolve, reject) => {
        const r = new FileReader();
        r.onload = () => resolve(String(r.result).split(",")[1]);
        r.onerror = () => reject(Error("Cannot read this file."));
        r.readAsDataURL(f);
      });
      const result = await new Promise<any>((resolve, reject) => {
        const x = new XMLHttpRequest();
        x.open("POST", "/api/clinic.v1?op=report.upload");
        x.setRequestHeader("Content-Type", "application/json");
        x.setRequestHeader("X-CSRF-Token", getCsrf());
        x.upload.onprogress = (e) => {
          if (e.lengthComputable)
            setProgress(Math.min(98, Math.round((e.loaded / e.total) * 100)));
        };
        x.onload = () => {
          try {
            const b = JSON.parse(x.responseText);
            x.status >= 200 && x.status < 300
              ? resolve(b)
              : reject(Error(b.error || "Upload failed."));
          } catch {
            reject(Error("Upload failed. Please try again."));
          }
        };
        x.onerror = () =>
          reject(Error("Connection interrupted. Try uploading again."));
        x.timeout = 60000;
        x.ontimeout = () => reject(Error("The upload timed out."));
        x.send(
          JSON.stringify({
            filename: f.name,
            mime: f.type,
            data,
            patient_id: patientId,
          }),
        );
      });
      setDone(result.filename);
      onDone(result);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setProgress(-1);
      if (ref.current) ref.current.value = "";
    }
  }
  return (
    <div>
      <label className={"upload-box " + (progress >= 0 ? "uploading" : "")}>
        <span className="upload-symbol">
          <Icon name={done ? "success" : "upload"} size={23} />
        </span>
        <strong>
          {progress >= 0
            ? `Uploading ${progress}%`
            : done
              ? "Report saved privately"
              : "Choose a medical report"}
        </strong>
        <small>{done || "PDF, JPG, or PNG · Up to 2 MB"}</small>
        <input
          ref={ref}
          type="file"
          aria-label="Upload medical report"
          accept="application/pdf,image/jpeg,image/png"
          disabled={progress >= 0}
          onChange={(e) => {
            if (e.target.files?.[0]) send(e.target.files[0]);
          }}
        />
        {progress >= 0 && <progress value={progress} max="100" />}
      </label>
      <ErrorBox message={error} />
    </div>
  );
}
