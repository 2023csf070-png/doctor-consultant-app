import React, {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  ReactNode,
} from "react";
import {
  ArrowRight,
  ArrowUpRight,
  ArrowLeft,
  CalendarDays,
  Video,
  Stethoscope,
  HeartPulse,
  CalendarCheck2,
  FolderHeart,
  ClipboardList,
  BookOpen,
  Clock3,
  MapPin,
  Phone,
  UserRound,
  ShieldCheck,
  Menu,
  X,
  Plus,
  Check,
  ChevronRight,
  ChevronLeft,
  ChevronDown,
  Mail,
  LockKeyhole,
  Eye,
  EyeOff,
  Activity,
  Hospital,
  FileText,
  CheckCheck,
  House,
  LayoutDashboard,
  UsersRound,
  Bell,
  LogOut,
  Settings2,
  Search,
  FolderClosed,
  ReceiptText,
  Upload,
  Download,
  Printer,
  Pill,
  MessageCircle,
  Send,
  TriangleAlert,
  LoaderCircle,
  RefreshCw,
  Trash2,
  CalendarClock,
  SlidersHorizontal,
  CheckCircle2,
  Info,
  ClipboardPlus,
  HeartHandshake,
  List,
  ClipboardCheck,
  KeyRound,
  VideoOff,
  Layers3,
} from "../lib/icons.web";
import { api, Service, User } from "../lib/api";
const icons: Record<string, any> = {
  arrow: ArrowRight,
  external: ArrowUpRight,
  back: ArrowLeft,
  calendar: CalendarDays,
  video: Video,
  stethoscope: Stethoscope,
  heart: HeartPulse,
  followup: CalendarCheck2,
  folder: FolderHeart,
  prescription: ClipboardList,
  education: BookOpen,
  clock: Clock3,
  pin: MapPin,
  phone: Phone,
  user: UserRound,
  shield: ShieldCheck,
  menu: Menu,
  x: X,
  plus: Plus,
  check: Check,
  right: ChevronRight,
  left: ChevronLeft,
  down: ChevronDown,
  mail: Mail,
  lock: LockKeyhole,
  eye: Eye,
  hidden: EyeOff,
  activity: Activity,
  clinic: Hospital,
  file: FileText,
  read: CheckCheck,
  home: House,
  dashboard: LayoutDashboard,
  patients: UsersRound,
  bell: Bell,
  logout: LogOut,
  settings: Settings2,
  search: Search,
  records: FolderClosed,
  payment: ReceiptText,
  upload: Upload,
  download: Download,
  print: Printer,
  pill: Pill,
  chat: MessageCircle,
  send: Send,
  alert: TriangleAlert,
  loading: LoaderCircle,
  refresh: RefreshCw,
  trash: Trash2,
  schedule: CalendarClock,
  filter: SlidersHorizontal,
  success: CheckCircle2,
  info: Info,
  addrecord: ClipboardPlus,
  care: HeartHandshake,
  list: List,
  clipboard: ClipboardCheck,
  key: KeyRound,
  videooff: VideoOff,
  layers: Layers3,
};
export function Icon({
  name,
  size = 20,
  className = "",
  stroke = 1.75,
}: {
  name: string;
  size?: number;
  className?: string;
  stroke?: number;
}) {
  const C = icons[name] || Activity;
  return (
    <C
      className={"icon " + className}
      size={size}
      strokeWidth={stroke}
      aria-hidden="true"
    />
  );
}
export type ClinicContext = {
  go: (path: string) => void;
  path: string;
  user: User | null;
  ready: boolean;
  preview: boolean;
  services: Service[];
  refreshServices: () => Promise<void>;
  onAuth: (u: User | null, csrf?: string) => void;
  toast: (m: string) => void;
  booking: any;
  setBooking: (s: any) => void;
};
export const Clinic = createContext<ClinicContext>(null as any);
export const useClinic = () => useContext(Clinic);
export function Link({
  to,
  children,
  className = "",
  ...props
}: {
  to: string;
  children: ReactNode;
  className?: string;
  [key: string]: any;
}) {
  const { go } = useClinic();
  return (
    <a
      href={to}
      className={className}
      {...props}
      onClick={(e) => {
        if (!e.ctrlKey && !e.metaKey && !e.shiftKey && e.button === 0) {
          e.preventDefault();
          go(to);
        }
      }}
    >
      {children}
    </a>
  );
}
export function Logo() {
  return (
    <Link to="/" className="brand" aria-label="Bashir Alam Clinic home">
      <svg viewBox="0 0 52 54" className="brand-mark" aria-hidden="true">
        <path
          d="M20 2h12a3 3 0 0 1 3 3v10h10a4 4 0 0 1 4 4v12a4 4 0 0 1-4 4H35v12a3 3 0 0 1-3 3H20a4 4 0 0 1-4-4V35H5a4 4 0 0 1-4-4V19a4 4 0 0 1 4-4h11V6a4 4 0 0 1 4-4Z"
          fill="#8ce1c5"
        />
        <path
          d="M2 27h12l5-10 7 21 6-16 4 5h13"
          fill="none"
          stroke="#103746"
          strokeWidth="3.4"
          strokeLinejoin="round"
          strokeLinecap="round"
        />
      </svg>
      <span>
        <strong>Bashir Alam Clinic</strong>
        <small>MULTAN, PAKISTAN</small>
      </span>
    </Link>
  );
}
export function Button({
  children,
  icon,
  end,
  onClick,
  to,
  kind = "primary",
  busy = false,
  disabled = false,
  type = "button",
  className = "",
}: {
  children: ReactNode;
  icon?: string;
  end?: string;
  onClick?: () => void;
  to?: string;
  kind?: string;
  busy?: boolean;
  disabled?: boolean;
  type?: "button" | "submit";
  className?: string;
}) {
  const inner = (
    <>
      {(icon || busy) && (
        <Icon
          name={busy ? "loading" : icon!}
          size={18}
          className={busy ? "spin" : ""}
        />
      )}
      <span>{children}</span>
      {end && <Icon name={end} size={16} />}
    </>
  );
  const cn = `btn btn-${kind} ${className}`;
  return to ? (
    <Link to={to} className={cn}>
      {inner}
    </Link>
  ) : (
    <button
      type={type}
      onClick={onClick}
      disabled={busy || disabled}
      className={cn}
    >
      {inner}
    </button>
  );
}
export function Eyebrow({ children }: { children: ReactNode }) {
  return (
    <div className="eyebrow">
      <span />
      {children}
    </div>
  );
}
export function Badge({ children }: { children: string }) {
  return (
    <span
      className={"status status-" + children.toLowerCase().replaceAll(" ", "-")}
    >
      <i />
      {children}
    </span>
  );
}
export function Field({
  label,
  children,
  hint,
  wide = false,
}: {
  label: string;
  children: ReactNode;
  hint?: string;
  wide?: boolean;
}) {
  return (
    <label className={"field " + (wide ? "field-wide" : "")}>
      <span>{label}</span>
      {children}
      {hint && <small>{hint}</small>}
    </label>
  );
}
export function ErrorBox({ message }: { message: string }) {
  return message ? (
    <div role="alert" className="alert error">
      <Icon name="alert" size={18} />
      <span>{message}</span>
    </div>
  ) : null;
}
export function Notice({
  children,
  icon = "info",
}: {
  children: ReactNode;
  icon?: string;
}) {
  return (
    <div className="alert notice">
      <Icon name={icon} size={18} />
      <span>{children}</span>
    </div>
  );
}
export function Empty({
  icon = "folder",
  title,
  children,
  action,
}: {
  icon?: string;
  title: string;
  children: ReactNode;
  action?: ReactNode;
}) {
  return (
    <div className="empty">
      <span className="empty-icon">
        <Icon name={icon} size={29} />
      </span>
      <h3>{title}</h3>
      <p>{children}</p>
      {action}
    </div>
  );
}
export function Loading({
  label = "Loading your workspace…",
}: {
  label?: string;
}) {
  return (
    <div className="loading" role="status">
      <Icon name="loading" className="spin" />
      {label}
    </div>
  );
}
export function Modal({
  title,
  children,
  onClose,
  wide = false,
}: {
  title: string;
  children: ReactNode;
  onClose: () => void;
  wide?: boolean;
}) {
  const r = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const el = r.current;
    el?.showModal();
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
      el?.close();
    };
  }, []);
  return (
    <dialog
      ref={r}
      aria-label={title}
      className={"dialog " + (wide ? "wide" : "")}
      onCancel={(e) => {
        e.preventDefault();
        onClose();
      }}
      onClick={(e) => {
        if (e.target === r.current) {
          const rect = r.current!.getBoundingClientRect();
          if (
            e.clientX < rect.left ||
            e.clientX > rect.right ||
            e.clientY < rect.top ||
            e.clientY > rect.bottom
          )
            onClose();
        }
      }}
    >
      <div className="modal-head">
        <div className="eyebrow">
          <span />
          BASHIR ALAM CLINIC
        </div>
        <button
          className="icon-btn"
          onClick={onClose}
          aria-label="Close dialog"
        >
          <Icon name="x" />
        </button>
      </div>
      <h2>{title}</h2>
      {children}
    </dialog>
  );
}
export function useLoad<T = any>(
  op: string,
  query?: Record<string, string>,
  enabled = true,
  viewKey = "",
) {
  const [data, setData] = useState<T | null>(null),
    [error, setError] = useState(""),
    [loading, setLoading] = useState(true),
    [tick, setTick] = useState(0);
  const key = JSON.stringify(query);
  useEffect(() => {
    let active = true;
    setData(null);
    setError("");
    if (!enabled) {
      setLoading(false);
      return;
    }
    setLoading(true);
    api<T>(op, undefined, query)
      .then((x) => active && setData(x))
      .catch((e) => active && setError(e.message))
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, [op, key, tick, enabled, viewKey]);
  return { data, error, loading, refresh: () => setTick((x) => x + 1) };
}
export function LoadError({
  error,
  retry,
}: {
  error: string;
  retry: () => void;
}) {
  return (
    <div>
      <ErrorBox message={error} />
      <Button kind="secondary" icon="refresh" onClick={retry}>
        Try again
      </Button>
    </div>
  );
}
